
module tb;
  localparam COUNT = 2693;
  reg clk = 0;
  always #5 clk = ~clk;
  reg enable = 0;
  wire done, write_en;
  wire [13:0] write_addr;
  wire [31:0] write_data;
  reg [45:0] expected [0:COUNT-1];
  // Deliberately uninitialized: no simulation-only memory preload.
  reg [31:0] ram [0:16383];
  integer n = 0, cycle = 0, complete_cycle = 0;
  reg saw_bounds = 0;
  
  wire dbg_boot_complete, dbg_fault_valid, retire_valid, retire_fault_valid;
  wire [31:0] dbg_nia, dbg_fault, retire_nia, debug_cr15_word2;
  full dut(.clk(clk), .rst_n(1'b1), .uart_rx_pin(1'b1),
    .dbg_boot_complete(dbg_boot_complete), .dbg_fault_valid(dbg_fault_valid),
    .dbg_nia(dbg_nia), .dbg_fault(dbg_fault), .retire_valid(retire_valid),
    .retire_nia(retire_nia), .retire_fault_valid(retire_fault_valid),
    .debug_cr15_word2(debug_cr15_word2),
    .done(done), .write_en(write_en), .write_addr(write_addr), .write_data(write_data));

  initial $readmemh("pairs.hex", expected);
  always @(negedge clk) enable = (cycle > 3 && cycle % 5 != 1 && cycle % 5 != 2);
  always @(posedge clk) begin
    cycle = cycle + 1;
    if (write_en === 1'bx) $fatal(1, "Unknown write enable");
    if (write_en) begin
      if (n >= COUNT) $fatal(1, "Extra write");
      if ({write_addr,write_data} !== expected[n])
        $fatal(1, "Write mismatch index=%0d addr=%h data=%h expected=%h",
               n, write_addr, write_data, expected[n]);
      ram[write_addr] = write_data;
      $display("WRITE %0d %0d %08h", n, write_addr, write_data);
      n = n + 1;
    end
    
      if (dbg_fault_valid === 1'b1 || retire_fault_valid === 1'b1)
        $fatal(1, "BOOT_FAULT nia=%h fault=%h cycle=%0d", dbg_nia, dbg_fault, cycle);
      if (retire_valid === 1'b1) begin
        $display("RETIRE cycle=%0d nia=%h", cycle, retire_nia);
        if (retire_nia === 32'h2e08) saw_bounds = 1;
        if (saw_bounds && retire_nia === 32'h2e0c) begin
          if (n != COUNT || ram[1] !== 32'd63 || !dbg_boot_complete ||
              debug_cr15_word2 !== 32'd63)
            $fatal(1, "Boot passed address without valid initialization");
          $display("PASS_BOOT_PAST_2E08 cycle=%0d ns_limit=%0d cr15_limit=%0d",
                   cycle, ram[1], debug_cr15_word2);
          $finish;
        end
      end

    if (cycle == 250000) $fatal(1, "TIMEOUT writes=%0d", n);
  end
endmodule
