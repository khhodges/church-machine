
`timescale 1ns/1ps
module tb;
  localparam COUNT = 2693;
  reg clk = 0;
  always #5 clk = ~clk;
  reg enable = 0;
  wire done, write_en;
  wire [13:0] write_addr;
  wire [31:0] write_data;
  reg [45:0] expected [0:COUNT-1];
  // Deliberately uninitialized: no simulation-only memory preload.
  reg [31:0] ram [0:16383];
  integer n = 0, cycle = 0, complete_cycle = 0;
  reg saw_bounds = 0;
  
  initializer dut(.clk(clk), .rst(1'b0), .enable(enable),
    .done(done), .write_en(write_en), .write_addr(write_addr), .write_data(write_data));

  initial $readmemh("pairs.hex", expected);
  always @(negedge clk) enable = (cycle > 3 && cycle % 5 != 1 && cycle % 5 != 2);
  always @(posedge clk) begin
    cycle = cycle + 1;
    if (write_en === 1'bx) $fatal(1, "Unknown write enable");
    if (write_en) begin
      if (n >= COUNT) $fatal(1, "Extra write");
      if ({write_addr,write_data} !== expected[n])
        $fatal(1, "Write mismatch index=%0d addr=%h data=%h expected=%h",
               n, write_addr, write_data, expected[n]);
      ram[write_addr] = write_data;
      $display("WRITE %0d %0d %08h", n, write_addr, write_data);
      n = n + 1;
    end
    
      if (done === 1'b1) begin
        if (n != COUNT || ram[1] !== 32'd63)
          $fatal(1, "Missing writes or namespace limit");
        if (complete_cycle == 0) complete_cycle = cycle;
        if (cycle == complete_cycle + 8) begin
          $display("PASS_INITIALIZER count=%0d ns_limit=%0d", n, ram[1]);
          $finish;
        end
      end

    if (cycle == 5000000) $fatal(1, "TIMEOUT writes=%0d", n);
  end
endmodule
