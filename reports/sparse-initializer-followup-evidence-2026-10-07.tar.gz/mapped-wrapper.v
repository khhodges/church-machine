
module \full.initializer (clk, enable, done, write_en, rd__data);
  input clk, enable;
  output done, write_en;
  output [45:0] rd__data;
  initializer mapped(.clk(clk), .rst(1'b0), .enable(enable), .done(done),
    .write_en(write_en), .write_addr(rd__data[45:32]), .write_data(rd__data[31:0]));
endmodule
