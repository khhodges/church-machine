
`timescale 1ns/1ps
module tb;
  reg clk = 0;
  always #5 clk = ~clk;
  wire done, write_en, dbg_boot_complete, dbg_fault_valid, retire_valid, retire_fault_valid;
  wire [13:0] write_addr;
  wire [31:0] write_data, dbg_nia, dbg_fault, retire_nia, debug_cr15_word2;
  full dut(.clk(clk), .rst_n(1'b1), .uart_rx_pin(1'b1),
    .dbg_boot_complete(dbg_boot_complete), .dbg_fault_valid(dbg_fault_valid),
    .dbg_nia(dbg_nia), .dbg_fault(dbg_fault), .retire_valid(retire_valid),
    .retire_nia(retire_nia), .retire_fault_valid(retire_fault_valid),
    .debug_cr15_word2(debug_cr15_word2), .done(done),
    .write_en(write_en), .write_addr(write_addr), .write_data(write_data));
  reg [45:0] expected [0:2693-1];
  integer n = 0, cycles = 0;
  integer retired = 0;
  reg saw_before = 0;
  initial $readmemh("pairs.hex", expected);
  always @(posedge clk) begin
    cycles = cycles + 1;
    if (write_en === 1'bx) $fatal(1, "unknown initializer enable");
    if (write_en) begin
      if (n >= 2693) $fatal(1, "extra initialization write");
      if ({write_addr,write_data} !== expected[n]) $fatal(1, "initializer mismatch %0d", n);
      if (n == 0 || n == 2693-1)
        $display("INITIALIZER index=%0d word=%0d value=%08h", n, write_addr, write_data);
      n = n + 1;
    end
    if (dbg_boot_complete && !saw_before) begin
      saw_before = 1;
      $display("BEFORE cycle=%0d", cycles);
      $display("CR0 w2_base_gt=%024h", dut.\core.u_registers.cr0 );
      $display("CR1 w2_base_gt=%024h", dut.\core.u_registers.cr1 );
      $display("CR2 w2_base_gt=%024h", dut.\core.u_registers.cr2 );
      $display("CR3 w2_base_gt=%024h", dut.\core.u_registers.cr3 );
      $display("CR4 w2_base_gt=%024h", dut.\core.u_registers.cr4 );
      $display("CR5 w2_base_gt=%024h", dut.\core.u_registers.cr5 );
      $display("CR6 w2_base_gt=%024h", dut.\core.u_registers.cr6 );
      $display("CR7 w2_base_gt=%024h", dut.\core.u_registers.cr7 );
      $display("CR8 w2_base_gt=%024h", dut.\core.u_registers.cr8 );
      $display("CR9 w2_base_gt=%024h", dut.\core.u_registers.cr9 );
      $display("CR10 w2_base_gt=%024h", dut.\core.u_registers.cr10 );
      $display("CR11 w2_base_gt=%024h", dut.\core.u_registers.cr11 );
      $display("CR12 w2_base_gt=%024h", dut.\core.u_registers.cr12 );
      $display("CR13 w2_base_gt=%024h", dut.\core.u_registers.cr13 );
      $display("CR14 w2_base_gt=%024h", dut.\core.u_registers.cr14 );
      $display("CR15 w2_base_gt=%024h", dut.\core.u_registers.cr15 );
      $display("DR1=%08h", dut.\core.u_registers.dr1 );
      $display("DR2=%08h", dut.\core.u_registers.dr2 );
      $display("DR3=%08h", dut.\core.u_registers.dr3 );
      $display("DR4=%08h", dut.\core.u_registers.dr4 );
      $display("DR5=%08h", dut.\core.u_registers.dr5 );
      $display("DR6=%08h", dut.\core.u_registers.dr6 );
      $display("DR7=%08h", dut.\core.u_registers.dr7 );
      $display("DR8=%08h", dut.\core.u_registers.dr8 );
      $display("DR9=%08h", dut.\core.u_registers.dr9 );
      $display("DR10=%08h", dut.\core.u_registers.dr10 );
      $display("DR11=%08h", dut.\core.u_registers.dr11 );
      $display("DR12=%08h", dut.\core.u_registers.dr12 );
      $display("DR13=%08h", dut.\core.u_registers.dr13 );
      $display("DR14=%08h", dut.\core.u_registers.dr14 );
      $display("DR15=%08h", dut.\core.u_registers.dr15 );
      if (dut.\core.u_registers.cr15 !== 96'h00000012_00000000_1a000000)
        $fatal(1, "unexpected bootstrap CR15");
    end
    if (dbg_fault_valid === 1'b1 || retire_fault_valid === 1'b1)
      $fatal(1, "FAULT nia=%08h code=%h", dbg_nia, dbg_fault);
    if (retire_valid === 1'b1) begin
      retired = retired + 1;
      $display("RETIRE nia=%08h instruction=%08h", retire_nia, dut.\core.retire_instr );
      if (retired == 1 && (retire_nia !== 0 || dut.\core.retire_instr !== 32'h077f8000))
        $fatal(1, "not the expected Namespace LOAD");
      if (retired == 2 && retire_nia !== 4)
        $fatal(1, "not the expected CHANGE address");
      // Observe committed storage after the current clock's nonblocking writes.
      #1;
      $display("AFTER instruction=%0d cycle=%0d", retired, cycles);
      $display("CR0 w2_base_gt=%024h", dut.\core.u_registers.cr0 );
      $display("CR1 w2_base_gt=%024h", dut.\core.u_registers.cr1 );
      $display("CR2 w2_base_gt=%024h", dut.\core.u_registers.cr2 );
      $display("CR3 w2_base_gt=%024h", dut.\core.u_registers.cr3 );
      $display("CR4 w2_base_gt=%024h", dut.\core.u_registers.cr4 );
      $display("CR5 w2_base_gt=%024h", dut.\core.u_registers.cr5 );
      $display("CR6 w2_base_gt=%024h", dut.\core.u_registers.cr6 );
      $display("CR7 w2_base_gt=%024h", dut.\core.u_registers.cr7 );
      $display("CR8 w2_base_gt=%024h", dut.\core.u_registers.cr8 );
      $display("CR9 w2_base_gt=%024h", dut.\core.u_registers.cr9 );
      $display("CR10 w2_base_gt=%024h", dut.\core.u_registers.cr10 );
      $display("CR11 w2_base_gt=%024h", dut.\core.u_registers.cr11 );
      $display("CR12 w2_base_gt=%024h", dut.\core.u_registers.cr12 );
      $display("CR13 w2_base_gt=%024h", dut.\core.u_registers.cr13 );
      $display("CR14 w2_base_gt=%024h", dut.\core.u_registers.cr14 );
      $display("CR15 w2_base_gt=%024h", dut.\core.u_registers.cr15 );
      $display("DR1=%08h", dut.\core.u_registers.dr1 );
      $display("DR2=%08h", dut.\core.u_registers.dr2 );
      $display("DR3=%08h", dut.\core.u_registers.dr3 );
      $display("DR4=%08h", dut.\core.u_registers.dr4 );
      $display("DR5=%08h", dut.\core.u_registers.dr5 );
      $display("DR6=%08h", dut.\core.u_registers.dr6 );
      $display("DR7=%08h", dut.\core.u_registers.dr7 );
      $display("DR8=%08h", dut.\core.u_registers.dr8 );
      $display("DR9=%08h", dut.\core.u_registers.dr9 );
      $display("DR10=%08h", dut.\core.u_registers.dr10 );
      $display("DR11=%08h", dut.\core.u_registers.dr11 );
      $display("DR12=%08h", dut.\core.u_registers.dr12 );
      $display("DR13=%08h", dut.\core.u_registers.dr13 );
      $display("DR14=%08h", dut.\core.u_registers.dr14 );
      $display("DR15=%08h", dut.\core.u_registers.dr15 );
      if (!saw_before || n != 2693 ||
          dut.\core.u_registers.cr15 !== 96'h0000003f_00000000_00000000)
        $fatal(1, "Namespace LOAD state mismatch");
      if (retired == 2) begin
        $display("PASS_REVIEW_BOUNDARY instructions=%0d", retired);
        $finish;
      end
    end
    if (cycles >= 600000) $fatal(1, "instruction deadline");
  end
endmodule
