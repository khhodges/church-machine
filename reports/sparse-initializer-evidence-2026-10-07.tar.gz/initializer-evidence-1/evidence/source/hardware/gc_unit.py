from amaranth import *
from amaranth.lib.data import View

from .hw_types import *
from .layouts import NS_ENTRY_LAYOUT, WORD2_LAYOUT


class ChurchGCUnit(Elaboratable):
    def __init__(self):
        self.gc_start = Signal()
        self.gc_mark_en = Signal()
        self.gc_sweep_en = Signal()
        self.gc_busy = Signal()
        self.gc_done = Signal()

        self.ns_addr = Signal(32)
        self.ns_rd_en = Signal()
        self.ns_rd_data = Signal(32 * 4)  # NS_ENTRY_WORDS=4 (stride-4, 16 bytes/slot)
        self.ns_wr_data = Signal(32 * 4)  # NS_ENTRY_WORDS=4 (stride-4, 16 bytes/slot)
        self.ns_wr_en = Signal()

        self.ns_start_index = Signal(16)
        self.ns_end_index = Signal(16)

        self.marked_count = Signal(32)
        self.garbage_count = Signal(32)

        self.valid_key_access = Signal()
        self.access_index = Signal(16)
        self.g_bit_reset = Signal()

    def elaborate(self, platform):
        m = Module()

        current_index = Signal(16)
        mark_counter = Signal(32)
        garbage_counter = Signal(32)

        # NS_ENTRY_LAYOUT (4 words at stride slot_id << 4, i.e. 16 bytes per entry;
        # NS_ENTRY_WORDS=4):
        #   word_select(0, 32) = word0_location  (+0)  — lump base byte address
        #   word_select(1, 32) = word1_authority (+4)  — WORD2_LAYOUT: limit_offset[20:0] | gt_seq[29:21] | g_bit[30] | f_flag[31] ★v2.0
        #   word_select(2, 32) = word2_integrity (+8)  — integrity32(W0, W1 with g_bit[30]+f_flag[31] masked)
        #   word_select(3, 32) = word3_seals     (+12) — FNV seal for mLoad validation (not used by GC)
        # g_bit is at W1[30] ★v2.0.  GC reads/writes W1; integrity stays valid (g_bit masked in check).
        latched_entry = Signal(32 * 4)  # NS_ENTRY_WORDS=4
        latched_w1 = latched_entry.word_select(1, 32)   # word1_authority (+4): g_bit at [30] ★v2.0

        w1_view = View(WORD2_LAYOUT, latched_w1)   # g_bit and gt_seq live here

        next_version = Signal(7)
        m.d.comb += next_version.eq(w1_view.gt_seq + 1)

        with m.FSM(name="gc") as fsm:
            with m.State("IDLE"):
                with m.If(self.gc_start & self.gc_mark_en):
                    m.d.sync += [
                        current_index.eq(self.ns_start_index),
                        mark_counter.eq(0),
                        garbage_counter.eq(0),
                    ]
                    m.next = "MARK_READ"
                with m.Elif(self.gc_start & self.gc_sweep_en):
                    m.d.sync += [
                        current_index.eq(self.ns_start_index),
                        mark_counter.eq(0),
                        garbage_counter.eq(0),
                    ]
                    m.next = "SWEEP_READ"

            with m.State("MARK_READ"):
                m.d.comb += [
                    self.ns_addr.eq(current_index),
                    self.ns_rd_en.eq(1),
                ]
                m.d.sync += latched_entry.eq(self.ns_rd_data)
                m.next = "MARK_WRITE"

            with m.State("MARK_WRITE"):
                wr_entry = Signal(32 * 4)  # NS_ENTRY_WORDS=4
                wr_w1 = wr_entry.word_select(1, 32)   # word1_authority (+4): g_bit at [28]
                wr_w1_view = View(WORD2_LAYOUT, wr_w1)
                m.d.comb += wr_entry.eq(latched_entry)
                m.d.comb += wr_w1_view.g_bit.eq(1)

                m.d.comb += [
                    self.ns_addr.eq(current_index),
                    self.ns_wr_data.eq(wr_entry),
                    self.ns_wr_en.eq(1),
                ]

                with m.If(~w1_view.g_bit):
                    m.d.sync += mark_counter.eq(mark_counter + 1)

                m.d.sync += current_index.eq(current_index + 1)

                with m.If(current_index >= self.ns_end_index):
                    with m.If(self.gc_sweep_en):
                        m.d.sync += current_index.eq(self.ns_start_index)
                        m.next = "SWEEP_READ"
                    with m.Else():
                        m.next = "COMPLETE"
                with m.Else():
                    m.next = "MARK_READ"

            with m.State("SWEEP_READ"):
                m.d.comb += [
                    self.ns_addr.eq(current_index),
                    self.ns_rd_en.eq(1),
                ]
                m.d.sync += latched_entry.eq(self.ns_rd_data)
                m.next = "SWEEP_CHECK"

            with m.State("SWEEP_CHECK"):
                with m.If(w1_view.g_bit):
                    m.d.sync += garbage_counter.eq(garbage_counter + 1)
                    m.next = "SWEEP_WRITE"
                with m.Else():
                    m.d.sync += current_index.eq(current_index + 1)
                    with m.If(current_index >= self.ns_end_index):
                        m.next = "COMPLETE"
                    with m.Else():
                        m.next = "SWEEP_READ"

            with m.State("SWEEP_WRITE"):
                swept_entry = Signal(32 * 4)  # NS_ENTRY_WORDS=4
                swept_w1 = swept_entry.word_select(1, 32)   # word1_authority (+4): gt_seq | g_bit
                swept_w1_view = View(WORD2_LAYOUT, swept_w1)
                m.d.comb += [
                    swept_entry.eq(0),
                    swept_w1_view.gt_seq.eq(next_version),
                ]
                m.d.comb += [
                    self.ns_addr.eq(current_index),
                    self.ns_wr_data.eq(swept_entry),
                    self.ns_wr_en.eq(1),
                ]

                m.d.sync += current_index.eq(current_index + 1)
                with m.If(current_index >= self.ns_end_index):
                    m.next = "COMPLETE"
                with m.Else():
                    m.next = "SWEEP_READ"

            with m.State("COMPLETE"):
                m.next = "IDLE"

        m.d.comb += [
            self.gc_busy.eq(~fsm.ongoing("IDLE") & ~fsm.ongoing("COMPLETE")),
            self.gc_done.eq(fsm.ongoing("COMPLETE")),
            self.marked_count.eq(mark_counter),
            self.garbage_count.eq(garbage_counter),
        ]

        m.d.comb += self.g_bit_reset.eq(self.valid_key_access)

        return m
