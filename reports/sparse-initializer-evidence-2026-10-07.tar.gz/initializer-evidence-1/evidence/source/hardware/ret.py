from amaranth import *
from amaranth.lib.data import View

from .hw_types import *
from .layouts import GT_LAYOUT, CAP_REG_LAYOUT, COND_FLAGS_LAYOUT, LUMP_HEADER_LAYOUT
from .mload_seq import mload_wait_body
from .stack_frame import stack_slot_addr
from .thread_design import THREAD_STO_OFFSET


class ChurchReturn(Elaboratable):
    def __init__(self):
        self.return_start = Signal()
        # Accepted instruction's low imm12; held through the later cLoad commit.
        self.return_mask = Signal(12)
        self.return_mask_latched = Signal(12)
        self.busy = Signal()
        self.complete = Signal()
        self.fault_valid = Signal()
        self.fault_type = Signal(5)  # 5 bits: FaultType values up to 0x18
        self.reboot_request = Signal()

        self.cr_wr_addr = Signal(4)
        self.cr_wr_data = Signal(CAP_REG_LAYOUT)
        self.cr_wr_en = Signal()

        self.nia_set = Signal()
        self.nia_value = Signal(32)
        # Every saved PC requires validated caller context, never a ROM
        # authority marker. Root CALL's 0x7FFF poison faults below.

        self.mload_start = Signal()
        self.mload_cr_src = Signal(4)
        self.mload_cr_dst = Signal(4)
        self.mload_index = Signal(16)
        self.mload_direct = Signal()
        self.mload_direct_gt = Signal(32)
        self.mload_m_elevated = Signal()
        self.mload_validate_only = Signal()

        self.mload_done = Signal()
        self.mload_fault = Signal()
        self.mload_fault_type = Signal(5)  # 5 bits: FaultType values up to 0x18

        self.lambda_active = Signal()
        self.lambda_pc = Signal(32)
        self.lambda_clear = Signal()

        self.cr5_heap   = Signal(CAP_REG_LAYOUT)
        self.cr14_code = Signal(CAP_REG_LAYOUT)
        # LAMBDA shares the caller's executable identity; this is an accepted
        # operand latch, not a CALL-time descriptor snapshot.
        self.cload_same_code = Signal()
        self.cload_code_location = Signal(32)
        self.cr12_thread = Signal(CAP_REG_LAYOUT)
        self.thread_base = Signal(32)
        # Cached by CHANGE on activation.  RETURN uses it to validate the
        # current frame and its saved predecessor before touching STO.
        self.thread_hdr = Signal(32)

        self.mem_rd_addr  = Signal(32)
        self.mem_rd_en    = Signal()
        self.mem_rd_data  = Signal(32)
        self.mem_rd_valid = Signal()

        self.mem_wr_addr = Signal(32)
        self.mem_wr_data = Signal(32)
        self.mem_wr_en   = Signal()

        self.cload_e_gt = Signal(32)
        self.flags_restore_en = Signal()
        self.flags_restore_data = Signal(COND_FLAGS_LAYOUT)

    def elaborate(self, platform):
        m = Module()

        CR5_HEAP  = 5

        cr5_heap_latched = Signal(CAP_REG_LAYOUT)
        cr12_thread_latched = Signal(CAP_REG_LAYOUT)
        thread_hdr_latched = Signal(32)
        lambda_active_latched = Signal()
        lambda_pc_latched = Signal(32)
        cr5_view  = View(CAP_REG_LAYOUT, cr5_heap_latched)
        cr5_gt    = View(GT_LAYOUT, cr5_view.word0_gt)
        cr5_null  = Signal()
        cr5_has_r = Signal()
        cr5_has_w = Signal()
        m.d.comb += [
            cr5_null.eq(cr5_gt.gt_type == GT_TYPE_NULL),
            cr5_has_r.eq(~cr5_gt.dom & cr5_gt.perm[PERM_R]),   # Turing dom=0, perm[0]=R
            cr5_has_w.eq(~cr5_gt.dom & cr5_gt.perm[PERM_W]),   # Turing dom=0, perm[1]=W
        ]

        cr12_view = View(CAP_REG_LAYOUT, cr12_thread_latched)
        cr12_gt   = View(GT_LAYOUT, cr12_view.word0_gt)
        code_view = View(CAP_REG_LAYOUT, self.cr14_code)
        code_gt = View(GT_LAYOUT, code_view.word0_gt)
        lambda_code_valid = Signal()
        lambda_egt = Signal(GT_LAYOUT)
        m.d.comb += [
            lambda_egt.slot_id.eq(code_gt.slot_id),
            lambda_egt.gt_seq.eq(code_gt.gt_seq),
            lambda_egt.gt_type.eq(code_gt.gt_type),
            lambda_egt.dom.eq(1),
            lambda_egt.perm.eq(0b100),
            lambda_egt.b_flag.eq(code_gt.b_flag),
            self.cload_same_code.eq(lambda_active_latched),
        ]
        cr12_null = Signal()
        m.d.comb += cr12_null.eq(cr12_gt.gt_type == GT_TYPE_NULL)

        heap_base_latched   = Signal(32)
        thread_base_latched = Signal(32)
        protected_sto_addr  = Signal(32)
        m.d.comb += protected_sto_addr.eq(
            thread_base_latched + (THREAD_STO_OFFSET << 2))

        sto_indicator      = Signal(32)
        sto_latched        = Signal(12)
        callee_egt_latched = Signal(32)
        return_pc_latched  = Signal(15)
        prev_sto_latched   = Signal(12)
        prev_sz_latched    = Signal()
        prev_flags_latched = Signal(COND_FLAGS_LAYOUT)
        thread_hdr_view = View(LUMP_HEADER_LAYOUT, thread_hdr_latched)
        lump_size = Signal(15)
        caps_start = Signal(15)
        stack_start = Signal(15)
        sp_max = Signal(15)
        m.d.comb += [
            lump_size.eq(Const(1, 15) << (thread_hdr_view.n_minus_6 + 6)),
            caps_start.eq(lump_size - 12),
            stack_start.eq(caps_start - thread_hdr_view.cw),
            sp_max.eq(caps_start - 1),
        ]

        frame_word    = Signal(32)
        frame_sz      = Signal()
        frame_ret_pc  = Signal(15)
        frame_prev_sto = Signal(16)
        m.d.comb += [
            frame_sz.eq(frame_word[12]),
            frame_ret_pc.eq(frame_word[13:28]),
            frame_prev_sto.eq(frame_word[0:12]),
        ]

        local_mem_rd_addr = Signal(32)
        local_mem_rd_en   = Signal()
        local_mem_wr_addr = Signal(32)
        local_mem_wr_data = Signal(32)
        local_mem_wr_en   = Signal()
        m.d.comb += [
            self.mem_rd_addr.eq(local_mem_rd_addr),
            self.mem_rd_en.eq(local_mem_rd_en),
            self.mem_wr_addr.eq(local_mem_wr_addr),
            self.mem_wr_data.eq(local_mem_wr_data),
            self.mem_wr_en.eq(local_mem_wr_en),
        ]

        m.d.comb += [
            self.mload_start.eq(0),
            self.mload_cr_src.eq(0),
            self.mload_cr_dst.eq(0),
            self.mload_index.eq(0),
            self.mload_direct.eq(0),
            self.mload_direct_gt.eq(0),
            self.mload_m_elevated.eq(0),
            self.mload_validate_only.eq(0),
        ]

        m.d.comb += [
            self.cr_wr_addr.eq(0),
            self.cr_wr_data.eq(0),
            self.cr_wr_en.eq(0),
        ]

        callee_egt_view = View(GT_LAYOUT, callee_egt_latched)
        companion_valid = Signal()
        m.d.comb += [
            self.cload_e_gt.eq(callee_egt_latched),
            companion_valid.eq(
                (callee_egt_view.gt_type == GT_TYPE_INFORM) &
                callee_egt_view.dom & callee_egt_view.perm[2]
            ),
        ]
        m.d.comb += [
            self.flags_restore_en.eq(0),
            self.flags_restore_data.eq(prev_flags_latched),
        ]

        sub_start_reg     = Signal()
        sub_done_latched  = Signal()
        sub_fault_latched = Signal()
        fault_flag        = Signal()
        fault_latched     = Signal(5)  # 5 bits: FaultType values up to 0x18
        # dmem_rd_valid is shared with the other execution units and is
        # one-cycle delayed. A valid left over from the preceding bus owner
        # must not be consumed when entering one of RETURN's read states.
        rd_armed          = Signal()

        with m.FSM(name="ret") as fsm:

            with m.State("IDLE"):
                m.d.sync += [
                    fault_flag.eq(0), fault_latched.eq(FaultType.NONE),
                    sub_done_latched.eq(0), sub_fault_latched.eq(0),
                    callee_egt_latched.eq(0),
                    rd_armed.eq(0),
                ]
                with m.If(self.return_start):
                    m.d.sync += [
                        self.return_mask_latched.eq(self.return_mask),
                        cr5_heap_latched.eq(self.cr5_heap),
                        cr12_thread_latched.eq(self.cr12_thread),
                        thread_base_latched.eq(self.thread_base),
                        thread_hdr_latched.eq(self.thread_hdr),
                        lambda_active_latched.eq(self.lambda_active),
                        lambda_pc_latched.eq(self.lambda_pc),
                        lambda_code_valid.eq(
                            (code_gt.gt_type == GT_TYPE_INFORM) &
                            ~code_gt.dom & code_gt.perm[PERM_X]),
                        self.cload_code_location.eq(code_view.word1_location),
                    ]
                    with m.If(self.lambda_active):
                        # CR6 may have changed in the lambda body; derive the
                        # reconstruction identity from the still-current CR14.
                        m.d.sync += callee_egt_latched.eq(lambda_egt.as_value())
                        m.next = "LAMBDA_FAST"
                    with m.Else():
                        # RETURN has no CR source operand. Its authority is the
                        # saved Enter E-GT in the architectural stack frame.
                        m.next = "CHECK_CR5_CR12"

            with m.State("LAMBDA_FAST"):
                with m.If(~lambda_code_valid):
                    m.d.sync += [
                        fault_flag.eq(1),
                        fault_latched.eq(FaultType.PERM_X),
                    ]
                    m.next = "FAULT"
                with m.Else():
                    # No frame pop on the legacy hardware leaf path, but the
                    # core must still run cLoad before committing the RETURN.
                    m.d.comb += [
                        self.nia_set.eq(1),
                        self.nia_value.eq(lambda_pc_latched),
                        self.lambda_clear.eq(1),
                    ]
                    m.next = "COMPLETE"

            with m.State("CHECK_CR5_CR12"):
                m.d.sync += [
                    heap_base_latched.eq(cr5_view.word1_location),
                ]
                with m.If(cr5_null):
                    m.d.sync += [fault_flag.eq(1), fault_latched.eq(FaultType.NULL_CAP)]
                    m.next = "FAULT"
                with m.Elif(~cr5_has_r):
                    m.d.sync += [fault_flag.eq(1), fault_latched.eq(FaultType.PERM_R)]
                    m.next = "FAULT"
                with m.Elif(~cr5_has_w):
                    m.d.sync += [fault_flag.eq(1), fault_latched.eq(FaultType.PERM_W)]
                    m.next = "FAULT"
                with m.Elif(cr12_null):
                    m.d.sync += [fault_flag.eq(1), fault_latched.eq(FaultType.NULL_CAP)]
                    m.next = "FAULT"
                with m.Else():
                    m.next = "READ_STO"

            with m.State("READ_STO"):
                m.d.comb += [
                    local_mem_rd_addr.eq(protected_sto_addr),
                    local_mem_rd_en.eq(1),
                ]
                m.d.sync += rd_armed.eq(1)
                with m.If(self.mem_rd_valid & rd_armed):
                    m.d.sync += [
                        sto_indicator.eq(self.mem_rd_data),
                        sto_latched.eq(self.mem_rd_data[:12]),
                        rd_armed.eq(0),
                    ]
                    m.next = "CHECK_STO"

            with m.State("CHECK_STO"):
                # Reject a malformed protected indicator before dereferencing
                # either frame word.  This keeps an out-of-zone STO from
                # turning the subsequent frame reads into an address oracle.
                with m.If(
                    (sto_indicator[12] == 0) |
                    (sto_indicator[13:28] != 0) |
                    (sto_latched < (stack_start + 2)) |
                    (sto_latched > sp_max)
                ):
                    m.d.sync += [
                        fault_flag.eq(1),
                        fault_latched.eq(FaultType.STACK_CORRUPT),
                    ]
                    m.next = "FAULT"
                with m.Else():
                    m.next = "READ_FRAME"

            with m.State("READ_FRAME"):
                m.d.comb += [
                    local_mem_rd_addr.eq(
                        thread_base_latched +
                        ((sto_latched + Mux(sto_indicator[12], 2, 1)) << 2)),
                    local_mem_rd_en.eq(1),
                ]
                m.d.sync += rd_armed.eq(1)
                with m.If(self.mem_rd_valid & rd_armed):
                    m.d.sync += frame_word.eq(self.mem_rd_data)
                    m.d.sync += [
                        return_pc_latched.eq(self.mem_rd_data[13:28]),
                        prev_sto_latched.eq(self.mem_rd_data[0:12]),
                        prev_sz_latched.eq(self.mem_rd_data[12]),
                        prev_flags_latched.eq(self.mem_rd_data[28:32]),
                        rd_armed.eq(0),
                    ]
                    m.next = "READ_EGT"

            with m.State("READ_EGT"):
                m.d.comb += [
                    local_mem_rd_addr.eq(stack_slot_addr(thread_base_latched, sto_latched, 1)),
                    local_mem_rd_en.eq(1),
                ]
                m.d.sync += rd_armed.eq(1)
                with m.If(self.mem_rd_valid & rd_armed):
                    m.d.sync += [
                        callee_egt_latched.eq(self.mem_rd_data),
                        rd_armed.eq(0),
                    ]
                    m.next = "VALIDATE_COMPANION"

            with m.State("VALIDATE_COMPANION"):
                # Run the saved companion through the shared direct-mLoad
                # validator before any POP_STACK, flags, or NIA side effect.
                # Abstract and non-E companions are rejected locally because
                # direct mLoad intentionally treats its word as already
                # resident and does not infer the required Inform-E type.
                with m.If(~companion_valid):
                    m.d.sync += [
                        fault_flag.eq(1),
                        fault_latched.eq(FaultType.STACK_CORRUPT),
                    ]
                    m.next = "FAULT"
                with m.Else():
                    m.d.comb += [
                        self.mload_start.eq(1),
                        self.mload_direct.eq(1),
                        self.mload_direct_gt.eq(callee_egt_latched),
                        self.mload_validate_only.eq(1),
                    ]
                    m.next = "VALIDATE_WAIT"

            with m.State("VALIDATE_WAIT"):
                mload_wait_body(
                    m,
                    sub_start_reg=sub_start_reg,
                    done_sig=self.mload_done,
                    fault_sig=self.mload_fault,
                    fault_type_sig=self.mload_fault_type,
                    sub_done_latched=sub_done_latched,
                    sub_fault_latched=sub_fault_latched,
                    fault_latched=fault_flag,
                    fault_type_latched=fault_latched,
                    done_next="VALIDATE_FRAME",
                )

            with m.State("VALIDATE_FRAME"):
                # A frame is committed only after both its bounds and its
                # companion have been checked.  In particular, a corrupt
                # frame can never advance the protected STO.
                with m.If(
                    (sto_indicator[12] == 0) |
                    (sto_indicator[13:28] != 0) |
                    (sto_latched < (stack_start + 2)) |
                    (sto_latched > sp_max) |
                    (frame_prev_sto != (sto_latched + 2)) |
                    (frame_prev_sto < (stack_start + 2)) |
                    (frame_prev_sto > sp_max) |
                    ~companion_valid
                ):
                    m.d.sync += [
                        fault_flag.eq(1),
                        fault_latched.eq(FaultType.STACK_CORRUPT),
                    ]
                    m.next = "FAULT"
                with m.Elif(return_pc_latched == 0x7FFF):
                    # Root CALL's poison return field is a marker, not a
                    # boot-ROM address.  Report underflow without popping
                    # the frame or requesting a namespace-backed cLoad.
                    m.d.sync += [
                        fault_flag.eq(1),
                        fault_latched.eq(FaultType.STACK_UNDERFLOW),
                    ]
                    m.next = "FAULT"
                with m.Else():
                    m.next = "POP_STACK"

            with m.State("POP_STACK"):
                m.d.comb += [
                    local_mem_wr_addr.eq(protected_sto_addr),
                    local_mem_wr_data.eq(Cat(
                        prev_sto_latched, prev_sz_latched,
                        Const(0, 15), prev_flags_latched.as_value())),
                    local_mem_wr_en.eq(1),
                    self.flags_restore_en.eq(1),
                ]
                m.next = "SET_NIA"

            with m.State("SET_NIA"):
                m.d.comb += [
                    self.nia_set.eq(1),
                    self.nia_value.eq(return_pc_latched << 2),
                ]
                m.next = "COMPLETE"

            with m.State("COMPLETE"):
                m.next = "IDLE"

            with m.State("REBOOT"):
                m.next = "IDLE"

            with m.State("FAULT"):
                m.next = "IDLE"

        m.d.comb += [
            self.busy.eq(~fsm.ongoing("IDLE")),
            self.complete.eq(fsm.ongoing("COMPLETE")),
            self.fault_valid.eq(fault_flag),
            self.fault_type.eq(fault_latched),
            self.reboot_request.eq(fsm.ongoing("REBOOT")),
        ]

        return m
