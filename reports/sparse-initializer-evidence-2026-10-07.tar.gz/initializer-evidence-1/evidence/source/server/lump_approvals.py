"""Dependency-free canonical LUMP approval-ledger contract."""
import hashlib
import hmac
import json
import os
import re
import tempfile

VERSION = 1
ALGORITHM = "sha256"
DIGEST_RE = re.compile(r"^[0-9a-f]{64}$")
COMPILER_SIGNING_SCHEME = "church-compiler-hmac-sha256/v2"
COMPILER_SIGNING_KEY_ID = "compiler-signing-secret/v1"
RECORD_FIELDS = frozenset({
    "binary_hash", "filename", "dot_name", "issue_n", "identity_hash", "token",
    "abstraction", "author", "version", "compiled_at", "display_name",
    "documentation", "annotations", "portable_binding", "pet_name", "pet_names",
    "history_note", "release_notes", "grants", "capability_type",
    "identity_string", "identity_seal_location", "bootstrap_t",
    "bootstrap_runtime_gt", "save_as_latest",
    "trust_origin", "compiler_identity", "compiler_version",
    "compiler_record", "integrity_record",
    "isa_profile", "execution_envelope", "execution_digest",
})
INTRINSIC_FIELDS = frozenset({
    "cw", "cc", "typ", "lump_size", "source", "api_definition",
    "sourceStorageTier", "binary", "clist_entries", "methods", "capabilities",
    "content_type", "profile", "language",
})
IDENTITY_SEAL_LOCATIONS = frozenset({"approval"})


def compiler_tcb_key(secret) -> bytes:
    """Derive the TCB-only compiler evidence key.

    The key is never accepted from an artifact or browser request.  App and
    boot-image processes derive the same key from the server session secret.
    """
    return hashlib.sha256(
        ("ChurchMachine.BankCustody|" + str(secret)).encode("utf-8")
    ).digest()


def configured_compiler_tcb_key(environ=None) -> bytes:
    """Return the dedicated, fail-closed compiler attestation key."""
    source = os.environ if environ is None else environ
    secret = source.get("COMPILER_SIGNING_SECRET")
    if (not isinstance(secret, str) or len(secret) < 32
            or secret == "dev-secret-key"):
        raise RuntimeError(
            "trusted compiler attestations require a dedicated high-entropy "
            "COMPILER_SIGNING_SECRET")
    return hashlib.sha256(
        ("ChurchMachine.CompilerAttestation.v1|" + secret).encode("utf-8")
    ).digest()


def configured_legacy_compiler_tcb_key(environ=None) -> bytes:
    """Return the pre-separation key for explicitly unversioned evidence."""
    source = os.environ if environ is None else environ
    secret = source.get("M_BIT_IDE_SECRET")
    if (not isinstance(secret, str) or len(secret) < 32
            or secret == "dev-secret-key"):
        raise RuntimeError(
            "legacy compiler attestations require the historical "
            "M_BIT_IDE_SECRET to satisfy the 32-character policy")
    return hashlib.sha256(
        ("ChurchMachine.CompilerAttestation.v1|" + secret).encode("utf-8")
    ).digest()


def compiler_record_verification_key(record, environ=None) -> bytes:
    """Select exactly one key from an evidence record's explicit format."""
    if not isinstance(record, dict):
        raise RuntimeError("compiler evidence record is not an object")
    scheme = record.get("signing_scheme")
    key_id = record.get("signing_key_id")
    if scheme == COMPILER_SIGNING_SCHEME and key_id == COMPILER_SIGNING_KEY_ID:
        return configured_compiler_tcb_key(environ)
    if scheme is None and key_id is None:
        return configured_legacy_compiler_tcb_key(environ)
    raise RuntimeError("compiler evidence has an unsupported signing scheme or key id")


def sign_compiler_record(record, *, signing_key):
    """Return an opaque server-signed record."""
    if not isinstance(record, dict):
        raise ValueError("compiler record must be an object")
    unsigned = dict(record)
    unsigned.pop("signature", None)
    unsigned["signing_scheme"] = COMPILER_SIGNING_SCHEME
    unsigned["signing_key_id"] = COMPILER_SIGNING_KEY_ID
    canonical = json.dumps(unsigned, sort_keys=True, separators=(",", ":"))
    unsigned["signature"] = hmac.new(
        bytes(signing_key), canonical.encode("utf-8"), hashlib.sha256
    ).hexdigest()
    return unsigned


def validate_record(digest, record):
    if not isinstance(digest, str) or not DIGEST_RE.fullmatch(digest):
        raise ValueError("approval digest must be lowercase SHA-256")
    if not isinstance(record, dict) or record.get("binary_hash") != digest:
        raise ValueError("approval record must be bound to its digest key")
    unknown = set(record) - RECORD_FIELDS
    if unknown:
        raise ValueError(f"approval record contains unsupported fields: {sorted(unknown)}")
    origin = record.get("trust_origin")
    if origin is not None and origin not in {
            "trusted-home-ide", "untrusted-upload", "human-vouched",
            "bootstrap-authorized"}:
        raise ValueError("approval trust_origin is unsupported")
    if origin == "trusted-home-ide":
        if not isinstance(record.get("compiler_identity"), str) or not record["compiler_identity"]:
            raise ValueError("trusted compiler record requires compiler_identity")
        if not isinstance(record.get("compiler_version"), str) or not record["compiler_version"]:
            raise ValueError("trusted compiler record requires compiler_version")
        if not isinstance(record.get("compiler_record"), dict):
            raise ValueError("trusted compiler record requires integrity-protected compiler_record")
    identity_string = record.get("identity_string")
    seal_location = record.get("identity_seal_location")
    if identity_string is not None or seal_location is not None:
        if not isinstance(identity_string, str) or not identity_string:
            raise ValueError(
                "approval identity_string must be a non-empty string when identity metadata is present")
        dot_name = record.get("dot_name")
        issue_n = record.get("issue_n")
        if not isinstance(dot_name, str) or not dot_name:
            raise ValueError(
                "approval identity metadata requires a non-empty dot_name")
        if not isinstance(issue_n, int) or isinstance(issue_n, bool) or issue_n < 1:
            raise ValueError(
                "approval identity metadata requires a positive integer issue_n")
        canonical_identity = f"{dot_name}#{issue_n}"
        if identity_string != canonical_identity:
            raise ValueError(
                f"approval identity_string must equal canonical identity {canonical_identity!r}")
        identity_hash = record.get("identity_hash")
        expected_hash = hashlib.sha256(identity_string.encode("utf-8")).hexdigest()
        if identity_hash != expected_hash:
            raise ValueError(
                "approval identity_hash must be the SHA-256 of identity_string")
        if not isinstance(seal_location, str) or seal_location not in IDENTITY_SEAL_LOCATIONS:
            raise ValueError(
                "approval identity_seal_location must be 'approval'")
    bootstrap_t = record.get("bootstrap_t")
    bootstrap_gt = record.get("bootstrap_runtime_gt")
    if bootstrap_t is not None or bootstrap_gt is not None:
        if (not isinstance(bootstrap_t, str) or
                len(bootstrap_t) != 8 or
                any(ch not in "0123456789abcdef" for ch in bootstrap_t) or
                isinstance(bootstrap_gt, bool) or not isinstance(bootstrap_gt, int)
                or not 0 <= bootstrap_gt <= 0xffffffff
                or bootstrap_t != f"{bootstrap_gt:08x}"):
            raise ValueError(
                "bootstrap approval T must be the exact unsigned 32-bit runtime SELF GT")
    return dict(record)


def validate_envelope(value):
    if (not isinstance(value, dict) or value.get("version") != VERSION
            or value.get("algorithm") != ALGORITHM
            or not isinstance(value.get("approvals"), dict)
            or set(value) != {"version", "algorithm", "approvals"}):
        raise ValueError("approval ledger must use the strict version-1 sha256 envelope")
    return {digest: validate_record(digest, record)
            for digest, record in value["approvals"].items()}


def is_trusted_compiler_record(record, *, binary=None, signing_key=None):
    """Whether *record* is compiler admission evidence, not an approval.

    Callers must still authenticate the envelope and the artifact hash before
    using this predicate.  Keeping the predicate here prevents each delivery
    path from inventing a subtly different trust spelling.
    """
    valid = (
        isinstance(record, dict)
        and record.get("trust_origin") == "trusted-home-ide"
        and isinstance(record.get("compiler_identity"), str)
        and bool(record["compiler_identity"])
        and isinstance(record.get("compiler_version"), str)
        and bool(record["compiler_version"])
        and isinstance(record.get("compiler_record"), dict)
    )
    if not valid:
        return False
    inner = record["compiler_record"]
    if inner.get("binary_hash") != record.get("binary_hash"):
        return False
    if binary is not None:
        if not isinstance(binary, (bytes, bytearray)):
            return False
        if hashlib.sha256(bytes(binary)).hexdigest() != record.get("binary_hash"):
            return False
        from server.idx1_profile import validate_execution
        try:
            execution = validate_execution(record, bytes(binary))
            if execution is not None and inner.get("isa_profile") != "IDX1":
                return False
        except ValueError:
            return False
    if signing_key is None:
        return False
    signature = inner.get("signature")
    unsigned = dict(inner)
    unsigned.pop("signature", None)
    canonical = json.dumps(unsigned, sort_keys=True, separators=(",", ":"))
    expected = hmac.new(
        bytes(signing_key), canonical.encode("utf-8"), hashlib.sha256).hexdigest()
    if (not isinstance(signature, str)
            or not hmac.compare_digest(signature, expected)):
        return False
    return True


def is_compiler_owned_record(record, *, binary=None):
    """Authenticated compiler provenance, excluding frozen bootstrap records."""
    if (not isinstance(record, dict)
            or record.get("bootstrap_t") is not None
            or record.get("bootstrap_runtime_gt") is not None):
        return False
    try:
        return is_trusted_compiler_record(
            record, binary=binary,
            signing_key=compiler_record_verification_key(record.get("compiler_record")))
    except (ValueError, TypeError, RuntimeError):
        return False


def read_approvals(path, missing_ok=True):
    try:
        with open(path, encoding="utf-8") as source:
            return validate_envelope(json.load(source))
    except FileNotFoundError:
        if missing_ok:
            return {}
        raise


def envelope(records):
    checked = {digest: validate_record(digest, record)
               for digest, record in records.items()}
    return {"version": VERSION, "algorithm": ALGORITHM, "approvals": checked}


def write_approvals(path, records):
    value = envelope(records)
    directory = os.path.dirname(path) or "."
    fd, temporary = tempfile.mkstemp(prefix=".approvals.", dir=directory)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as output:
            json.dump(value, output, indent=2)
            output.write("\n")
            output.flush()
            os.fsync(output.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)