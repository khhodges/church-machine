"""Boot image binary generator (Task #217).

Produces a self-contained binary boot image from a saved boot-config.json.

Format
------
Raw little-endian 32-bit memory dump of the simulator namespace memory window:

    bytes = totalNamespaceWords * 4

The image is exactly what the simulator's `memory[]` array should look
like immediately after `_initNamespaceTable()` finishes, so loading it
is a single `memory.set(uint32_words)` on the simulator side.

This is deliberately *not* the Wukong serial-upload ABI.  The simulator
uses an inverted Namespace table at the image tail, while Wukong has a
16K-word DMEM with a forward Namespace table at address zero.  Use
``build_wukong_upload_image()`` to project a validated generic image
onto that physical layout before sending it to a board.

The generator deliberately mirrors `simulator.js _initNamespaceTable()`
rather than calling out to the simulator runtime — Python here is the
canonical boot-image producer; the simulator's hardcoded path remains
as a fallback when no image is present.

Layout (all words 32-bit little-endian):

    [0 .. NS_LUMP_SIZE)                      Namespace lump body (header @0)
    [NS_LUMP_SIZE .. +THREAD_LUMP_SIZE)      Thread lump body    (header @0)
     [resident lump bodies, including the
      state-selected SelfTest, in allocation order]
    [NS_TABLE_BASE .. +NS_TABLE_RESERVE)     Namespace table
       (step1.nsSlotsMax entries × 4 words, default 256; named slots followed
        by Step-3 reserved empties; remainder zero)

NS slots 2–5 are MMIO device-register windows (UART, LED, BTN, TIMER).
They carry NS entries pointing at physical hardware addresses but have no
lump body in RAM — running_offset is not advanced for them.
SelfTest's Namespace slot, exact artifact, and allocation are selected from
authoritative Namespace state and manifest metadata.
"""
import json
import hashlib
from server.lump_approvals import (
    read_approvals, is_trusted_compiler_record, compiler_record_verification_key,
)
from server.lump_integrity import (
    compute_number, parse_canonical_filename,
)
from server.bootstrap_identity import (
    bootstrap_t_from_self_gt, verify_bootstrap_self_gt,
)
from server.namespace_authority import validate_namespace_rows, namespace_fingerprint
import os
import re
import struct
import warnings
from shared.architecture_contracts import (
    ABSTRACT_GT_WORD0 as ARCH_ABSTRACT_GT_WORD0,
    BOOT as ARCH_BOOT,
    GT_WORD0 as ARCH_GT_WORD0,
    NS_ENTRY as ARCH_NS_ENTRY,
    PROFILES as ARCH_PROFILES,
    field_lsb,
    field_width,
    ns_integrity_word1_mask,
)
from shared.namespace_header import (
    BASE as NS_HEADER_BASE,
    BOOT_ENTRY as NS_HEADER_BOOT_ENTRY,
    FORMAT as NS_HEADER_FORMAT,
    NAMESPACE_ENTRY_WORDS as NS_HEADER_ENTRY_WORDS,
    NAMESPACE_HEADER_V2_TAG,
    NAMESPACE_HEADER_V2_WORDS,
    NAMESPACE_HEADER_V2_MAX_SLOTS,
    NAMESPACE_HEADER_V2_VERSION,
    SEAL_BOUNDARY as NS_HEADER_SEAL_BOUNDARY,
    TABLE_OFFSET as NS_HEADER_TABLE_OFFSET,
    WORD0 as NS_HEADER_WORD0,
    SEAL_START_WORD as NS_HEADER_SEAL_START_WORD,
    encode_namespace_header,
    pack_namespace_word0,
    unpack_namespace_word0,
)
try:
    from boot_constants import DEMO_CLIST_SIZE, BOOT_ABSTR_DEFAULT_SIZE
except ImportError:
    from server.boot_constants import DEMO_CLIST_SIZE, BOOT_ABSTR_DEFAULT_SIZE

NS_ENTRY_WORDS   = ARCH_NS_ENTRY["words"]
NS_BUS_WORDS     = 4            # hardware ns_rd_data/ns_wr_data bus width in 32-bit words
MAX_NS_ENTRIES   = NAMESPACE_HEADER_V2_MAX_SLOTS
DEFAULT_NS_SLOTS_MAX = ARCH_PROFILES["generic-boot-image-v20"]["namespace"]["defaultSlots"]
NS_TABLE_RESERVE = DEFAULT_NS_SLOTS_MAX * NS_ENTRY_WORDS  # 1024 words = 256 entries × 4 (legacy default reserve)
SLOT_SIZE        = 0x40         # 64 words


def ns_table_reserve_words(ns_slots_max):
    """Return the NS table reservation in words for ns_slots_max configured slots.

    = ns_slots_max * NS_ENTRY_WORDS exactly (no power-of-2 rounding).
    This is deliberately not rounded or minimum-clamped: V2 ``cw`` is the
    physical, plain entry count, including its codec-valid zero value.  The
    caller validates whether a bootable image has enough entries for its
    mandatory Namespace rows.

    Examples:
        ns_slots_max=16  →   64 words
        ns_slots_max=52  →  208 words
        ns_slots_max=102 →  408 words
        ns_slots_max=1024 → 4096 words
    """
    return ns_slots_max * NS_ENTRY_WORDS

# Hardware-accurate device register limits (matches simulator.js
# DEVICE_REG_LIMITS and hardware/boot_rom.py _MMIO_ENTRIES).
DEVICE_REG_LIMITS = {}  # slots 11 (UART), 12 (LED), 13 (Button), 14 (Timer) freed — Tasks #406 and #431

# This is only the historical catalog index.  The live SelfTest Namespace slot
# is selected from ns-state for every generated image.
BOOT_ABSTR_NS_SLOT = ARCH_BOOT["minimalSlots"]["SelfTest"]
with open(os.path.join(os.path.dirname(os.path.dirname(__file__)),
                       "shared", "thread_design.json"), encoding="utf-8") as _thread_design_file:
    _THREAD_DESIGN = json.load(_thread_design_file)
THREAD_CAP_WORDS = _THREAD_DESIGN["capabilityHomes"]["words"]
THREAD_CAPS_OFFSET = (
    _THREAD_DESIGN["canonicalBodyWords"] - THREAD_CAP_WORDS
)
THREAD_MIN_WORDS = _THREAD_DESIGN["canonicalBodyWords"]
THREAD_STO_OFFSET = _THREAD_DESIGN["protectedStoOffset"]
THREAD_HEAP_OFFSET = _THREAD_DESIGN["heapOffset"]
THREAD_SUPPORTED_BODY_WORDS = tuple(_THREAD_DESIGN["supportedBodyWords"])


def thread_layout(lump_size, stack_words):
    """Derive the normative Thread zones from the shared contract."""
    caps_start = lump_size - THREAD_CAP_WORDS
    caps_end = lump_size - 1
    stack_end = caps_start - 1
    stack_start = caps_start - stack_words
    heap_start = THREAD_HEAP_OFFSET
    heap_end = stack_start - 1
    heap_words = max(0, heap_end - heap_start + 1)
    return {
        "valid": (lump_size in THREAD_SUPPORTED_BODY_WORDS
                  and stack_words > 0 and heap_words > 0
                  and heap_end + 1 == stack_start
                  and caps_end == lump_size - 1),
        "lump_size": lump_size,
        "sto_offset": THREAD_STO_OFFSET,
        "heap_start": heap_start,
        "heap_end": heap_end,
        "heap_words": heap_words,
        "stack_start": stack_start,
        "stack_end": stack_end,
        "stack_words": stack_words,
        "caps_start": caps_start,
        "caps_end": caps_end,
        "caps_words": THREAD_CAP_WORDS,
    }

# Mandatory NS slots — every valid boot image must have a non-zero entry here.
# CapabilityTest has a conventional catalog slot, but is not foundational.
CAPABILITY_TEST_NS_SLOT = 10  # CapabilityTest capability-validation LUMP

_MANDATORY_NS_SLOTS = (0, 1, 2, 3, 4, 5, 6, 10)

# The resident core is deliberately a named policy rather than an incidental
# consequence of whichever manifest rows happen to be marked resident.  The
# table remains extensible (the default capacity is larger than slot 13), but
# these identities and slots are stable across simulator, generic-image, and
# Wukong projections.
RESIDENT_BOOT_PROFILE_NAME = "three-lump-core-v1"
RESIDENT_BOOT_PROFILE = {
    "name": RESIDENT_BOOT_PROFILE_NAME,
    "core_slots": tuple(range(14)),
    "residents": {
        "SelfTest": 6,
        "WukongCallHome": 7,
        "CapabilityTest": 10,
    },
    "threads": {
        1: "Boot.Thread",
        11: "Thread.2",
        12: "Thread.3",
    },
    "devices": {
        2: "UART_DEV",
        3: "LED_DEV",
        4: "BTN_DEV",
        5: "TIMER_DEV",
        13: "M_BIT_DEV",
    },
    "catalog": {
        0: "Boot.NS",
        8: "Tunnel",
        9: "Ethernet",
    },
}


def validate_resident_boot_profile(rows, profile_name=RESIDENT_BOOT_PROFILE_NAME):
    """Validate and return the authoritative fixed resident Namespace map.

    A manifest is an artifact index and history store; it is not allowed to
    promote a different revision or a different abstraction into the resident
    core.  This check is intentionally performed before any image memory is
    allocated so malformed or ambiguous state cannot produce a partial image.
    """
    if profile_name != RESIDENT_BOOT_PROFILE_NAME:
        raise ValueError(f"unknown resident boot profile: {profile_name!r}")
    if not isinstance(rows, list):
        raise ValueError("resident boot profile requires a Namespace-state array")

    by_slot = {}
    for row in rows:
        if not isinstance(row, dict):
            raise ValueError("resident boot profile contains a non-object Namespace row")
        slot = row.get("slot")
        if isinstance(slot, bool) or not isinstance(slot, int):
            continue
        if slot in by_slot:
            raise ValueError(
                f"resident boot profile has duplicate Namespace slot {slot}")
        by_slot[slot] = row

    expected = {
        **RESIDENT_BOOT_PROFILE["catalog"],
        **RESIDENT_BOOT_PROFILE["threads"],
        **RESIDENT_BOOT_PROFILE["devices"],
        **{slot: name for name, slot in RESIDENT_BOOT_PROFILE["residents"].items()},
    }
    missing = [slot for slot in RESIDENT_BOOT_PROFILE["core_slots"]
               if slot not in by_slot]
    if missing:
        raise ValueError(
            "resident boot profile is missing fixed Namespace slots: "
            + ", ".join(map(str, missing)))
    wrong = [
        f"slot {slot} is {by_slot[slot].get('name')!r}, expected {name!r}"
        for slot, name in expected.items()
        if by_slot[slot].get("name") != name
    ]
    if wrong:
        raise ValueError("resident boot profile name/slot mismatch: " + "; ".join(wrong))

    resident_names = set()
    for name, slot in RESIDENT_BOOT_PROFILE["residents"].items():
        row = by_slot[slot]
        if (row.get("resident") is not True
                or row.get("boot_resident") is not True
                or row.get("load_policy") != "Resident"
                or row.get("ns_slot_policy") != "static"):
            raise ValueError(
                f"resident boot profile row {name} at slot {slot} must be "
                "resident, boot_resident, static, and load_policy=Resident")
        token = row.get("token") or row.get("cache_token")
        filename = row.get("filename")
        if not isinstance(token, str) or not token:
            raise ValueError(f"resident boot profile row {name} has no selected token")
        if (not isinstance(filename, str) or not filename
                or os.path.basename(filename) != filename):
            raise ValueError(
                f"resident boot profile row {name} has no exact artifact filename")
        seq = row.get("seq")
        if isinstance(seq, bool) or not isinstance(seq, int) or not 0 <= seq <= 0x1FF:
            raise ValueError(
                f"resident boot profile row {name} has invalid sequence {seq!r}")
        resident_names.add(name)

    return {slot: by_slot[slot] for slot in RESIDENT_BOOT_PROFILE["core_slots"]}


def namespace_boot_marker_slot(rows):
    """Return the sole live Namespace row carrying the Lightning Bolt marker.

    Namespace state is the image plan authority.  In particular, callers must
    not replace a missing marker with a boot-config value, a browser value, or
    a historical catalog default.  This helper is intentionally independent
    of the manifest so direct generator callers get the same fail-closed
    behavior as the server endpoint.
    """
    if not isinstance(rows, list):
        raise ValueError("authoritative ns-state abstractions must be a list")
    marked = []
    seen_slots = set()
    for row in rows:
        if not isinstance(row, dict):
            raise ValueError("authoritative ns-state contains a non-object row")
        slot = row.get("slot")
        if (isinstance(slot, bool) or not isinstance(slot, int)
                or not 0 <= slot < MAX_NS_ENTRIES):
            raise ValueError(
                f"authoritative ns-state contains invalid Namespace slot {slot!r}")
        if slot in seen_slots:
            raise ValueError(
                f"authoritative ns-state has duplicate Namespace slot {slot}")
        seen_slots.add(slot)
        if "boot" in row and not isinstance(row["boot"], bool):
            raise ValueError(
                f"authoritative ns-state NS[{slot}] has an invalid boot marker")
        if row.get("archived") is True and row.get("boot") is True:
            raise ValueError(
                f"authoritative ns-state archived NS[{slot}] has boot:true")
        if row.get("archived") is not True and row.get("boot") is True:
            marked.append(row)
    if len(marked) != 1:
        raise ValueError(
            "authoritative ns-state must contain exactly one live Namespace "
            f"row with boot:true (found {len(marked)})")
    return marked[0]["slot"]


# Format-version tag written to mem[NS_TABLE_BASE - 1] so loadBootImage()
# can reject stale binaries.
# Thread suspension ABI version. Images with the retired +18 executable-
# identity layout carry an older tag and are rejected before any Thread words
# are interpreted. Must match simulator.js.
# Namespace Header V2's physical format marker.  Pre-V2 images only carried a
# tail sentinel and are intentionally rejected rather than reinterpreted.
BOOT_IMAGE_FORMAT_TAG = NAMESPACE_HEADER_V2_TAG

# Wukong's physical-memory contract is shared with the hardware ABI so the
# image projection cannot drift from the synthesized board limits.
try:
    from hardware.hw_types import (
        WUKONG_DMEM_WORDS,
        WUKONG_FORWARD_NS_SLOTS,
        WUKONG_UPLOAD_BODY_BASE_WORD,
        WUKONG_PHYSICAL_MAX_THREAD_COUNT,
    )
except ImportError:
    _wukong_profile = ARCH_PROFILES["wukong-uart-upload-v2"]
    WUKONG_DMEM_WORDS = _wukong_profile["totalWords"]
    WUKONG_FORWARD_NS_SLOTS = _wukong_profile["namespace"]["slots"]
    WUKONG_UPLOAD_BODY_BASE_WORD = _wukong_profile["uploadBodyBaseWord"]
    WUKONG_PHYSICAL_MAX_THREAD_COUNT = _wukong_profile["maxThreadCount"]

# Direct dispatch: NUC_CODE (B:07) pre-loads CR0 with the boot-entry E-GT.
# No CHANGE→TPERM→CALL trampoline — 00000600.lump must always be present.


def _encode_perm(perms_dict):
    """Encode {R,W,X,L,S,E} → (dom, perm3) using Turing/Church mutual exclusion.

    Church side (L|S|E) dominates if any Church bit is set.
    Mirrors hardware/hw_types.py gt_encode_perm() and simulator.js createGT().
    Returns (dom: int 0–1, perm3: int 0–7).
    """
    E = 1 if perms_dict.get("E") else 0
    S = 1 if perms_dict.get("S") else 0
    L = 1 if perms_dict.get("L") else 0
    if E or S or L:
        return 1, (E << 2) | (S << 1) | L
    X = 1 if perms_dict.get("X") else 0
    W = 1 if perms_dict.get("W") else 0
    R = 1 if perms_dict.get("R") else 0
    return 0, (X << 2) | (W << 1) | R


# Abstract GT device-class constants (Task #406) — must match simulator.js
DEVICE_CLASS_LED      = 0x01
DEVICE_CLASS_UART     = 0x02
DEVICE_CLASS_BUTTON   = 0x03
DEVICE_CLASS_TIMER    = 0x04
DEVICE_CLASS_DISPLAY  = 0x05
DEVICE_CLASS_CHURCHHW = 0x06  # hardware-control device: PetNameMemory write port (Task #1542)

AB_TYPE_IO          = 0x00
AB_TYPE_M_ELEVATION = 0x01


def create_abstract_sperm_gt():
    """Abstract S-perm GT — encodes CHANGE CR12/CR13 authority without an NS entry.

    type=0b11 (Abstract), dom=1 (Church), perm3=0b010 (S), slot_id=0, gt_seq=0.
    Word value: (0b010<<28)|(1<<27)|(0b11<<25) = 0x2E000000

    Replaces the old Inform GTs pointing at Church HW Range NS entries (slots 19-22).
    Used in SERVICE_CLIST_DEFS via descriptor type "abstract_sperm".
    """
    dom, perm3 = _encode_perm({"S": 1})
    return _u32((perm3 << 28) | (dom << 27) | (0b11 << 25))


def create_abstract_gt(ab_type, rw_perms, gt_seq, ab_data):
    """Encode a self-describing Abstract GT word (type=0b11).

    v2.0 Layout: [31:27]=ab_type  [26:25]=gt_type=0b11  [24]=R  [23]=W  [22:16]=gt_seq  [15:0]=ab_data
    Only R and W are valid perm bits; X/L/S/E/B are repurposed as ab_type.
    Mirrors simulator.js createAbstractGT() (★v2.0 bit positions).

    Raises ValueError if any of X/L/S/E/B are present in rw_perms — those bits
    are repurposed as ab_type and must never appear as perm keys.
    """
    illegal = [k for k in ("X", "L", "S", "E", "B") if rw_perms.get(k)]
    if illegal:
        raise ValueError(
            f"create_abstract_gt: {', '.join(illegal)} are not valid perm bits for "
            f"Abstract GTs — they are repurposed as ab_type.  Use only R and W."
        )
    # v2.0 layout: gt_type=0b11 at [26:25], R at bit[24], W at bit[23] ★v2.0
    r_bit = 1 if rw_perms.get("R") else 0
    w_bit = 1 if rw_perms.get("W") else 0
    fields = ARCH_ABSTRACT_GT_WORD0["fields"]
    mask = lambda name: (1 << field_width(fields[name])) - 1
    return _u32(
        ((ab_type & mask("ab_type")) << field_lsb(fields["ab_type"])) |
        (0b11 << field_lsb(fields["gt_type"])) |
        (r_bit << field_lsb(fields["read"])) |
        (w_bit << field_lsb(fields["write"])) |
        ((gt_seq & mask("gt_seq")) << field_lsb(fields["gt_seq"])) |
        (ab_data & mask("ab_data"))
    )


# Default abstraction catalog — ports simulator.js _getAbstractionCatalog()
# fallback list (used when no abstractionRegistry is wired in). The boot
# image is produced from this canonical list so server and simulator
# agree on what the default boot ROM contains.
#
# Sparse fixed boot namespace through slot 13, followed by user-deployed abstractions.
# The ⚡ lightning bolt sets Thread.CR0 to the E-GT of whichever slot the programmer
# chooses as the boot entry.  Default is SelfTest (slot 6); Wukong boards use slot 7.
DEFAULT_ABSTRACTION_CATALOG = [
    ("Boot.NS",        {"R":0,"W":0,"X":0,"L":0,"S":0,"E":0}, False),
    ("Boot.Thread",    {"R":0,"W":0,"X":0,"L":0,"S":0,"E":0}, False),
    *[
        (
            name,
            {p: int(p in ARCH_BOOT["devices"][name]["permissions"]) for p in ("R", "W", "X", "L", "S", "E")},
            False,
        )
        for name in ("UART_DEV", "LED_DEV", "BTN_DEV", "TIMER_DEV")
    ],
    ("SelfTest",       {"R":0,"W":0,"X":0,"L":0,"S":0,"E":1}, False),
    ("WukongCallHome", {"R":0,"W":0,"X":0,"L":0,"S":0,"E":1}, False),
     ("Tunnel",         {"R":0,"W":0,"X":0,"L":0,"S":0,"E":1}, False),  # 8  CALL HOME / IDE bridge
    ("Ethernet",       {"R":0,"W":0,"X":0,"L":0,"S":0,"E":1}, False),  # 9  network I/O hardware cap
    ("CapabilityTest",        {"R":0,"W":0,"X":0,"L":0,"S":0,"E":1}, False),  # 10 capability validation LUMP
    None,  # 11 reserved/free
    None,  # 12 reserved/free
    ("M_BIT_DEV",      {p: int(p in ARCH_BOOT["devices"]["M_BIT_DEV"]["permissions"]) for p in ("R", "W", "X", "L", "S", "E")}, False),  # 13 Namespace-held one-word M register
]
assert len(DEFAULT_ABSTRACTION_CATALOG) == 14, "catalog drift vs simulator.js"

# Thread.1 is the fixed Boot.Thread entry at NS slot 1. Configured secondary
# threads retain their established slots: Thread.2 -> 11, Thread.3 -> 12.
# Additional generated threads skip the fixed M_BIT_DEV at slot 13.
GENERATED_THREAD_FIRST_NS_SLOT = 11
MAX_THREAD_COUNT = 10


def configured_thread_count(step1):
    """Return the validated V20 Thread Count from a Step-1 config."""
    raw = step1.get("threadCount", 1) if isinstance(step1, dict) else 1
    if not isinstance(raw, int) or isinstance(raw, bool) or not (1 <= raw <= MAX_THREAD_COUNT):
        raise ValueError(
            f"threadCount must be an integer between 1 and {MAX_THREAD_COUNT}"
        )
    return raw


def generated_thread_slots(thread_count):
    """Return deterministic NS slots for Thread.2 through Thread.N."""
    if not isinstance(thread_count, int) or isinstance(thread_count, bool) or not (
            1 <= thread_count <= MAX_THREAD_COUNT):
        raise ValueError(
            f"threadCount must be an integer between 1 and {MAX_THREAD_COUNT}"
        )
    slots = []
    candidate = GENERATED_THREAD_FIRST_NS_SLOT
    while len(slots) < thread_count - 1:
        if candidate != ARCH_BOOT["minimalSlots"]["M_BIT_DEV"]:
            slots.append(candidate)
        candidate += 1
    return tuple(slots)


def generated_thread_label(slot):
    """Return the display pet name for a generated Thread slot, if any."""
    try:
        offset = generated_thread_slots(MAX_THREAD_COUNT).index(slot)
    except ValueError:
        return None
    return f"Thread.{offset + 2}"


def boot_resident_region_end(thread_size, boot_abstr_size, thread_count,
                             catalog_slot_sizes=None):
    """Return the first free RAM word after the fixed boot bodies.

    Legacy estimate retained for callers that do not have authoritative
    Namespace state.  Image generation itself computes the protected end from
    the live resident-placement cursor, including the selected SelfTest body.
    """
    catalog_slot_sizes = catalog_slot_sizes or {}
    mmio_slots = {
        ARCH_BOOT["minimalSlots"][name]
        for name in ARCH_BOOT["devices"]
    }
    trailing_catalog_words = sum(
        catalog_slot_sizes.get(slot, SLOT_SIZE)
        for slot in range(BOOT_ABSTR_NS_SLOT + 1,
                          len(DEFAULT_ABSTRACTION_CATALOG))
        if slot not in mmio_slots
        and DEFAULT_ABSTRACTION_CATALOG[slot] is not None
    )
    return (NAMESPACE_HEADER_V2_WORDS + thread_size * thread_count
            + boot_abstr_size + trailing_catalog_words)


def architecture_device_catalog():
    """Return the built-in device facts from the shared architecture contract.

    The boot image and server-side approval view both need the same slot,
    address, register-count, and permission facts.  Keep this as a fresh
    structure so callers cannot mutate the architecture contract imported
    from ``shared.architecture_contracts``.
    """
    return {
        name: {
            "name": name,
            "slot": int(ARCH_BOOT["minimalSlots"][name]),
            "address": int(spec["address"]),
            "words": int(spec["words"]),
            "limit": int(spec["words"]) - 1,
            "permissions": tuple(spec.get("permissions", ())),
        }
        for name, spec in ARCH_BOOT["devices"].items()
    }


# MMIO NS slot specs: (mmio_byte_addr, lim17).
# Device slots use physical MMIO addresses — no RAM body is allocated;
# running_offset is not advanced for them.
_MMIO_SLOT_SPECS = {
    device["slot"]: (device["address"], device["limit"])
    for device in architecture_device_catalog().values()
}

# Service abstraction c-list capability table.
# Each entry: ns_slot -> [ GT descriptor, ... ]
#   GT descriptor tuple types:
#     ("inform",        ns_slot_ref, perms_dict) -> create_gt(0, ns_slot_ref, perms_dict, 1)
#     ("abstract",      ab_type, rw_perms_dict, ab_data) -> create_abstract_gt(...)
#     ("abstract_sperm",)                        -> create_abstract_sperm_gt() = 0x2E000000
# Minimal: only Thread (36), TuringMemory (39), ChurchMemory (40) need c-lists.
# Pure Church-calculus slots (SUCC/PRED/ADD/SUB/MUL/ISZERO/TRUE/FALSE/PAIR) keep cc=0.
SERVICE_CLIST_DEFS = {
    36: [("abstract_sperm",)],                                         # Thread:       Abstract S-perm GT (CHANGE CR12 authority)
    39: [("inform", 38, {"E":1})],                                     # TuringMemory: Billing E
    40: [("inform", 38, {"E":1})],                                     # ChurchMemory: Billing E
}


# ----- bit-packing helpers (mirror simulator.js exactly) ---------------------

def _u32(x):
    return x & 0xFFFFFFFF


_NS_W1_FIELDS = ARCH_NS_ENTRY["word1"]["fields"]


def _field_mask(field):
    return (1 << field_width(field)) - 1


def _ns_word1_get(word, name):
    field = _NS_W1_FIELDS[name]
    return (word >> field_lsb(field)) & _field_mask(field)


def _ns_word1_replace(word, name, value):
    field = _NS_W1_FIELDS[name]
    shifted_mask = _field_mask(field) << field_lsb(field)
    return _u32((word & ~shifted_mask)
                | ((value & _field_mask(field)) << field_lsb(field)))


def perm_bits(perms):
    """Return the 6-bit logical permission mask (for legacy callers only).

    Bit layout: R=0, W=1, X=2, L=3, S=4, E=5.  B (bit 6) is NOT a GT perm.
    Use _encode_perm() for new GT word construction.
    """
    bits = 0
    if perms.get("R"): bits |= 1
    if perms.get("W"): bits |= 2
    if perms.get("X"): bits |= 4
    if perms.get("L"): bits |= 8
    if perms.get("S"): bits |= 16
    if perms.get("E"): bits |= 32
    return bits & 0x3F


def pack_ns_word1(limit_offset, gt_seq=0, g=0, f=0):
    """Pack the canonical v2.0 NS W1 authority word.

    W1 has one meaning in every resident entry:
      limit_offset[20:0] | gt_seq[29:21] | g_bit[30] | f_flag[31].
    Entry state is carried by the access GT, never by W1.
    """
    fields = ARCH_NS_ENTRY["word1"]["fields"]
    mask = lambda name: (1 << field_width(fields[name])) - 1
    return _u32(
        ((f & mask("f_flag")) << field_lsb(fields["f_flag"]))
        | ((g & mask("g_bit")) << field_lsb(fields["g_bit"]))
        | ((gt_seq & mask("gt_seq")) << field_lsb(fields["gt_seq"]))
        | (limit_offset & mask("limit_offset"))
    )


def pack_lump_header(n_minus_6, cw, cc, typ=0):
    if typ == 1:
        raise ValueError(
            "pack_lump_header: typ=01 is Namespace Header V2; use "
            "pack_namespace_word0(total_words, slots)")
    return _u32(
        (0x1F            << 27)
        | ((n_minus_6 & 0xF) << 23)
        | ((cw & 0x1FFF)     << 10)
        | ((typ & 0x3)       <<  8)
        | (cc & 0xFF)
    )


def create_gt(gt_seq, slot_id, perms, gt_type):
    """Encode a 32-bit GT word using the v2.0 GT layout.

    v2.0 layout (matches hardware/hw_types.py make_gt and simulator.js createGT):
      slot_id[15:0] | gt_seq[24:16] (9-bit) | gt_type[26:25]
      | dom[27] | perm[30:28] | b_flag[31]=0

    Note: v1.x layout used gt_type[24:23] and gt_seq[22:16] (7-bit).
    """
    dom, perm3 = _encode_perm(perms)
    fields = ARCH_GT_WORD0["fields"]
    mask = lambda name: (1 << field_width(fields[name])) - 1
    t = (gt_type & mask("gt_type")) << field_lsb(fields["gt_type"])
    s = (gt_seq & mask("gt_seq")) << field_lsb(fields["gt_seq"])
    d = (dom & mask("dom")) << field_lsb(fields["dom"])
    p = (perm3 & mask("perm")) << field_lsb(fields["perm"])
    return _u32(d | p | t | s | (slot_id & mask("slot_id")))


def localize_portable_lump_body(lump_words, portable_binding, candidates):
    """Materialize a portable c-list once destination bindings are available.

    ``candidates`` is keyed by exact ``N`` and each value must include the
    actual on-disk ``lump_bytes``, live ``ns_slot`` and live ``sequence``.
    This intentionally does not use a manifest hash as evidence: candidate
    verification rehashes the actual bytes before a local GT is minted.
    """
    try:
        from portable_binding import (validate_portable_binding, validate_unresolved_clist,
                                      verify_candidate, mint_gt)
    except ImportError:
        from server.portable_binding import (validate_portable_binding, validate_unresolved_clist,
                                             verify_candidate, mint_gt)
    if not lump_words:
        raise ValueError("portable localization requires a LUMP body")
    header = int(lump_words[0]) & 0xffffffff
    if ((header >> 27) & 0x1f) != 0x1f:
        raise ValueError("portable localization requires a valid LUMP header")
    size = 1 << (((header >> 23) & 0xf) + 6)
    cc = header & 0xff
    if len(lump_words) < size or cc > size:
        raise ValueError("portable localization LUMP body is truncated")
    contract = validate_portable_binding(portable_binding, cc)
    validate_unresolved_clist(contract, lump_words)
    output = list(lump_words[:size])
    for dep in contract["dependencies"]:
        candidate = candidates.get(dep["N"]) if isinstance(candidates, dict) else None
        if dep["symbolic_self"] and candidate is None:
            candidate = candidates.get(contract["owner"]) if isinstance(candidates, dict) else None
        raw = candidate.get("lump_bytes") if isinstance(candidate, dict) else None
        ok, reason = verify_candidate(dep, candidate, raw)
        if not ok:
            raise ValueError(f"portable localization {dep['N']}: {reason}")
        granted = candidate.get("grants", candidate.get("rights", []))
        granted = {str(right).upper() for right in
                   (granted if isinstance(granted, list) else str(granted))}
        if not set(dep["rights"]).issubset(granted):
            raise ValueError(f"portable localization {dep['N']}: insufficient rights")
        if _type_value(candidate.get("capability_type", candidate.get("gt_type",
                                                                       candidate.get("type", 1)))) != dep["capability_type"]:
            raise ValueError(f"portable localization {dep['N']}: capability type mismatch")
        slot, sequence = candidate.get("ns_slot"), candidate.get("sequence", candidate.get("gt_seq"))
        if (isinstance(slot, bool) or not isinstance(slot, int) or not 0 <= slot <= 0xffff or
                isinstance(sequence, bool) or not isinstance(sequence, int) or not 0 <= sequence <= 0x1ff):
            raise ValueError(f"portable localization {dep['N']}: invalid live destination")
        output[size - cc + dep["relocation_row"]] = mint_gt(
            sequence, slot, dep["rights"], dep["capability_type"])
    return output


def _type_value(value):
    """Small local type normalizer used by portable localization."""
    if isinstance(value, int) and not isinstance(value, bool) and 0 <= value <= 3:
        return value
    names = {"null": 0, "inform": 1, "outform": 2, "abstract": 3}
    try:
        return names[str(value).lower()]
    except KeyError:
        raise ValueError("invalid candidate capability type")


def _rol32(value, amount):
    value &= 0xFFFFFFFF
    return ((value << amount) | (value >> (32 - amount))) & 0xFFFFFFFF


def integrity32(location, authority):
    """Canonical hardware integrity32 over NS W0/W1.

    G and F are mutable liveness/routing bits, so W1[31:30] are masked before
    the check.  This is corruption detection, not cryptographic authenticity.
    """
    authority_masked = authority & ns_integrity_word1_mask()
    return _u32(
        _rol32(location, 7)
        ^ _rol32(authority_masked, 13)
        ^ 0xDEADBEEF
    )


def write_ns_entry(mem, total, ns_entry_words, slot, location, lim17,
                   b, g, gt_type, gt_seq, clist_count, cache_token32):
    """Write a single NS table entry with internally-computed seal (word2).

    This is the sole legitimate path for writing NS table entries in the
    boot image generator — no caller may set word2 directly.  The seal is
    always computed here from (location, lim17) and gt_seq, mirroring the
    hardware mLoad gate.

    Inverted layout: slot N starts at total - (N+1)*ns_entry_words.
    """
    if gt_type == 3:
        raise ValueError(
            f"write_ns_entry(slot {slot}): Abstract GTs (gt_type=3) must never "
            f"have NS entries. Use only Inform (1) or Outform (2)."
        )
    base = total - (slot + 1) * ns_entry_words
    mem[base + 0] = location & 0xFFFFFFFF
    authority = pack_ns_word1(lim17, gt_seq=gt_seq, g=g, f=0)
    mem[base + 1] = authority
    mem[base + 2] = integrity32(location, authority)
    # Resident Inform Word 3 is a compact cache/index value only.  It is
    # deliberately outside integrity32 and is never identity or authority.
    mem[base + 3] = (cache_token32 or 0) & 0xFFFFFFFF


def _locate_namespace_header(words, caller):
    """Return V2 physical-header facts or reject legacy/corrupt images.

    The format marker is retained as a bounded tail search only to identify the
    block; every location thereafter is taken from, and checked against, the
    physical V2 fields.  This makes a stale V1 tail sentinel an explicit
    unsupported-format failure, never a different interpretation.
    """
    total = len(words)
    tag_idx = NS_HEADER_FORMAT
    if total < NAMESPACE_HEADER_V2_WORDS or words[tag_idx] != BOOT_IMAGE_FORMAT_TAG:
        raise ValueError(
            f"{caller}: Namespace Header V2 format marker not found; "
            "image is stale or corrupt (legacy format is unsupported) and must be regenerated")
    start = 0
    if total < NAMESPACE_HEADER_V2_WORDS:
        raise ValueError(f"{caller}: truncated Namespace Header V2 block")
    decoded = unpack_namespace_word0(words[start + NS_HEADER_WORD0])
    table_base = words[start + NS_HEADER_TABLE_OFFSET]
    if decoded["total_words"] != total:
        raise ValueError(f"{caller}: Namespace header RAM allocation does not match image")
    if words[start + NS_HEADER_BASE] != 0:
        raise ValueError(f"{caller}: Namespace header base address must be zero")
    if words[start + NS_HEADER_SEAL_BOUNDARY] != NS_HEADER_SEAL_START_WORD:
        raise ValueError(f"{caller}: Namespace header seal boundary is not canonical")
    if any(words[index] for index in range(NS_HEADER_SEAL_START_WORD, NAMESPACE_HEADER_V2_WORDS)):
        raise ValueError(f"{caller}: Namespace header future seal section is nonzero")
    table_words = total - table_base
    if (table_words < 0 or table_words % NS_HEADER_ENTRY_WORDS
            or decoded["slots"] != table_words // NS_HEADER_ENTRY_WORDS):
        raise ValueError(f"{caller}: Namespace header has impossible four-word table geometry")
    entry = words[start + NS_HEADER_BOOT_ENTRY]
    if entry & 3 or not NAMESPACE_HEADER_V2_WORDS * 4 <= entry < total * 4:
        raise ValueError(f"{caller}: Namespace header boot-entry location is invalid")
    entry_word = entry // 4
    matching_slots = [
        slot for slot in range(decoded["slots"])
        if words[total - (slot + 1) * NS_ENTRY_WORDS] == entry_word
    ]
    return {
        "start": start, "tag_idx": tag_idx, "table_base": table_base,
        "table_words": table_words, "slots": decoded["slots"],
        "boot_slot": matching_slots[0] if len(matching_slots) == 1 else None,
        "boot_entry": entry_word, **decoded,
    }


def read_namespace_header_info(image_bytes):
    """Return the canonical V2 physical-header facts from an image.

    This is the server/API-facing decoder.  It intentionally exposes values
    from the serialized header rather than accepting boot-config display
    metadata, so Build Approval cannot describe a different Namespace than
    the one a loader will consume.
    """
    if not isinstance(image_bytes, (bytes, bytearray, memoryview)):
        raise ValueError("Namespace image must be bytes")
    if len(image_bytes) % 4:
        raise ValueError("Namespace image length is not a whole number of words")
    n_words = len(image_bytes) // 4
    words = struct.unpack(f"<{n_words}I", image_bytes)
    physical = _locate_namespace_header(words, "read_namespace_header_info")
    return {
        "format_tag": words[physical["start"] + NS_HEADER_FORMAT],
        "version": NAMESPACE_HEADER_V2_VERSION,
        "base_byte": words[physical["start"] + NS_HEADER_BASE],
        "total_words": physical["total_words"],
        "slot_count": physical["slots"],
        "table_offset_words": physical["table_base"],
        "table_offset_byte": physical["table_base"] * 4,
        "boot_entry_word": physical["boot_entry"],
        "boot_entry_byte": words[physical["start"] + NS_HEADER_BOOT_ENTRY],
        "boot_entry_slot": physical["boot_slot"],
        "seal_boundary_word": words[physical["start"] + NS_HEADER_SEAL_BOUNDARY],
    }


def _encoded_thread_count(words, slots):
    """Infer contiguous resident Thread contexts, not arbitrary occupied slots.

    A code-free design placement can retain a nonzero generation at NS[14]
    after revocation. W1 alone must never manufacture an extra Thread.
    """
    count, candidate = 1, GENERATED_THREAD_FIRST_NS_SLOT
    while count < MAX_THREAD_COUNT:
        if candidate != ARCH_BOOT["minimalSlots"]["M_BIT_DEV"]:
            if candidate >= slots:
                break
            base = len(words) - (candidate + 1) * NS_ENTRY_WORDS
            location = words[base]
            if (location == 0 or location >= len(words)
                    or ((words[location] >> 27) & 0x1F) != 0x1F
                    or ((words[location] >> 8) & 3) != 2):
                break
            count += 1
        candidate += 1
    return count


# ----- pre-flight validator --------------------------------------------------

def validate_boot_body_ranges(words, physical):
    """Validate physical RAM allocations, independent of NS capability limits.

    An NS limit describes access to a body (often excluding its c-list); it
    does not reserve memory. Serialized LUMP headers establish full body
    allocations; the generator's unloaded fixed catalog rows reserve 64
    zero words each. Device and zero-location symbolic rows have no RAM body.
    """
    total = len(words)
    table = physical["table_base"]
    claims = [(0, NAMESPACE_HEADER_V2_WORDS, "Namespace header"),
              (table, total, "Namespace table")]
    for slot in range(physical["slots"]):
        base = total - (slot + 1) * NS_ENTRY_WORDS
        location, authority = words[base], words[base + 1]
        if location == 0 and authority == 0:
            continue
        if slot == 0:
            if location != physical["start"]:
                raise ValueError("validate_boot_image: NS slot 0 does not name Namespace Header V2")
            continue
        if location == 0 and slot not in _MMIO_SLOT_SPECS:
            # A code-free symbolic row may keep its generation/authority
            # without installing a LUMP. Mandatory residents cannot.
            if slot in _MANDATORY_NS_SLOTS:
                raise ValueError(f"validate_boot_image: mandatory NS slot {slot} has no resident body")
            continue
        if slot in _MMIO_SLOT_SPECS:
            if (location, _ns_word1_get(authority, "limit_offset")) != _MMIO_SLOT_SPECS[slot]:
                raise ValueError(f"validate_boot_image: NS slot {slot} has invalid device MMIO descriptor")
            continue
        if location >= total or location < NAMESPACE_HEADER_V2_WORDS:
            raise ValueError(f"validate_boot_image: NS slot {slot} has out-of-range RAM location {location}")
        header = words[location]
        if header == 0 and slot in (7, 8, 9, 10):
            # Generator reserves a full 64-word catalog slot even when
            # optional catalog residents (CallHome, Tunnel, Ethernet,
            # CapabilityTest) have not been selected/installed yet.
            end = location + SLOT_SIZE
            if end > table or any(words[location:end]):
                raise ValueError(
                    f"validate_boot_image: NS slot {slot} has truncated or nonempty unloaded catalog allocation")
            claims.append((location, end, f"NS slot {slot} unloaded catalog"))
            continue
        if header >> 27 != 0x1f:
            raise ValueError(f"validate_boot_image: NS slot {slot} has invalid or missing LUMP header")
        size = 1 << (((header >> 23) & 15) + 6)
        typ = (header >> 8) & 3
        cw, cc = (header >> 10) & 8191, header & 255
        # typ 00 executable, 01 data (away from the physical NS header),
        # 10 Thread, 11 Outform. Each still occupies its entire allocation.
        if 1 + cw + cc > size:
            raise ValueError(f"validate_boot_image: NS slot {slot} has malformed LUMP header")
        if location + size > table:
            raise ValueError(
                f"validate_boot_image: NS slot {slot} full LUMP allocation "
                f"[{location}, {location + size}) overlaps Namespace header/table or exceeds RAM")
        claims.append((location, location + size, f"NS slot {slot}"))
    claims.sort()
    for left, right in zip(claims, claims[1:]):
        if right[0] < left[1]:
            raise ValueError(
                f"validate_boot_image: {left[2]} [{left[0]}, {left[1]}) "
                f"overlaps {right[2]} [{right[0]}, {right[1]})")


def validate_boot_image(image_bytes, total_namespace_words=None, *, check_layout=True,
                        simulation_only=False, saved_namespace_only=False):
    """Inspect the NS table inside a boot image and raise ValueError early.

    Checks that the format-version tag at mem[ns_table_base - 1] equals
    BOOT_IMAGE_FORMAT_TAG, and that every mandatory NS slot (0, 1,
    and the Namespace-header-selected boot entry are non-zero.  A wrong or zero tag means the
    image was produced by a stale generator and would be rejected by
    loadBootImage() in the simulator; a zeroed mandatory slot causes
    isNSEntryValid() to return false, producing a BOOT fault at runtime.
    Catching both here surfaces version mismatches and slot problems with
    a clear Python-level error before the image ever reaches the harness.

    ``total_namespace_words`` defaults to ``len(image_bytes) // 4``. When an
    explicit configured size is supplied, the image must contain exactly that
    many words; partial overlays and trailing padding are rejected.
    ``check_layout=False`` is only for read-only forensic size reporting:
    it is never an admission check for publication or execution.

    Foundational slots (0, 1, 6=Boot.Abstr) and MMIO device slots
    (2=UART_DEV, 3=LED_DEV, 4=BTN_DEV, 5=TIMER_DEV) are all checked.
    ``simulation_only=True`` admits the private Namespace projection instead:
    only the architectural Namespace, root Thread, and header-selected boot
    target are mandatory. Historical hardware catalog membership is not a
    simulator requirement. All structural, Thread, and allocation checks remain.

    Raises:
        ValueError: if the format-version tag is wrong, any mandatory slot
                    is zeroed, or the image is too small to contain the NS
                    table at all.
    """
    if len(image_bytes) % 4 != 0:
        raise ValueError(
            f"validate_boot_image: image size {len(image_bytes)} bytes is not "
            "a whole number of 32-bit words; regenerate the boot image"
        )
    if total_namespace_words is None:
        total_namespace_words = len(image_bytes) // 4
    total = total_namespace_words
    n_words = len(image_bytes) // 4
    if n_words != total:
        raise ValueError(
            f"validate_boot_image: saved image has {n_words} words, but the "
            f"configured Namespace memory has {total} words; regenerate the "
            "boot image for the current memory configuration"
        )
    words = struct.unpack(f"<{n_words}I", image_bytes[: n_words * 4])

    physical = _locate_namespace_header(words, "validate_boot_image")
    ns_table_base = physical["table_base"]
    ns_table_reserve = physical["table_words"]

    for slot in ((0,) if saved_namespace_only else (0, 1) if simulation_only else _MANDATORY_NS_SLOTS):
        base = n_words - (slot + 1) * NS_ENTRY_WORDS
        if base + 1 >= n_words:
            raise ValueError(
                f"validate_boot_image: image too small to contain NS slot {slot} "
                f"(base={base}, image_words={n_words})"
            )
        word0 = words[base]
        word1 = words[base + 1]
        if word0 == 0 and word1 == 0:
            raise ValueError(
                f"validate_boot_image: mandatory NS slot {slot} is zeroed "
                f"(word0=0x{word0:08x}, word1=0x{word1:08x}); "
                "the boot image is invalid and would cause a BOOT fault at runtime"
            )
    boot_base = n_words - (physical["boot_slot"] + 1) * NS_ENTRY_WORDS if (
        physical["boot_slot"] is not None) else -1
    if boot_base < 0 or boot_base + 1 >= n_words or (
            words[boot_base] == 0 and words[boot_base + 1] == 0):
        raise ValueError("validate_boot_image: Namespace header boot entry is zeroed")

    # A dormant Thread resumes exclusively through the canonical two-word
    # CHURCH frame at STO+1/STO+2: Enter E-GT followed by packed NIA/flags.
    # Retired +18-layout images are rejected by BOOT_IMAGE_FORMAT_TAG above;
    # Heap contents are unconstrained and must never be used as a version
    # heuristic.
    thread_count = _encoded_thread_count(words, physical["slots"])
    ns_capacity = physical["slots"]
    if not saved_namespace_only and not 1 <= thread_count <= MAX_THREAD_COUNT:
        raise ValueError(
            f"validate_boot_image: encoded Thread count {thread_count} is outside "
            f"1..{MAX_THREAD_COUNT}")
    # Thread descriptors are positional: slot 1 is the root and subsequent
    # configured Threads occupy 11, 12, 14, ... .  Do not let a gap (or an
    # extra root-like typ=2 descriptor in an arbitrary slot) disappear from
    # validation merely because the legacy count scanner stops at the first
    # empty slot.
    resident_thread_slots = []
    for slot in range(ns_capacity):
        base = n_words - (slot + 1) * NS_ENTRY_WORDS
        if base < 0:
            continue
        location = words[base]
        if location == 0 or location >= physical["table_base"] or location >= n_words:
            continue
        header_word = words[location]
        if ((header_word >> 27) & 0x1F) == 0x1F and ((header_word >> 8) & 3) == 2:
            resident_thread_slots.append(slot)
    expected_thread_slots = [1]
    candidate_slot = GENERATED_THREAD_FIRST_NS_SLOT
    while len(expected_thread_slots) < thread_count:
        if candidate_slot != ARCH_BOOT["minimalSlots"]["M_BIT_DEV"]:
            expected_thread_slots.append(candidate_slot)
        candidate_slot += 1
    if not saved_namespace_only and resident_thread_slots != expected_thread_slots:
        raise ValueError(
            "validate_boot_image: Thread descriptors have a malformed gap or "
            f"duplicate root (found {resident_thread_slots}, "
            f"expected {expected_thread_slots})")
    # Generic saved-image inspection treats Thread headers exactly like other
    # LUMP headers: the saved descriptor locates them. Hardware remains positional.
    thread_slots = resident_thread_slots if saved_namespace_only else expected_thread_slots
    gt_fields = ARCH_GT_WORD0["fields"]
    gt_type_lsb = field_lsb(gt_fields["gt_type"])
    gt_seq_lsb = field_lsb(gt_fields["gt_seq"])
    gt_slot_lsb = field_lsb(gt_fields["slot_id"])
    for thread_slot in thread_slots:
        tbase = _ns_base = n_words - (thread_slot + 1) * NS_ENTRY_WORDS
        if tbase < 0:
            raise ValueError(f"validate_boot_image: Thread slot {thread_slot} is missing")
        thread_loc = words[tbase]
        # A Thread body can validly begin at physical word zero in a profile
        # whose Namespace header is elsewhere.  Zero is not a null location
        # once its descriptor is populated, so never use truthiness or the
        # V2-header size as a Thread-base validity test.
        if not 0 <= thread_loc < physical["table_base"]:
            raise ValueError(f"validate_boot_image: Thread slot {thread_slot} has invalid location")
        hdr = words[thread_loc]
        size = 1 << (((hdr >> 23) & 0xF) + 6)
        if ((hdr >> 27) & 0x1F) != 0x1F or ((hdr >> 8) & 3) != 2 or thread_loc + size > n_words:
            raise ValueError(f"validate_boot_image: Thread slot {thread_slot} has invalid header")
        layout = thread_layout(size, (hdr >> 10) & 0x1FFF)
        if not layout["valid"]:
            raise ValueError(f"validate_boot_image: Thread slot {thread_slot} has invalid geometry")
        protected = words[thread_loc + THREAD_STO_OFFSET]
        resume_sto = protected & 0xFFF
        if (((protected >> 12) & 1) != 1
                or resume_sto < layout["stack_start"] - 1
                or resume_sto + 2 > layout["stack_end"]):
            raise ValueError(
                f"validate_boot_image: Thread slot {thread_slot} has invalid CHURCH frame STO")
        identity = words[thread_loc + resume_sto + 1]
        packed_resume = words[thread_loc + resume_sto + 2]
        gt_type = (identity >> gt_type_lsb) & _field_mask(gt_fields["gt_type"])
        code_slot = (identity >> gt_slot_lsb) & _field_mask(gt_fields["slot_id"])
        code_seq = (identity >> gt_seq_lsb) & _field_mask(gt_fields["gt_seq"])
        code_ns = n_words - (code_slot + 1) * NS_ENTRY_WORDS
        if (identity == 0 or gt_type != 1 or code_ns < 0 or code_ns + 1 >= n_words):
            raise ValueError(f"validate_boot_image: Thread slot {thread_slot} has stale or invalid CHURCH Enter identity")
        perm_lsb = field_lsb(gt_fields["perm"])
        perm = (identity >> perm_lsb) & _field_mask(gt_fields["perm"])
        dom = (identity >> field_lsb(gt_fields["dom"])) & _field_mask(gt_fields["dom"])
        if dom != 1 or (not (perm & 0b100) if saved_namespace_only else perm != 0b100):
            raise ValueError(f"validate_boot_image: Thread slot {thread_slot} CHURCH frame does not contain an Enter E-GT")
        code_auth = words[code_ns + 1]
        if code_seq != _ns_word1_get(code_auth, "gt_seq"):
            raise ValueError(f"validate_boot_image: Thread slot {thread_slot} has stale CHURCH Enter identity")
        code_loc = words[code_ns]
        code_cw = ((words[code_loc] >> 10) & 0x1FFF) if code_loc < n_words else 0
        resume_nia = (packed_resume >> 13) & 0x7FFF
        if (code_loc >= n_words or ((words[code_loc] >> 27) & 0x1F) != 0x1F
                or code_cw == 0
                or (resume_nia not in (0, 0x7FFF) and
                    (not saved_namespace_only or resume_nia >= code_cw))):
            raise ValueError(f"validate_boot_image: Thread slot {thread_slot} has non-executable CHURCH Enter identity")
        saved_sto = packed_resume & 0xFFF
        if not saved_namespace_only and resume_nia == 0:
            root_sto = layout["stack_end"] - 2
            if (resume_sto != root_sto - 2 or saved_sto != root_sto
                    or words[thread_loc + root_sto + 1] != identity
                    or words[thread_loc + root_sto + 2] !=
                    ((0x7FFF << 13) | (1 << 12) | layout["stack_end"])):
                raise ValueError(f"validate_boot_image: Thread slot {thread_slot} has malformed initial continuation/root")
        if ((packed_resume >> 12) & 1) != 1 or (
                saved_sto < layout["stack_start"] + 1
                or saved_sto > layout["stack_end"]
                or resume_sto != saved_sto - 2):
            raise ValueError(f"validate_boot_image: Thread slot {thread_slot} has malformed CHURCH resume frame")

        # The Enter companion and persisted CR0 home carry the same
        # destination identity.  Permission bits may differ on an intentionally
        # denied home (the CALL gate reports that fault), but a different slot,
        # generation, or type is stale frame state.
        cr0_home = words[thread_loc + layout["caps_start"]]
        if cr0_home and not saved_namespace_only:
            home_type = (cr0_home >> gt_type_lsb) & _field_mask(gt_fields["gt_type"])
            home_slot = (cr0_home >> gt_slot_lsb) & _field_mask(gt_fields["slot_id"])
            home_seq = (cr0_home >> gt_seq_lsb) & _field_mask(gt_fields["gt_seq"])
            if (home_type, home_slot, home_seq) != (gt_type, code_slot, code_seq):
                raise ValueError(
                    f"validate_boot_image: Thread slot {thread_slot} has a stale "
                    "CHURCH Enter companion")

        # CR0 is boot authority only for the fixed Boot.Thread.  It is a
        # persisted capability home, not a boot-time scratch register: the ROM
        # restores it with CHANGE CR12 and CALL consumes it.  Derive the offset
        # from the Thread header rather than assuming the historical 256-word
        # layout (where this happened to be +244).
        if thread_slot == 1 and not saved_namespace_only:
            cr0_index = thread_loc + layout["caps_start"]
            cr0_home = words[cr0_index]
            expected_cr0 = create_gt(
                _ns_word1_get(words[boot_base + 1], "gt_seq"),
                physical["boot_slot"], {"E": 1}, 1)
            if cr0_home == 0:
                raise ValueError(
                    "validate_boot_image: Boot.Thread CR0 home is missing; "
                    "prepare the selected boot target before booting")
            if cr0_home != expected_cr0:
                raise ValueError(
                    "validate_boot_image: Boot.Thread CR0 home is stale or "
                    "does not match the Namespace Header boot target "
                    f"(stored 0x{cr0_home:08x}, expected 0x{expected_cr0:08x})")

    # Do not infer Inform/Outform from any NS word.  State belongs exclusively
    # to access GTs, which are outside this raw table validator.
    if check_layout:
        validate_boot_body_ranges(words, physical)


def read_boot_entry_info(image_bytes):
    """Parse a generated boot image and report its boot-entry state.

    Returns a dict:
        entry_slot   — NS slot stored at mem[ns_table_base - 2] (low byte)
        entry_loc    — word0_location of that slot's NS entry (word index)
        resident     — True when the entry lump body is resident (valid lump
                       header with cw > 0 at entry_loc)
        reason       — human-readable explanation when resident is False
        thread_caps0 — the Boot.Thread CR0-home word derived from its header
        thread_caps_offset — derived CR0 offset within Boot.Thread
        expected_gt  — the E-GT expected for entry_slot
        caps0_ok     — thread_caps0 == expected_gt

    Raises ValueError when the image lacks the BOOT_IMAGE_FORMAT_TAG (stale
    or corrupt image).  Used by the send-to-hardware gate so a boot image
    whose entry lump is not resident is rejected before it reaches the board.
    """
    # Keep this inspection path fail-closed.  In particular, do not turn a
    # missing/stale CR0 home into a freshly minted token merely to describe an
    # imported image.
    validate_boot_image(image_bytes)
    n_words = len(image_bytes) // 4
    words = struct.unpack(f"<{n_words}I", image_bytes[: n_words * 4])

    physical = _locate_namespace_header(words, "read_boot_entry_info")
    entry_slot = physical["boot_slot"]
    if entry_slot is None:
        raise ValueError(
            "read_boot_entry_info: Namespace header boot-entry does not name one NS slot")

    def _ns_base(slot):
        base = n_words - (slot + 1) * NS_ENTRY_WORDS
        if base < 0 or base >= n_words:
            return None
        return base

    def _ns_word0(slot):
        base = _ns_base(slot)
        return words[base] if base is not None else None

    entry_loc = physical["boot_entry"]
    entry_ns_base = _ns_base(entry_slot)
    entry_authority = words[entry_ns_base + 1] if entry_ns_base is not None else 0
    entry_gt_seq = _ns_word1_get(entry_authority, "gt_seq")

    resident = False
    reason = None
    if entry_loc is None:
        reason = f"NS slot {entry_slot} entry is outside the image"
    elif not (0 <= entry_loc < n_words):
        reason = (f"NS slot {entry_slot} location 0x{entry_loc:08X} is outside "
                  f"the image (MMIO or unallocated)")
    else:
        hdr   = words[entry_loc]
        magic = (hdr >> 27) & 0x1F
        cw    = (hdr >> 10) & 0x1FFF
        if magic != 0x1F:
            reason = (f"NS slot {entry_slot} location 0x{entry_loc * 4:08X} does "
                      f"not hold a lump header (word=0x{hdr:08X})")
        elif cw == 0:
            reason = (f"NS slot {entry_slot} lump is a CODE_NOT_RESIDENT stub "
                      f"(cw=0) — body not resident")
        else:
            resident = True

    thread_loc = _ns_word0(1)
    thread_caps0 = 0
    thread_caps_offset = None
    if thread_loc is not None and 0 <= thread_loc < n_words:
        thread_header = words[thread_loc]
        thread_words = 1 << (((thread_header >> 23) & 0xF) + 6)
        thread_layout_info = thread_layout(
            thread_words, (thread_header >> 10) & 0x1FFF)
        if thread_layout_info["valid"]:
            thread_caps_offset = thread_layout_info["caps_start"]
            home_index = thread_loc + thread_caps_offset
            if home_index < n_words:
                thread_caps0 = words[home_index]
    # Thread.caps[0] is a capability for the selected live descriptor, so its
    # generation must match W1[29:21].  Hardcoding sequence zero rejects a
    # valid reissued boot entry and leads to a boot-time VERSION fault.
    expected_gt  = create_gt(entry_gt_seq, entry_slot, {"E": 1}, 1)

    return {
        "entry_slot":   entry_slot,
        "entry_loc":    entry_loc,
        "entry_gt_seq": entry_gt_seq,
        "resident":     resident,
        "reason":       reason,
        "thread_caps0": thread_caps0,
        "thread_caps_offset": thread_caps_offset,
        "expected_gt":  expected_gt,
        "caps0_ok":     thread_caps0 == expected_gt,
    }


def build_wukong_upload_image(generic_image, boot_config=None):
    """Project a generic boot image onto Wukong's physical DMEM layout.

    Generic images use an inverted Namespace table at their tail; Wukong's
    serial uploader writes a complete 16K-word DMEM image from word zero and
    the board reads a forward Namespace table there.  Uploading the generic
    image directly can therefore wrap its 14-bit write address and replace an
    entry LUMP with unrelated words.

    Start from the authoritative Wukong bootstrap layout, copy the selected
    resident LUMP and the configured Thread contexts into the uploaded DMEM
    image, then install their forward Namespace descriptors. Thread bodies
    retain their complete private state; the FPGA does not compile a separate
    per-Thread memory store or a post-boot LUMP transfer engine.
    """
    source_info = read_boot_entry_info(generic_image)
    if not source_info["resident"]:
        raise ValueError(
            "Wukong upload requires a resident executable boot entry: "
            + (source_info["reason"] or "entry body is unavailable")
        )
    if not source_info["caps0_ok"]:
        raise ValueError(
            "Wukong upload requires Thread.caps[0] to match the selected "
            f"entry slot {source_info['entry_slot']}"
        )
    if len(generic_image) % 4:
        raise ValueError("Wukong upload source is not a whole-word image")

    source_words = list(struct.unpack(
        f"<{len(generic_image) // 4}I", generic_image
    ))
    source_total = len(source_words)
    entry_slot = source_info["entry_slot"]
    entry_loc = source_info["entry_loc"]
    if not (0 <= entry_slot < WUKONG_FORWARD_NS_SLOTS):
        raise ValueError(
            f"Wukong supports forward Namespace slots 0–{WUKONG_FORWARD_NS_SLOTS - 1}; "
            f"selected slot {entry_slot} cannot be uploaded"
        )
    if entry_loc is None or not (0 <= entry_loc < source_total):
        raise ValueError("Wukong upload source has no valid selected-entry location")

    entry_header = source_words[entry_loc]
    alloc_words = 1 << (((entry_header >> 23) & 0xF) + 6)
    if entry_loc + alloc_words > source_total:
        raise ValueError(
            f"Wukong upload source truncates selected slot {entry_slot}: "
            f"needs {alloc_words} words from 0x{entry_loc:X}"
        )
    # Wukong has no lazy linker.  A compiler-owned portable row must have been
    # localized in the generic image before projection; the unresolved marker
    # is never safe to upload.  (A zero c-list word remains valid for ordinary
    # non-portable legacy bodies, so only the portable marker is rejected.)
    entry_cc = entry_header & 0xFF
    for _portable_row in source_words[entry_loc + alloc_words - entry_cc:
                                      entry_loc + alloc_words]:
        if (_portable_row & 0xffff0000) == 0xfeed0000:
            raise ValueError(
                "Wukong upload refuses an unresolved portable c-list row; "
                "generate a verified localized boot image first"
            )

    # The generic image commits its Thread count immediately before the
    # format tag. Read that image truth instead of an optional saved config:
    # an image may outlive later editor changes and no context may be dropped.
    source_physical = _locate_namespace_header(
        source_words, "Wukong upload source")
    thread_count = _encoded_thread_count(source_words, source_physical["slots"])
    if thread_count > WUKONG_PHYSICAL_MAX_THREAD_COUNT:
        raise ValueError(
            f"Wukong supports at most {WUKONG_PHYSICAL_MAX_THREAD_COUNT} "
            f"Thread contexts; source image requests {thread_count}"
        )

    thread_slots = (1,) + generated_thread_slots(thread_count)
    if entry_slot in thread_slots:
        raise ValueError(
            f"Wukong boot entry slot {entry_slot} is a Thread context, not an "
            "executable abstraction"
        )

    thread_sources = []
    source_ranges = []
    for number, slot in enumerate(thread_slots, start=1):
        source_ns_base = source_total - (slot + 1) * NS_ENTRY_WORDS
        if source_ns_base < 0 or source_ns_base + NS_ENTRY_WORDS > source_total:
            raise ValueError(
                f"Wukong source Thread.{number} slot {slot} has no Namespace descriptor"
            )
        descriptor = source_words[source_ns_base:source_ns_base + NS_ENTRY_WORDS]
        source_base = descriptor[0]
        if not (0 <= source_base < source_total):
            raise ValueError(
                f"Wukong source Thread.{number} slot {slot} has invalid body location"
            )
        header = source_words[source_base]
        size = 1 << (((header >> 23) & 0xF) + 6)
        if ((header >> 27) & 0x1F) != 0x1F or ((header >> 8) & 0x3) != 2:
            raise ValueError(
                f"Wukong source Thread.{number} slot {slot} is not a Thread LUMP"
            )
        stack_words = (header >> 10) & 0x1FFF
        cap_words = header & 0xFF
        layout = thread_layout(size, stack_words)
        if (size not in THREAD_SUPPORTED_BODY_WORDS or cap_words != THREAD_CAP_WORDS
                or not layout["valid"] or source_base + size > source_total):
            raise ValueError(
                f"Wukong source Thread.{number} slot {slot} has an invalid {size}-word body"
            )
        if any(source_base < end and source_base + size > start
               for start, end, _ in source_ranges):
            raise ValueError(f"Wukong source Thread slot {slot} overlaps another Thread")
        source_ranges.append((source_base, source_base + size, slot))
        thread_sources.append({
            "number": number, "slot": slot, "source_base": source_base,
            "descriptor": descriptor, "size": size,
            "caps0_offset": layout["caps_start"],
        })

    # Lazy import prevents simulator-only generation from requiring FPGA
    # dependencies, while making this projection follow the actual bitstream
    # bootstrap structures rather than a copied server-side layout.
    try:
        from hardware.boot_rom import (
            WUKONG_DEMO_NAMESPACE,
            WUKONG_DEMO_CLIST,
            WUKONG_SELFTEST_BASE_WORD,
            WUKONG_SELFTEST_WORDS,
            WUKONG_CALLHOME_BASE_WORD,
            WUKONG_CAPABILITY_TEST_BASE_WORD,
            WUKONG_CAPABILITY_TEST_WORDS,
            WUKONG_WCH_CLIST_WORD,
            WUKONG_WCH_CLIST,
            WUKONG_NUC_PROGRAM,
            WUKONG_THREAD_BASE_WORD,
            WUKONG_THREAD_HEADER,
            WUKONG_THREAD_STO_WORD,
            WUKONG_THREAD_STO_INIT,
            WUKONG_THREAD_CAPS0_WORD,
            WUKONG_THREAD_CAPS12_WORD,
            GT_TYPE_INFORM,
            PERM_MASK_S,
            make_gt,
            wukong_wch_header,
        )
    except Exception as exc:
        raise ValueError(f"Wukong upload layout is unavailable: {exc}") from exc

    mem = [0] * WUKONG_DMEM_WORDS
    mem[:len(WUKONG_DEMO_NAMESPACE)] = list(WUKONG_DEMO_NAMESPACE)
    mem[256:256 + len(WUKONG_DEMO_CLIST)] = list(WUKONG_DEMO_CLIST)
    mem[WUKONG_SELFTEST_BASE_WORD:
        WUKONG_SELFTEST_BASE_WORD + len(WUKONG_SELFTEST_WORDS)] = list(WUKONG_SELFTEST_WORDS)

    wch_words = [wukong_wch_header(len(WUKONG_NUC_PROGRAM))] + list(WUKONG_NUC_PROGRAM)
    mem[WUKONG_CALLHOME_BASE_WORD:
        WUKONG_CALLHOME_BASE_WORD + len(wch_words)] = wch_words
    mem[WUKONG_WCH_CLIST_WORD:
        WUKONG_WCH_CLIST_WORD + len(WUKONG_WCH_CLIST)] = list(WUKONG_WCH_CLIST)
    mem[WUKONG_CAPABILITY_TEST_BASE_WORD:
        WUKONG_CAPABILITY_TEST_BASE_WORD + len(WUKONG_CAPABILITY_TEST_WORDS)] = list(
            WUKONG_CAPABILITY_TEST_WORDS)

    # Preserve the factory Thread for standalone power-on boot. The uploaded
    # Thread.1 descriptor below replaces it when an IDE image is installed.
    mem[WUKONG_THREAD_BASE_WORD] = WUKONG_THREAD_HEADER
    mem[WUKONG_THREAD_STO_WORD] = WUKONG_THREAD_STO_INIT
    mem[WUKONG_THREAD_CAPS12_WORD] = make_gt(
        GT_TYPE_INFORM, PERM_MASK_S, 1, 0
    )

    # Allocate projected bodies around every factory body whose descriptor will
    # remain live.  The historical upload base is not an allocation boundary:
    # a large active SelfTest can extend across it.  Slots replaced below may
    # donate their old factory ranges, but all other residents are immutable.
    replaced_slots = {entry_slot, *thread_slots}
    occupied = [
        (0, WUKONG_FORWARD_NS_SLOTS * NS_ENTRY_WORDS, "forward Namespace"),
        (256, 256 + len(WUKONG_DEMO_CLIST), "Boot.NS c-list"),
    ]
    for slot in range(WUKONG_FORWARD_NS_SLOTS):
        if slot in replaced_slots:
            continue
        ns_base = slot * NS_ENTRY_WORDS
        location_byte = mem[ns_base]
        if location_byte % 4:
            raise ValueError(f"Wukong factory NS slot {slot} has an unaligned location")
        location = location_byte // 4
        if not (0 < location < WUKONG_DMEM_WORDS):
            continue
        header = mem[location]
        if ((header >> 27) & 0x1F) != 0x1F:
            continue
        size = 1 << (((header >> 23) & 0xF) + 6)
        if location + size > WUKONG_DMEM_WORDS:
            raise ValueError(f"Wukong factory NS slot {slot} body exceeds DMEM")
        occupied.append((location, location + size, f"factory NS slot {slot}"))

    def _claim(size, label):
        for start in range(WUKONG_DMEM_WORDS - size + 1):
            end = start + size
            if all(end <= low or start >= high for low, high, _ in occupied):
                occupied.append((start, end, label))
                return start
        raise ValueError(
            f"Wukong image cannot allocate a disjoint {size}-word {label} body "
            f"within {WUKONG_DMEM_WORDS}-word DMEM")

    # Copy the complete allocation so c-list rows at the LUMP tail survive.
    body_base = _claim(alloc_words, f"uploaded NS slot {entry_slot}")
    mem[body_base:body_base + alloc_words] = source_words[
        entry_loc:entry_loc + alloc_words
    ]

    # Re-seal the selected descriptor against its new byte address.  Its
    # authority and cache token remain those validated in the generic source.
    source_ns_base = source_total - (entry_slot + 1) * NS_ENTRY_WORDS
    source_authority = source_words[source_ns_base + 1]
    source_cache_token = source_words[source_ns_base + 3]
    target_ns_base = entry_slot * NS_ENTRY_WORDS
    body_base_byte = body_base * 4
    mem[target_ns_base + 0] = body_base_byte
    mem[target_ns_base + 1] = source_authority
    mem[target_ns_base + 2] = integrity32(body_base_byte, source_authority)
    mem[target_ns_base + 3] = source_cache_token

    # Materialize the fixed Thread plus the two generated Thread contexts
    # exactly as the IDE saved them. Each body arrives through the ordinary
    # image upload and each forward descriptor is re-sealed for its relocated
    # byte address. No board-side per-thread data RAM is synthesized.
    projected_threads = []
    for item in thread_sources:
        size = item["size"]
        slot = item["slot"]
        thread_target = _claim(size, f"Thread NS slot {slot}")
        source_base = item["source_base"]
        descriptor = item["descriptor"]
        mem[thread_target:thread_target + item["size"]] = source_words[
            source_base:source_base + item["size"]
        ]
        target_ns_base = slot * NS_ENTRY_WORDS
        target_byte = thread_target * 4
        authority = _ns_word1_replace(descriptor[1], "limit_offset", size - 1)
        mem[target_ns_base:target_ns_base + NS_ENTRY_WORDS] = [
            target_byte,
            authority,
            integrity32(target_byte, authority),
            descriptor[3],
        ]
        projected_threads.append({
            "number": item["number"],
            "slot": slot,
            "source_base": source_base,
            "base_word": thread_target,
            "size": size,
            "caps0": source_words[source_base + item["caps0_offset"]],
        })
    dynamic_end = max(end for _, end, _ in occupied)

    # Non-authoritative metadata for the physical scheduler.  The final
    # forward-table W3 belongs to an unoccupied slot and is never consulted for
    # Namespace authority/integrity; the FPGA latches this count while receiving
    # an upload and still validates every selected descriptor through mLoad.
    mem[WUKONG_FORWARD_NS_SLOTS * NS_ENTRY_WORDS - 1] = thread_count

    # The hardware boot ROM calls through this exact capability.
    mem[WUKONG_THREAD_CAPS0_WORD] = source_info["thread_caps0"]

    projected_header = mem[body_base]
    projected_magic = (projected_header >> 27) & 0x1F
    projected_cw = (projected_header >> 10) & 0x1FFF
    if projected_magic != 0x1F or projected_cw == 0:
        raise ValueError(
            f"Wukong projection failed for slot {entry_slot}: "
            f"header=0x{projected_header:08X}, cw={projected_cw}"
        )

    # Fail closed if any live in-DMEM descriptor is truncated, points at a
    # damaged LUMP, or aliases another live resident body.
    live_ranges = []
    for slot in range(WUKONG_FORWARD_NS_SLOTS):
        ns_base = slot * NS_ENTRY_WORDS
        location_byte = mem[ns_base]
        if location_byte % 4:
            raise ValueError(f"Wukong projected NS slot {slot} has an unaligned location")
        location = location_byte // 4
        if slot == 0 or not (0 < location < WUKONG_DMEM_WORDS):
            continue
        header = mem[location]
        if ((header >> 27) & 0x1F) != 0x1F:
            continue
        declared = 1 << (((header >> 23) & 0xF) + 6)
        descriptor_size = _ns_word1_get(mem[ns_base + 1], "limit_offset") + 1
        if (descriptor_size <= 0 or descriptor_size > declared
                or location + declared > WUKONG_DMEM_WORDS):
            raise ValueError(
                f"Wukong projected NS slot {slot} has inconsistent/truncated body")
        for low, high, other in live_ranges:
            if location < high and location + declared > low:
                raise ValueError(
                    f"Wukong projected NS slots {other} and {slot} overlap")
        live_ranges.append((location, location + declared, slot))

    projected = struct.pack(f"<{WUKONG_DMEM_WORDS}I", *mem)
    return projected, {
        "entry_slot": entry_slot,
        "entry_loc": body_base,
        "resident": True,
        "reason": None,
        "thread_caps0": mem[WUKONG_THREAD_CAPS0_WORD],
        "expected_gt": source_info["expected_gt"],
        "caps0_ok": mem[WUKONG_THREAD_CAPS0_WORD] == source_info["expected_gt"],
        "source_entry_loc": entry_loc,
        "source_words": source_total,
        "thread_count": thread_count,
        "thread_contexts": projected_threads,
        "dynamic_end": dynamic_end,
    }


# ----- main generator --------------------------------------------------------

def _ns_n_minus_6(lump_words):
    """log2(lump_words) - 6, clipped to 0..15 (header field is 4 bits).

    lump sizes are validated to be powers of 2 ≥ 64 elsewhere (Step 1
    validator); this is just the bit-width conversion.
    """
    n = 0
    while (1 << (n + 6)) < lump_words and n < 15:
        n += 1
    return n


def _read_lump_body(lumps_dir, token_hex, filename=None):
    """Read raw 32-bit words from lumps_dir.

    When ``filename`` is supplied it is the authoritative locator; failure to
    read it never falls back to a catalog or token-named alias.
    Lump files are stored big-endian on disk (written by build_*_lump.js and
    /api/lumps/save).  Words are returned as native Python ints so they can
    be written directly into mem[] and later packed as little-endian by
    struct.pack('<...I', *mem).
    """
    if filename:
        if not isinstance(filename, str) or os.path.basename(filename) != filename:
            return None
        path = os.path.join(lumps_dir, filename)
        if os.path.isfile(path):
            with open(path, "rb") as f:
                raw = f.read()
            if len(raw) % 4:
                return None
            n = len(raw) // 4
            return list(struct.unpack(f">{n}I", raw))
        return None
    if not token_hex:
        return None
    try:
        with open(os.path.join(lumps_dir, "manifest.json")) as source:
            locators = json.load(source)
        matches = [row.get("filename") for row in locators
                   if isinstance(row, dict)
                   and str(row.get("token", "")).lower() == str(token_hex).lower()
                   and isinstance(row.get("filename"), str)]
        if len(matches) == 1:
            path = os.path.join(lumps_dir, matches[0])
            if os.path.isfile(path):
                with open(path, "rb") as source:
                    raw = source.read()
                if len(raw) % 4:
                    return None
                return list(struct.unpack(f">{len(raw) // 4}I", raw))
    except (OSError, ValueError, TypeError):
        return None
    path = os.path.join(lumps_dir, f"{token_hex}.lump")
    if not os.path.isfile(path):
        return None
    with open(path, "rb") as f:
        raw = f.read()
    n = len(raw) // 4
    return list(struct.unpack(f">{n}I", raw[: n * 4]))


def find_lump_file_by_abstraction(lumps_dir, abstraction_name, ns_slot):
    """Find the canonical lump assigned to a Namespace-state slot.

    Namespace state selects the exact slot/token/filename/hash. Catalog,
    approval-ledger, directory, and token-named guesses are not locators.
    """
    try:
        with open(os.path.join(lumps_dir, "ns-state.json")) as _f:
            _state = json.load(_f)
        for _e in _state.get("abstractions", []):
            if not isinstance(_e, dict) or _e.get("name") != abstraction_name:
                continue
            if _e.get("slot") != ns_slot:
                continue
            _tok = _e.get("token") or _e.get("cache_token")
            _state_filename = _e.get("filename")
            _state_hash = _e.get("binary_hash", _e.get("binaryHash"))
            if (_tok and isinstance(_state_filename, str)
                    and os.path.basename(_state_filename) == _state_filename
                    and isinstance(_state_hash, str)
                    and re.fullmatch(r"[0-9a-fA-F]{64}", _state_hash)):
                _located = os.path.join(lumps_dir, _state_filename)
                if os.path.isfile(_located):
                    with open(_located, "rb") as source:
                        if hashlib.sha256(source.read()).hexdigest() != _state_hash.lower():
                            raise ValueError(
                                f"{abstraction_name} Namespace-selected artifact "
                                "hash does not match its assigned bytes")
                    _require_approved_executable_lump(
                        _located, lumps_dir, abstraction_name)
                    return _located
    except ValueError:
        raise
    except Exception:
        pass
    return None


def _resolve_authoritative_selftest_lump(lumps_dir):
    """Return SelfTest's one live, explicitly-bound executable artifact.

    SelfTest is boot code, so neither a slot-derived filename nor a manifest
    history entry is authority to execute it. Namespace state selects the
    exact filename and SHA-256. Approval validation is deliberately performed
    by the caller on that same path after this binding check.
    """
    try:
        with open(os.path.join(lumps_dir, "ns-state.json"), encoding="utf-8") as source:
            state = json.load(source)
    except (OSError, ValueError, TypeError) as exc:
        raise ValueError(
            f"generate_boot_image: SelfTest authoritative Namespace binding is unreadable: {exc}"
        ) from exc

    state_rows = [
        row for row in state.get("abstractions", []) if isinstance(row, dict)
        and row.get("name") == "SelfTest" and row.get("symbolic") is not True
    ] if isinstance(state, dict) else []
    if len(state_rows) != 1:
        raise ValueError(
            "generate_boot_image: SelfTest requires exactly one authoritative "
            f"Namespace-state binding; found {len(state_rows)}")
    selected = state_rows[0]
    slot = selected.get("slot")
    token = selected.get("token") or selected.get("cache_token")
    filename = selected.get("filename")
    selected_hash = selected.get("binary_hash", selected.get("binaryHash"))
    if (isinstance(slot, bool) or not isinstance(slot, int) or slot < 2
            or not isinstance(token, str) or not token
            or not isinstance(filename, str) or not filename
            or os.path.basename(filename) != filename
            or not isinstance(selected_hash, str)
            or not re.fullmatch(r"[0-9a-fA-F]{64}", selected_hash)):
        raise ValueError(
            "generate_boot_image: SelfTest Namespace-state binding requires its "
            "exact non-foundational slot, token, canonical filename, and hash")
    path = os.path.join(lumps_dir, filename)
    if not os.path.isfile(path):
        raise ValueError(
            f"generate_boot_image: SelfTest Namespace-selected locator {filename} is missing")
    with open(path, "rb") as source:
        actual_hash = hashlib.sha256(source.read()).hexdigest()
    if actual_hash != selected_hash.lower():
        raise ValueError(
            "generate_boot_image: SelfTest Namespace-selected locator hash "
            "does not match the authoritative Namespace binding")
    return path, slot


def _resolve_selected_lump_locator(lumps_dir, slot, token):
    """Resolve one selected slot/token without catalog or alias fallback."""
    normalized = str(token or "").lower()
    if not normalized:
        raise ValueError(
            f"generate_boot_image: resident slot {slot} has no selected token")
    try:
        with open(os.path.join(lumps_dir, "ns-state.json")) as source:
            state = json.load(source)
    except (OSError, ValueError, TypeError) as exc:
        raise ValueError(
            f"generate_boot_image: Namespace state is unreadable: {exc}") from exc
    matches = [
        row for row in state.get("abstractions", [])
        if isinstance(row, dict) and row.get("slot") == slot
        and str(row.get("token") or row.get("cache_token") or "").lower() == normalized
    ]
    if len(matches) > 1:
        raise ValueError(
            f"generate_boot_image: resident slot {slot} has ambiguous Namespace state")
    if matches:
        filename = matches[0].get("filename")
        selected_hash = matches[0].get(
            "binary_hash", matches[0].get("binaryHash"))
        if isinstance(filename, str) and os.path.basename(filename) == filename:
            path = os.path.join(lumps_dir, filename)
            if os.path.isfile(path):
                if (not isinstance(selected_hash, str)
                        or not re.fullmatch(r"[0-9a-fA-F]{64}", selected_hash)):
                    raise ValueError(
                        f"generate_boot_image: resident slot {slot} has no exact "
                        "Namespace-selected artifact hash")
                with open(path, "rb") as source:
                    actual_hash = hashlib.sha256(source.read()).hexdigest()
                if actual_hash != selected_hash.lower():
                    raise ValueError(
                        f"generate_boot_image: Namespace-selected resident slot "
                        f"{slot} artifact hash mismatch")
                return path
            raise ValueError(
                f"generate_boot_image: Namespace-selected resident locator {filename} is missing")
    raise ValueError(
        f"generate_boot_image: resident slot {slot} has no exact "
        "Namespace-selected locator")


def _require_approved_executable_lump(path, lumps_dir, label, bootstrap_binding=None):
    """Return exact words only for a canonically named, hash-approved body.

    ``bootstrap_binding`` is an available owner, not a declaration that every
    resident is bootstrap-authorized. Compiler-attested approvals ignore it;
    only approvals carrying bootstrap T/runtime fields consume and verify it.
    """
    if not path or not os.path.isfile(path):
        raise ValueError(
            f"generate_boot_image: {label} approval-required executable LUMP is missing")
    try:
        with open(path, "rb") as source:
            raw = source.read()
        if len(raw) < 4 or len(raw) % 4:
            raise ValueError("binary length is not a whole number of words")
        words = list(struct.unpack(f">{len(raw) // 4}I", raw))
        header = words[0]
        declared = 1 << (((header >> 23) & 0xF) + 6)
        cw, cc, typ = (header >> 10) & 0x1FFF, header & 0xFF, (header >> 8) & 3
        if ((header >> 27) & 0x1F) != 0x1F or declared != len(words):
            raise ValueError("invalid header or non-exact declared allocation")
        if 1 + cw + cc > declared or typ != 0 or cw == 0:
            raise ValueError("body is not a structurally valid executable LUMP")
        digest = hashlib.sha256(raw).hexdigest()
        approvals = read_approvals(os.path.join(lumps_dir, "approvals.json"))
        approval = approvals.get(digest)
        from server.idx1_profile import validate_execution
        execution = validate_execution(approval or {}, raw)
        if execution is not None:
            raise ValueError("IDX1 boot/hardware preparation is unsupported")
        filename = os.path.basename(path)
        parsed = parse_canonical_filename(filename)
        if approval is None:
            raise ValueError("no compiler admission record matches the exact SHA-256")
        if approval.get("filename") != filename or parsed is None:
            raise ValueError("approval filename is missing or not canonical")
        dot_name, issue_n, number = parsed
        identity_hash = hashlib.sha256(
            f"{dot_name}#{issue_n}".encode("utf-8")).hexdigest()
        bootstrap_record = (
            approval.get("bootstrap_t") is not None
            or approval.get("bootstrap_runtime_gt") is not None)
        compiler_record = False
        if not bootstrap_record:
            try:
                compiler_record = is_trusted_compiler_record(
                    approval, binary=raw,
                    signing_key=compiler_record_verification_key(
                        approval.get("compiler_record")))
            except RuntimeError:
                # Missing compiler TCB configuration cannot turn untrusted
                # bytes into compiler-authoritative bytes.
                compiler_record = False
        # Delivery is a TCB boundary: a display label or approval row alone
        # is not provenance.  Require the server HMAC over this exact raw
        # byte stream before accepting trusted compiler output.
        if not bootstrap_record and not compiler_record:
            raise ValueError(
                "artifact lacks authenticated compiler or bootstrap provenance")
        if ((not bootstrap_record and not compiler_record
             and compute_number(dot_name, raw) != number)
                or approval.get("dot_name") != dot_name
                or approval.get("issue_n") != issue_n
                or (not bootstrap_record and not compiler_record
                    and approval.get("identity_hash") != identity_hash)):
            raise ValueError("compiler/approval canonical identity does not match bytes")
        if bootstrap_record:
            if bootstrap_binding is None:
                raise ValueError("bootstrap approval has no authoritative Namespace owner")
            cc = words[0] & 0xff
            if cc < 1:
                raise ValueError("bootstrap approval requires c-list row-0 SELF GT")
            row0 = words[len(words) - cc]
            verify_bootstrap_self_gt(
                bootstrap_binding,
                row0, approval.get("bootstrap_t"))
            if row0 != approval.get("bootstrap_runtime_gt"):
                raise ValueError("bootstrap approval runtime GT disagrees with c-list row 0")
        return words
    except (OSError, ValueError) as exc:
        raise ValueError(
            f"generate_boot_image: {label} exact hash-bound approval required: {exc}") from exc

def materialize_compiler_self(raw, binding, lumps_dir, label):
    """Bind intrinsic SELF only from exact authenticated compiler bytes.

    Return a private derivative. Already-bound SELF must match the destination;
    neither an arbitrary placeholder nor an old destination is repairable.
    """
    from pathlib import Path
    slot, sequence = binding.get("slot"), binding.get("seq")
    if (type(slot) is not int or not 0 <= slot <= 65535
            or type(sequence) is not int or not 0 <= sequence <= 511):
        raise ValueError(f"{label}: invalid destination slot/sequence")
    words = list(struct.unpack(f">{len(raw) // 4}I", raw))
    cc = words[0] & 255
    expected = create_gt(sequence, slot, {"E": 1}, 1)
    if not cc or cc >= len(words):
        raise ValueError(f"{label}: requires a complete SELF row zero")
    if words[-cc] == expected:
        return raw, expected
    if words[-cc] != 0xFEED5E1F:
        raise ValueError(
            f"{label}: immutable SELF differs from destination GT. "
            "Select an artifact bound to this slot/sequence or recompile it; "
            "stored artifacts and image are unchanged.")
    try:
        digest = hashlib.sha256(raw).hexdigest()
        if digest != (binding.get("binary_hash") or binding.get("binaryHash")):
            raise ValueError("selected artifact hash differs from exact bytes")
        filename = binding.get("filename")
        if not isinstance(filename, str) or os.path.basename(filename) != filename:
            raise ValueError("requires an exact selected filename")
        path = Path(lumps_dir) / filename
        if path.is_symlink():
            raise ValueError("mutable artifact alias is not an exact saved file")
        exact = _require_approved_executable_lump(str(path), lumps_dir, label, binding)
        if exact != words:
            raise ValueError("selected bytes changed during SELF verification")
        approval = read_approvals(os.path.join(lumps_dir, "approvals.json")).get(digest)
        if not is_trusted_compiler_record(
                approval, binary=raw,
                signing_key=compiler_record_verification_key(approval.get("compiler_record"))):
            raise ValueError("intrinsic SELF requires authenticated compiler evidence")
    except (ValueError, RuntimeError, OSError) as exc:
        raise ValueError(
            f"{label}: cannot materialize compiler SELF: {exc}. "
            "Restore the exact saved artifact and its authenticated compiler evidence, "
            "or recompile and explicitly select the new revision, then prepare again. "
            "Stored artifacts and image are unchanged.") from exc
    words[-cc] = expected
    return struct.pack(f">{len(words)}I", *words), expected


def parse_ns_table(image_bytes):
    """Parse the NS table from a boot image binary.

    Returns canonical authority/integrity fields. Entry state is intentionally
    absent: it belongs to the access GT, not to an NS word.
    Returns [] when the image is unrecognisable.
    """
    n_words = len(image_bytes) // 4
    if n_words < 16:
        return []
    mem = list(struct.unpack(f"<{n_words}I", image_bytes[: n_words * 4]))

    try:
        physical = _locate_namespace_header(mem, "parse_ns_table")
    except ValueError:
        return []
    total            = n_words

    # Read stored nsCount from tag_idx - 2 (= NS_TABLE_BASE - 3).
    max_entries         = physical["slots"]
    stored_count_idx    = physical["start"] - 2
    if 0 <= stored_count_idx < total:
        _sc = mem[stored_count_idx] & 0xFFFF
        ns_count = _sc if 0 < _sc <= max_entries else max_entries
    else:
        ns_count = max_entries

    entries = []
    for slot in range(ns_count):
        base = total - (slot + 1) * NS_ENTRY_WORDS
        if base < 0 or base + 3 >= total:
            break
        w0 = mem[base + 0]
        w1 = mem[base + 1]
        w2 = mem[base + 2]
        if w0 == 0 and w1 == 0:
            continue  # unoccupied slot
        entries.append({
            "slot":        slot,
            "location":    w0,
            "f":           _ns_word1_get(w1, "f_flag"),
            "g":           _ns_word1_get(w1, "g_bit"),
            "limit17":     _ns_word1_get(w1, "limit_offset"),
            "seq":         _ns_word1_get(w1, "gt_seq"),
            "integrity32": w2,
            "integrity_ok": w2 == integrity32(w0, w1),
        })
    return entries
def parse_ns_table_raw(image_bytes):
    """Authoritative raw view of the committed NS table for the design page.

    Returns None when the image is unrecognisable, otherwise:
      { "totalWords": int, "maxEntries": int, "nsTableBase": int,
        "header": {"n_minus_6": int, "cw": int, "cc": int, "typ": int} | None,
        "entries": [ {"slot": int, "w0": int, "w1": int, "w2": int, "w3": int}, ... ] }

    entries contains every occupied slot's four raw words exactly as stored
    in boot-image.bin (little-endian words); header decodes the NS lump
    header word at word 0 when it carries the 0x1F magic.
    """
    n_words = len(image_bytes) // 4
    if n_words < 16:
        return None
    mem = list(struct.unpack(f"<{n_words}I", image_bytes[: n_words * 4]))

    try:
        physical = _locate_namespace_header(mem, "parse_ns_table_raw")
    except ValueError:
        return None
    total            = n_words
    ns_table_base = physical["table_base"]
    max_entries = physical["slots"]

    # The Namespace header is physical at word zero. Thread.1 is found through
    # its fixed Namespace descriptor.
    header = None
    _thread_ns_base = total - 2 * NS_ENTRY_WORDS
    _thread_loc = mem[_thread_ns_base] if _thread_ns_base >= ns_table_base else -1
    hdr = mem[_thread_loc] if 0 <= _thread_loc < total else 0
    if (hdr >> 27) & 0x1F == 0x1F:
        header = {
            "kind":      "thread",   # header at word 0 belongs to Thread.1
            "n_minus_6": (hdr >> 23) & 0xF,
            "cw":        (hdr >> 10) & 0x1FFF,
            "typ":       (hdr >> 8) & 0x3,
            "cc":        hdr & 0xFF,
        }
    # Thread.1 memory-truth block: raw header word, the CR0 boot-entry GT at
    # its tail-relative capability-home zone, the boot-entry sentinel, and the
    # committed thread count (sentinel at ns_table_base-4; 0 ⇒ legacy 1).
    thread_block = None
    if header is not None and header["kind"] == "thread":
        _t_size = 1 << (header["n_minus_6"] + 6)
        _t_cnt  = _encoded_thread_count(mem, physical["slots"])
        _t_layout = thread_layout(_t_size, header["cw"])
        _cr0_idx = _t_layout["caps_start"] if _t_layout["valid"] else _t_size
        thread_block = {
            "headerWord": hdr,
            "size":       _t_size,
            "cr0Word":    (mem[_thread_loc + _cr0_idx]
                           if 0 <= _thread_loc + _cr0_idx < n_words else 0),
            "capsOffset": _cr0_idx,
            "count":      _t_cnt if _t_cnt >= 1 else 1,
            "bootSlot":   physical["boot_slot"],
        }

    ns_header = {
        "slots":     physical["slots"],
        "n_minus_13": physical["n_minus_13"],
        "cw":        physical["slots"],
        "typ":       1,
        "cc":        0,
        "word":      mem[physical["start"]],
        "physicalWord": physical["start"],
        "base": 0, "tableOffset": ns_table_base,
        "bootSlot": physical["boot_slot"], "bootEntry": physical["boot_entry"],
        "sealBoundary": ns_table_base,
    }

    entries = []
    for slot in range(max_entries):
        base = total - (slot + 1) * NS_ENTRY_WORDS
        if base < 0 or base + 3 >= total:
            break
        w0, w1, w2, w3 = mem[base], mem[base + 1], mem[base + 2], mem[base + 3]
        if w0 == 0 and w1 == 0:
            continue
        entries.append({"slot": slot, "w0": w0, "w1": w1, "w2": w2, "w3": w3})

    return {
        "totalWords":  total,
        "maxEntries":  max_entries,
        "nsTableBase": ns_table_base,
        "header":      header,
        "nsHeader":    ns_header,
        "thread":      thread_block,  # Thread.1 memory-truth block (may be None)
        "entries":     entries,
    }


def _load_ns_state_token_map(lumps_dir):
    """ns-state.json → slot→token map used by the boot image generator.

    New format (abstractions is a list of rich dicts): use entry["slot"] and
    resolve the token by name from the manifest.  Hardware MMIO slots (2-5)
    have no manifest token and are skipped for token resolution.

    Old flat-name format (abstractions is a list of strings): derive slot
    placement from manifest ns_slot fields (backward compatibility).

    Old slot-keyed format ({"slots": {...}}): returned directly.
    """
    _path = os.path.join(lumps_dir, "ns-state.json")
    if not os.path.isfile(_path):
        return {}
    try:
        with open(_path) as _f:
            _state = json.load(_f)
        # Backward-compat: very old slot-keyed format.
        if "slots" in _state and "abstractions" not in _state:
            _slots = _state.get("slots") or {}
            return {int(k): str(v) for k, v in _slots.items()
                    if str(k).lstrip("-").isdigit() and v}

        _abstractions = _state.get("abstractions") or []
        if not _abstractions:
            return {}

        out = {}

        # New rich-dict format: each element is {"name", "slot", ...}.
        if _abstractions and isinstance(_abstractions[0], dict):
            for _entry in _abstractions:
                _slot = _entry.get("slot")
                if not isinstance(_slot, int):
                    continue
                _token = _entry.get("token") or _entry.get("cache_token")
                if _token:
                    out[_slot] = str(_token).lower()
            return out

        # Flat-name state has no explicit slot and therefore cannot safely
        # establish Namespace membership.  It is intentionally not promoted
        # from the manifest's historical ns_slot fields.
        return out
    except Exception:
        return {}


def _load_ns_state_sequence_map(lumps_dir):
    """Return retained Namespace generations keyed by slot.

    Rebuilding a boot image replaces bytes, not Namespace identities.  The
    authoritative sequence therefore comes from ns-state.json and must be
    carried into both the descriptor and every GT minted for that slot.
    """
    try:
        with open(os.path.join(lumps_dir, "ns-state.json")) as state_file:
            state = json.load(state_file)
        result = {}
        for entry in state.get("abstractions", []):
            if not isinstance(entry, dict):
                continue
            slot = entry.get("slot")
            sequence = entry.get("seq")
            if (isinstance(slot, int) and isinstance(sequence, int)
                    and not isinstance(sequence, bool)
                    and 0 <= sequence <= 0x1FF):
                result[slot] = sequence
        return result
    except Exception:
        return {}


def generated_thread_assignment(row, config=None):
    """Whether an existing assignment is supplied by the saved Thread design.

    Never infer membership from a pet name, and never replace a selected file
    (including a malformed locator) with generated bytes.
    """
    if (not isinstance(row, dict) or row.get("archived") is True
            or row.get("symbolic") is True or row.get("implementationMissing") is True
            or row.get("filename") is not None):
        return False
    if row.get("type") == "Thread":
        return True
    step = (config or {}).get("step1", {})
    if "threadCount" not in step:
        return False
    slots = (1,) + generated_thread_slots(configured_thread_count(step))
    return row.get("type") == "Inform" and row.get("slot") in slots


def image_artifact_selected(row, config=None):
    """Whether the approved assignment selects a saved body for this image.

    Assignment/filename alone is not residency. The boot marker selects the
    entry body; other bodies require an explicit resident policy. Generated
    Namespace/Thread/MMIO objects are handled by their own constructors.
    """
    if (not isinstance(row, dict) or row.get("archived") is True
            or row.get("symbolic") is True
            or row.get("implementationMissing") is True
            or row.get("type") in ("Device", "Namespace")
            or generated_thread_assignment(row, config)):
        return False
    if row.get("type") == "Thread" and row.get("filename") is not None:
        return True
    if row.get("boot") is True:
        return True
    policy = row.get("load_policy", row.get("loadPolicy"))
    if policy is not None:
        return policy == "Resident"
    return row.get("resident") is True or row.get("boot_resident") is True


def copy_selected_image_inputs(lumps_dir, destination, rows, config=None):
    """Stage selected bodies only, never read/copy dormant library artifacts."""
    import shutil
    from pathlib import Path
    source, stage = Path(lumps_dir), Path(destination)
    stage.mkdir(parents=True)
    for name in ("manifest.json", "approvals.json"):
        shutil.copy2(source / name, stage / name)
    copied = set()
    for row in rows:
        if not image_artifact_selected(row, config):
            continue
        filename = row.get("filename")
        if (not isinstance(filename, str) or not filename
                or os.path.basename(filename) != filename):
            raise ValueError(f"NS[{row.get('slot')}] selected body has no exact filename")
        if filename in copied:
            continue
        shutil.copy2(source / filename, stage / filename)
        sidecar = Path(filename).with_suffix(".json")
        if (source / sidecar).is_file():
            shutil.copy2(source / sidecar, stage / sidecar)
        copied.add(filename)


def _load_catalog_token_map(manifest_path, selected_by_slot=None, config=None):
    """Return slot→token from Namespace state only.

    The manifest remains a filename/catalog lookup only.  It must never create
    membership or assign a token to a slot.  ``selected_by_slot`` is retained
    as a compatibility argument for callers, but deliberately ignored: a
    separately writable boot-config cannot retarget an image plan.
    """
    lumps_dir = os.path.dirname(manifest_path)
    with open(os.path.join(lumps_dir, "ns-state.json"), encoding="utf-8") as source:
        rows = json.load(source)["abstractions"]
    selected_slots = {row["slot"] for row in rows if image_artifact_selected(row, config)}
    return {slot: token for slot, token in _load_ns_state_token_map(lumps_dir).items()
            if slot in selected_slots}


def _load_trusted_cache_token_map(manifest_path, config=None):
    """Return slot→cache_token32 for canonical, fully verified lump records.

    The exact hash-bound approval is the trusted full-identity source. W3 only
    receives its issue-blind 32-bit cache value after the exact on-disk bytes
    satisfy the same resolver checks as ``GET /api/lump/<token>``.  Legacy or
    incomplete records intentionally produce W3=0 rather than learning trust
    from the bytes during image generation.
    """
    lumps_dir = os.path.dirname(manifest_path)
    # Rich ns-state is the authoritative current slot assignment.  Do not
    # merge stale manifest ns_slot aliases into it: that could place a valid
    # token for one abstraction into a slot now owned by another abstraction.
    slot_tokens = _load_ns_state_token_map(lumps_dir)
    try:
        with open(os.path.join(lumps_dir, "ns-state.json"), "r") as f:
            state = json.load(f)
    except Exception:
        return {}
    rows_by_slot = {
        row["slot"]: row for row in state.get("abstractions", [])
        if isinstance(row, dict) and isinstance(row.get("slot"), int)
    } if isinstance(state, dict) else {}

    trusted = {}
    for slot, token_hex in slot_tokens.items():
        if not image_artifact_selected(rows_by_slot.get(slot), config):
            continue
        token = str(token_hex or "").strip().lower()
        if len(token) != 8:
            continue
        try:
            token_value = int(token, 16)
        except ValueError:
            continue
        selected = rows_by_slot.get(slot)
        filename = selected.get("filename") if isinstance(selected, dict) else None
        selected_hash = selected.get(
            "binary_hash", selected.get("binaryHash")
        ) if isinstance(selected, dict) else None
        if (not isinstance(filename, str)
                or os.path.basename(filename) != filename
                or not isinstance(selected_hash, str)
                or not re.fullmatch(r"[0-9a-fA-F]{64}", selected_hash)):
            continue
        try:
            with open(os.path.join(lumps_dir, filename), "rb") as f:
                raw = f.read()
        except OSError:
            continue
        if hashlib.sha256(raw).hexdigest() != selected_hash.lower():
            continue
        try:
            selected_approval = read_approvals(
                os.path.join(lumps_dir, "approvals.json")).get(
                    selected_hash.lower())
        except (OSError, ValueError, TypeError):
            continue
        # Frozen bootstrap owners receive W3 from their already-verified
        # runtime SELF GT later in generation. This map is only for ordinary
        # compiler-attested cache identities.
        if (isinstance(selected_approval, dict)
                and (selected_approval.get("bootstrap_t") is not None
                     or selected_approval.get("bootstrap_runtime_gt") is not None)
                and selected_approval.get("portable_binding") is None):
            continue
        try:
            _require_approved_executable_lump(
                os.path.join(lumps_dir, filename), lumps_dir,
                f"resident slot {slot}", selected)
        except ValueError:
            continue
        trusted[int(slot)] = token_value & 0xFFFFFFFF
    return trusted


def _load_boot_resident_entries(manifest_path, selected_by_slot=None,
                                profile_name=None, config=None):
    """Return exact resident artifact bindings from committed Namespace state.

    Manifest history must never choose which artifact occupies a live slot.
    A rich Namespace entry without an exact token is therefore unbound, not an
    invitation to guess the newest matching filename or manifest record.
    """
    lumps_dir = os.path.dirname(manifest_path)
    try:
        with open(os.path.join(lumps_dir, "ns-state.json")) as f:
            state = json.load(f)
    except Exception:
        return []
    out = []
    # ``residentProfile`` was a legacy fixed identity/slot policy.  Resident
    # selection is now wholly owned by the Namespace rows below: only rows
    # carrying an exact token and filename are eligible.  Keep the parameter
    # for source compatibility with older callers, but never use it to
    # manufacture or adjudicate bindings.
    for e in state.get("abstractions", []) if isinstance(state, dict) else []:
        if not isinstance(e, dict) or e.get("type") not in ("Inform", "Resident"):
            continue
        slot = e.get("slot")
        tok  = e.get("token") or e.get("cache_token")
        if not isinstance(slot, int):
            continue
        if not image_artifact_selected(e, config):
            continue
        if not tok or not isinstance(e.get("filename"), str) or not e["filename"]:
            raise ValueError(f"generate_boot_image: selected resident NS[{slot}] has no exact artifact locator")
        out.append((
            slot,
            str(tok).lower(),
            e.get("filename"),
            int(e.get("lump_version") or e.get("issue_n") or 0),
        ))
    chosen = {}
    for slot, tok, filename, version in out:
        if slot not in chosen:
            chosen[slot] = (slot, tok, filename, int(version or 0))
        elif int(version or 0) >= chosen[slot][3]:
            chosen[slot] = (slot, tok, filename, int(version or 0))
    return [(slot, tok, filename) for slot, tok, filename, _version in chosen.values()]


def validate_resident_artifact_bindings(
        image_bytes, lumps_dir, require_provenance_image_digest=True,
        ns_state_path=None):
    """Require each Namespace-selected resident artifact to match the image.

    The Namespace descriptor does not serialize a filename, so exact binding is
    established by the selected slot/sequence plus the complete approved LUMP
    allocation at that slot.  This deliberately does not regenerate a composite:
    callers can reject an old image even when an unrelated artifact currently
    prevents regeneration.
    """
    validate_boot_image(image_bytes)
    n_words = len(image_bytes) // 4
    image_words = struct.unpack(f"<{n_words}I", image_bytes)
    provenance_path = os.path.join(lumps_dir, "boot-image.provenance.json")
    try:
        with open(provenance_path, encoding="utf-8") as provenance_file:
            provenance = json.load(provenance_file)
        image_digest = hashlib.sha256(image_bytes).hexdigest()
        generic_refresh = (
            isinstance(provenance, dict)
            and provenance.get("origin") == "generic-refresh"
            and provenance.get("profile") == "clean-saved-namespace-v1"
            and provenance.get("purpose") == "generic-simulator-image"
            and provenance.get("status") == "committed"
            and provenance.get("committed") is True
        )
        if (not isinstance(provenance, dict)
                or (provenance.get("version") != 1 and not generic_refresh)
                or (require_provenance_image_digest
                    and provenance.get("image_sha256") != image_digest)):
            raise ValueError("generation provenance does not authenticate this boot image")
        binding_rows = provenance.get(
            "artifactBindings" if generic_refresh else "resident_bindings", [])
        if (not isinstance(binding_rows, list)
                or any(not isinstance(row, dict)
                       or type(row.get("slot")) is not int for row in binding_rows)
                or len({row["slot"] for row in binding_rows}) != len(binding_rows)):
            raise ValueError("generation provenance has invalid or duplicate resident bindings")
        provenance_by_slot = {
            row["slot"]: row for row in binding_rows
        }
    except (OSError, ValueError, TypeError) as exc:
        raise ValueError(f"boot image generation provenance is unavailable: {exc}") from exc
    try:
        with open(ns_state_path or os.path.join(lumps_dir, "ns-state.json"), encoding="utf-8") as state_file:
            state = json.load(state_file)
    except (OSError, ValueError, TypeError) as exc:
        raise ValueError(f"resident binding inventory is unavailable: {exc}") from exc
    entries = state.get("abstractions") if isinstance(state, dict) else None
    validate_namespace_rows(entries)
    if provenance.get("namespace_fingerprint") != namespace_fingerprint(entries):
        raise ValueError(
            "Boot image Namespace revision differs from the approved Namespace "
            "or its revision provenance is missing; review and explicitly prepare "
            "an image from the current Namespace. No state was changed.")
    state_by_slot = {
        row["slot"]: row for row in state.get("abstractions", [])
        if isinstance(row, dict) and isinstance(row.get("slot"), int)
    }
    bindings = [
        row for row in state_by_slot.values()
        if image_artifact_selected(row)
        and (row.get("filename") or row.get("token") or row.get("cache_token"))
    ]
    for binding in bindings:
        slot = binding["slot"]
        filename = binding.get("filename")
        if not isinstance(filename, str) or not filename:
            raise ValueError(
                f"Namespace-selected resident NS slot {slot} has no exact artifact filename")
        artifact_path = os.path.realpath(os.path.join(lumps_dir, filename))
        if not artifact_path.startswith(os.path.realpath(lumps_dir) + os.sep):
            raise ValueError(
                f"Namespace-selected resident NS slot {slot} artifact path is invalid")
        try:
            with open(artifact_path, "rb") as lump_file:
                raw = lump_file.read()
            if not raw or len(raw) % 4:
                raise ValueError("artifact is empty or not word-aligned")
            expected = struct.unpack(f">{len(raw) // 4}I", raw)
        except (OSError, ValueError, struct.error) as exc:
            raise ValueError(
                f"Namespace-selected resident NS slot {slot} artifact "
                f"{filename!r} is unavailable: {exc}") from exc
        selected_hash = binding.get("binary_hash", binding.get("binaryHash"))
        artifact_digest = hashlib.sha256(raw).hexdigest()
        if selected_hash and artifact_digest != str(selected_hash).lower():
            raise ValueError(
                f"Namespace-selected resident NS slot {slot} artifact hash no longer "
                "matches the committed selection")
        generation_binding = provenance_by_slot.get(slot)
        if (generation_binding is None
                or generation_binding.get(
                    "binaryHash" if generic_refresh else "artifact_sha256") != artifact_digest
                or generation_binding.get("filename") != filename):
            raise ValueError(
                f"resident NS slot {slot} selected artifact changed since this "
                "boot image was generated")
        ns_base = n_words - (slot + 1) * NS_ENTRY_WORDS
        if ns_base < 0 or ns_base + 1 >= n_words:
            raise ValueError(f"resident NS slot {slot} is absent from the boot image")
        location, authority = image_words[ns_base], image_words[ns_base + 1]
        selected_seq = int(state_by_slot.get(slot, {}).get("seq", 0))
        image_seq = _ns_word1_get(authority, "gt_seq")
        if image_seq != selected_seq:
            raise ValueError(
                f"resident NS slot {slot} sequence is stale "
                f"(image {image_seq}, selected {selected_seq})")
        if location < NAMESPACE_HEADER_V2_WORDS or location + len(expected) > n_words:
            raise ValueError(f"resident NS slot {slot} has an invalid image location")
        actual = image_words[location:location + len(expected)]
        image_cc = image_words[location] & 0xFF
        # A capability limit restricts access; it is not the allocated body.
        # Compare the full header allocation even for deliberately short limits.
        image_allocation = 1 << (((image_words[location] >> 23) & 0xF) + 6)
        if image_allocation != len(expected):
            raise ValueError(
                f"resident NS slot {slot} allocation is stale "
                f"(image {image_allocation} words, selected artifact {len(expected)} words)")
        # C-list rows are localized for the destination image (SelfTest.Next,
        # portable capability bindings). Header + code/data words remain the
        # immutable artifact payload and are sufficient to reject an older
        # saved program without misclassifying legitimate localization.
        immutable_words = 1 + ((expected[0] >> 10) & 0x1FFF)
        if tuple(actual[:immutable_words]) != tuple(expected[:immutable_words]):
            raise ValueError(
                f"resident NS slot {slot} does not contain the currently selected "
                f"artifact {filename!r}; regenerate the boot image")
        localized_rows = actual[len(expected) - image_cc:] if image_cc else ()
        localized_digest = hashlib.sha256(struct.pack(
            f"<{len(localized_rows)}I", *localized_rows)).hexdigest()
        if generic_refresh:
            # Refresh evidence binds the entire destination-localized LUMP,
            # serialized in canonical big-endian artifact order.
            derivative_digest = hashlib.sha256(struct.pack(
                f">{len(actual)}I", *actual)).hexdigest()
            if generation_binding.get("derivativeHash") != derivative_digest:
                raise ValueError(
                    f"resident NS slot {slot} localized artifact does not match "
                    "the authenticated refresh provenance")
        elif generation_binding.get("localized_clist_sha256") != localized_digest:
            raise ValueError(
                f"resident NS slot {slot} localized capability rows do not match "
                "the authenticated generation provenance")
    return True


def build_boot_image_provenance(image_bytes, lumps_dir, ns_state_path=None):
    """Bind a generated image to exact selected artifacts and localized rows.

    ``ns_state_path`` permits the boot transaction to bind provenance to its
    staged authoritative state file when test/deployment storage separates
    state from the artifact library.
    """
    validate_boot_image(image_bytes)
    n_words = len(image_bytes) // 4
    image_words = struct.unpack(f"<{n_words}I", image_bytes)
    state_path = ns_state_path or os.path.join(lumps_dir, "ns-state.json")
    with open(state_path, encoding="utf-8") as state_file:
        state = json.load(state_file)
    entries = state.get("abstractions") if isinstance(state, dict) else None
    validate_namespace_rows(entries)
    rows = []
    for binding in state.get("abstractions", []):
        if (not image_artifact_selected(binding)
                or not isinstance(binding.get("slot"), int)
                or binding.get("type") not in ("Inform", "Resident")):
            continue
        filename = binding.get("filename")
        if not isinstance(filename, str) or not filename:
            continue
        slot = binding["slot"]
        artifact_path = os.path.realpath(os.path.join(lumps_dir, filename))
        if not artifact_path.startswith(os.path.realpath(lumps_dir) + os.sep):
            raise ValueError(f"resident NS slot {slot} artifact path is invalid")
        with open(artifact_path, "rb") as artifact_file:
            raw = artifact_file.read()
        if not raw or len(raw) % 4:
            raise ValueError(
                f"resident NS slot {slot} artifact is empty or not word-aligned")
        expected_words = len(raw) // 4
        ns_base = n_words - (slot + 1) * NS_ENTRY_WORDS
        if ns_base < 0 or ns_base + 1 >= n_words:
            raise ValueError(f"resident NS slot {slot} is absent from the boot image")
        location = image_words[ns_base]
        if location < NAMESPACE_HEADER_V2_WORDS or location + expected_words > n_words:
            raise ValueError(f"resident NS slot {slot} has an invalid image location")
        image_cc = image_words[location] & 0xFF
        localized_rows = image_words[
            location + expected_words - image_cc:location + expected_words
        ] if image_cc else ()
        rows.append({
            "slot": slot,
            "filename": filename,
            "artifact_sha256": hashlib.sha256(raw).hexdigest(),
            # A prepared target is bound to the exact immutable artifact and
            # deployment policy that supplied this committed body.  Preserve
            # these state-side identities in provenance so a later selection
            # patch cannot retarget an image after its state row was rewritten.
            "token": binding.get("token") or binding.get("cache_token"),
            "load_policy": binding.get(
                "load_policy", binding.get("loadPolicy")),
            "resident": binding.get("resident"),
            "boot_resident": binding.get("boot_resident"),
            "ns_slot_policy": binding.get("ns_slot_policy"),
            "localized_clist_sha256": hashlib.sha256(struct.pack(
                f"<{len(localized_rows)}I", *localized_rows)).hexdigest(),
        })
    return {
        "version": 1,
        "image_sha256": hashlib.sha256(image_bytes).hexdigest(),
        "namespace_fingerprint": namespace_fingerprint(entries),
        "resident_bindings": sorted(rows, key=lambda row: row["slot"]),
    }


_NO_PREPARED_THREAD_IMAGE = object()


def generate_boot_image(cfg, lumps_dir, boot_entry_slot=None,
                        require_entry_resident=False, *,
                        prepared_thread_image=_NO_PREPARED_THREAD_IMAGE):
    """Hardware/publication generator: compiler admission is mandatory."""
    image = _generate_boot_image(
        cfg, lumps_dir, boot_entry_slot, require_entry_resident,
        _require_approved_executable_lump)
    if prepared_thread_image is not _NO_PREPARED_THREAD_IMAGE:
        from server.prepared_thread_entries import preserve_prepared_entries
        image = preserve_prepared_entries(image, prepared_thread_image, cfg, lumps_dir)
    return image


def generate_simulation_image(cfg, lumps_dir, boot_entry_slot=None):
    """Private simulator generation; never confers hardware admission."""
    from server.simulation_preparation import validate_simulation_executable
    return _generate_boot_image(
        cfg, lumps_dir, boot_entry_slot, True, validate_simulation_executable,
        honor_namespace_layout=True)


def _generate_boot_image(cfg, lumps_dir, boot_entry_slot,
                         require_entry_resident, executable_validator,
                         honor_namespace_layout=False):
    """Produce the binary boot image bytes for the given config dict.

    `cfg` must already be Step-1 valid (target board + step1 fields).
    Step 2 / Step 3 are optional. Returns a `bytes` object whose length
    is `step1.totalNamespaceWords * 4`.

    `boot_entry_slot` – NS slot the boot ROM will jump to (default: the
    authoritative SelfTest Namespace-state slot).

    `require_entry_resident` – when True (hardware-targeted images, e.g. Wukong
    bridge uploads), the selected boot-entry lump's code body MUST be resident
    in the image; a lazy stub or missing body raises ValueError instead of
    producing an image that faults on the board's first fetch.  When False
    (simulator images), a non-resident entry is permitted because the simulator
    can lazy-fetch the body at runtime.
    """
    step1 = cfg["step1"]
    total       = int(step1["totalNamespaceWords"])
    ns_size     = int(step1["namespaceLumpWords"])
    thread_size = int(step1["threadLumpWords"])
    thread_stack_words = int(step1.get("threadStackWords", 32))
    layout = thread_layout(thread_size, thread_stack_words)
    if not layout["valid"]:
        raise ValueError("generate_boot_image: Thread geometry does not conform "
                         "to the normative Thread design")

    # Dynamic NS table reserve (Task #1244): size follows configured slot capacity.
    # nsSlotsMax defaults to DEFAULT_NS_SLOTS_MAX (256) when absent — legacy images.
    _raw_ns_slots_max = step1.get("nsSlotsMax")
    _ns_slots_max = (DEFAULT_NS_SLOTS_MAX if _raw_ns_slots_max is None
                     else int(_raw_ns_slots_max))
    if not 0 <= _ns_slots_max <= MAX_NS_ENTRIES:
        raise ValueError(
            f"generate_boot_image: nsSlotsMax must be in 0..{MAX_NS_ENTRIES}; "
            f"got {_ns_slots_max}.")
    # Older saved configs may still carry residentProfile.  It is ignored:
    # exact Namespace rows are the only selection authority.
    _boot_saved_path, _selftest_slot = _resolve_authoritative_selftest_lump(lumps_dir)
    try:
        with open(os.path.join(lumps_dir, "ns-state.json"), encoding="utf-8") as _bf:
            _bootstrap_state = json.load(_bf)
            _bootstrap_rows = (
                _bootstrap_state.get("abstractions")
                if isinstance(_bootstrap_state, dict) else None
            )
    except (OSError, ValueError, AttributeError) as exc:
        raise ValueError(f"generate_boot_image: authoritative ns-state is unreadable: {exc}")
    _marked_boot_slot = namespace_boot_marker_slot(_bootstrap_rows)
    # Resident identities and slots come only from the exact programmer
    # selections in Namespace state.  A legacy config profile must not add,
    # replace, or adjudicate those bindings.
    _bootstrap_by_slot = {
        row["slot"]: row for row in _bootstrap_rows
        if isinstance(row, dict) and isinstance(row.get("slot"), int)
        and row.get("resident") is True and row.get("boot_resident") is True
        and row.get("ns_slot_policy") == "static"
        and row.get("load_policy") == "Resident"
        and row.get("type") in ("Inform", "Resident")
    }
    _owner_approvals = read_approvals(os.path.join(lumps_dir, "approvals.json"))
    for _owner_slot, _owner in list(_bootstrap_by_slot.items()):
        _owner_filename = _owner.get("filename")
        if not isinstance(_owner_filename, str):
            raise ValueError(
                f"generate_boot_image: frozen resident slot {_owner_slot} has no locator")
        executable_validator(
            os.path.join(lumps_dir, _owner_filename), lumps_dir,
            f"frozen resident owner slot {_owner_slot}", _owner)
        with open(os.path.join(lumps_dir, _owner_filename), "rb") as source:
            _owner_approval = _owner_approvals.get(
                hashlib.sha256(source.read()).hexdigest(), {})
        # Residency policy survives a revision change; bootstrap provenance
        # does not. Only the exact approval can establish a frozen SELF GT.
        if (_owner_approval.get("bootstrap_t") is None
                and _owner_approval.get("bootstrap_runtime_gt") is None):
            del _bootstrap_by_slot[_owner_slot]
    if _selftest_slot >= _ns_slots_max:
        raise ValueError(
            f"generate_boot_image: SelfTest slot {_selftest_slot} is outside "
            f"configured Namespace capacity {_ns_slots_max}")
    if boot_entry_slot is not None and boot_entry_slot != _marked_boot_slot:
        raise ValueError(
            f"generate_boot_image: requested boot entry NS[{boot_entry_slot}] "
            "does not match authoritative Namespace boot:true row "
            f"NS[{_marked_boot_slot}]")
    boot_entry_slot = _marked_boot_slot
    if (isinstance(boot_entry_slot, bool)
            or not isinstance(boot_entry_slot, int)
            or not 0 <= boot_entry_slot < _ns_slots_max):
        raise ValueError(
            "generate_boot_image: boot entry slot has no allocated resident "
            "Namespace location (it must be an integer within the configured "
            f"Namespace capacity 0..{_ns_slots_max - 1})")
    # A selected boot target must have one current Namespace-state binding.
    # Do not turn an absent/malformed current generation into sequence zero:
    # that is a capability revision change, not a harmless default.
    _target_state_rows = [
        row for row in _bootstrap_rows
        if isinstance(row, dict) and row.get("slot") == boot_entry_slot
        and not row.get("archived")
    ]
    if len(_target_state_rows) != 1:
        raise ValueError(
            f"generate_boot_image: selected boot target NS[{boot_entry_slot}] "
            "does not have exactly one current Namespace-state binding")
    _target_sequence = _target_state_rows[0].get("seq")
    if (isinstance(_target_sequence, bool)
            or not isinstance(_target_sequence, int)
            or not 0 <= _target_sequence <= 0x1FF):
        raise ValueError(
            f"generate_boot_image: selected boot target NS[{boot_entry_slot}] "
            f"has an invalid current sequence {_target_sequence!r}")

    # Thread.1 remains the fixed Boot.Thread at NS[1].  Thread.2 onward are
    # generated resident entries immediately after the fixed catalog.  Reject,
    # rather than clamp, invalid counts so a hand-edited config cannot silently
    # produce a different Namespace layout than the designer displayed.
    _thread_count = configured_thread_count(step1)
    _generated_thread_slots = generated_thread_slots(_thread_count)
    # A selected immutable body overrides the corresponding design instance.
    # Do not allocate/generate another Thread over that exact saved selection.
    _saved_body_slots = {row["slot"] for row in _bootstrap_rows
                         if row.get("filename") is not None}
    _generated_thread_slots = tuple(slot for slot in _generated_thread_slots
                                    if slot not in _saved_body_slots)
    if _selftest_slot in _generated_thread_slots:
        raise ValueError(
            f"generate_boot_image: authoritative SelfTest slot {_selftest_slot} "
            "collides with a configured generated Thread slot")
    if _generated_thread_slots and _generated_thread_slots[-1] >= _ns_slots_max:
        raise ValueError(
            f"generate_boot_image: threadCount={_thread_count} requires generated "
            f"Thread slots through {_generated_thread_slots[-1]}, but "
            f"step1.nsSlotsMax is {_ns_slots_max}. Increase nsSlotsMax or reduce "
            "the Thread Count."
        )
    NS_TABLE_RESERVE = ns_table_reserve_words(_ns_slots_max)   # local, shadows module constant
    # A Namespace header allocates the complete Namespace RAM window, not the
    # historical synthetic ``namespaceLumpWords`` display value.
    _ns_word0 = pack_namespace_word0(total, _ns_slots_max)

    # Namespace placement is sourced from ns-state and boot configuration.
    if "abstractionLumpWords" in step1:
        print("WARNING: abstractionLumpWords is deprecated and ignored; "
              "Boot.Abstr size is determined by the saved SelfTest lump "
              "(from the authoritative Namespace binding).")

    # ── Load the authoritative SelfTest binding ────────────────────────────
    # The saved lump is written big-endian by /api/lumps/save. Only exact bytes
    # with a matching strict approval and canonical filename may determine the
    # Boot.Abstr allocation; failure aborts image generation.
    # A real Namespace-state binding and its matching manifest locator are
    # required.  In particular, do not recover using 00000600.lump, a
    # token-less approval, or a guessed 512-word Boot.Abstr allocation.
    actual_abstr_size = None
    abstr_words = None
    # Validation is deliberately outside the legacy parsing guard below:
    # approval, filename, hash, or structural failures must never fall back to
    # a generated executable body.
    executable_validator(
        _boot_saved_path, lumps_dir, "SelfTest",
        _bootstrap_by_slot.get(_selftest_slot))
    try:
            with open(_boot_saved_path, "rb") as _bsf:
                _bsraw = _bsf.read()
            _bsn = len(_bsraw) // 4
            if _bsn >= 1:
                _bswords = list(struct.unpack(f">{_bsn}I", _bsraw[:_bsn * 4]))
                _bshdr = _bswords[0]
                _bscw  = (_bshdr >> 10) & 0x1FFF
                _bscc  = _bshdr & 0xFF
                _bsnm6 = (_bshdr >> 23) & 0xF
                _bssz  = 1 << (_bsnm6 + 6)
                if ((_bshdr >> 27) == 0x1F
                        and _bscc <= DEMO_CLIST_SIZE and _bsn >= _bssz
                        and (1 + _bscw + _bscc) <= _bssz):
                    actual_abstr_size = _bssz
                    # Decide whether to strip cc → 0 (triggering LAZY injection
                    # in _applyPendingSimLoad) or embed cc as-is (POLA-finalized
                    # lump whose c-list is already correct).
                    #
                    # Rule: scan every LOAD/SAVE/ELOADCALL/XLOADLAMBDA word
                    # (opcodes 0/1/8/9) whose crSrc field is CR6 (= 6).  If the
                    # slot operand >= _bscc then the stored c-list is incomplete
                    # (e.g. assembler-generated cc=1 placeholder) and the
                    # simulator must LAZY-inject the DEMO_CLIST at runtime.
                    # If ALL slot references are < _bscc the lump was finalized
                    # by POLA compression and must be embedded with its actual cc
                    # so LAZY injection does NOT overwrite the POLA c-list with
                    # the original DEMO_CLIST order (which would corrupt the
                    # POLA-rewritten slot indices in the code words).
                    _CLIST_OPS = frozenset((0, 1, 8, 9))  # LOAD SAVE ELOADCALL XLOADLAMBDA
                    _needs_lazy = (_bscc == 0)             # no c-list → always needs LAZY
                    if not _needs_lazy:
                        for _wi in range(1, 1 + _bscw):
                            if _wi >= _bssz:
                                break
                            _ww = _bswords[_wi]
                            _op     = (_ww >> 27) & 0x1F
                            _cr_src = (_ww >> 15) & 0xF
                            # Row lives in bits[4:0]; ELOADCALL/XLOADLAMBDA pack
                            # methodIdx into bits[11:5], so & 0x7FFF would read the
                            # method as part of the slot, causing false positives.
                            _slot   = _ww & 0x1F
                            if _op in _CLIST_OPS and _cr_src == 6 and _slot >= _bscc:
                                _needs_lazy = True
                                break
                    if executable_validator is not _require_approved_executable_lump:
                        # Private simulation validates complete capability
                        # references up front. Never strip immutable c-list
                        # content to invite a later catalog-driven injection.
                        _needs_lazy = False
                    if _needs_lazy:
                        # Pre-LAZY / stale c-list: strip cc → 0 in the header AND
                        # zero any c-list words in the tail so the embedded lump is
                        # fully consistent (cc=0 header + empty tail).  LAZY injection
                        # will rebuild the full DEMO_CLIST at runtime on first Run.
                        # Without zeroing the tail, a partially-POLA'd lump would leave
                        # dead POLA GTs visible in the lump viewer while the header
                        # claims cc=0 — a confusing and inconsistent display.
                        _body = list(_bswords[1:_bssz])
                        if _bscc > 0:
                            # Positions _bssz-_bscc .. _bssz-1 (0-indexed in full lump)
                            # map to _bssz-_bscc-1 .. _bssz-2 in _body (offset by 1).
                            for _ci in range(_bscc):
                                _body[_bssz - _bscc - 1 + _ci] = 0
                        abstr_words = [_bswords[0] & ~0xFF] + _body
                    else:
                        # POLA-finalized c-list: embed with actual cc so the
                        # simulator's LAZY guard (clistCount === 0) does not fire.
                        abstr_words = list(_bswords[:_bssz])
    except Exception as exc:
        raise ValueError(
            "generate_boot_image: SelfTest executable body could not be "
            f"embedded after approval validation: {exc}") from exc
    if actual_abstr_size is None or abstr_words is None:
        raise ValueError(
            "generate_boot_image: SelfTest approval-bound body has no valid "
            "header-derived allocation")

    # Memory image (Python ints, packed at the end).
    mem = [0] * total

    ns_table_base = total - NS_TABLE_RESERVE
    ns_header_base = 0
    _metadata_start = ns_table_base
    if ns_table_base <= NAMESPACE_HEADER_V2_WORDS:
        raise ValueError("generate_boot_image: Namespace Header V2 does not fit before table")

    # ----- Step 2: per-slot physAddr overrides --------------------------
    step2_lumps = []
    if isinstance(cfg.get("step2"), dict):
        step2_lumps = cfg["step2"].get("lumps") or []
    # Step 2 remains a compatibility transport for older designer clients,
    # but it may not create Namespace membership, choose an artifact, or
    # change residency.  Every submitted row must agree with the complete
    # authoritative Namespace plan before it can influence body placement.
    _state_by_slot = {
        row["slot"]: row for row in _bootstrap_rows
        if isinstance(row, dict) and isinstance(row.get("slot"), int)
    }

    def _state_binding_is_thread(row):
        """Classify by the bound body's header, never by its name."""
        if generated_thread_assignment(row, cfg):
            return True
        filename = row.get("filename") if isinstance(row, dict) else None
        if isinstance(filename, str) and os.path.basename(filename) == filename:
            try:
                with open(os.path.join(lumps_dir, filename), "rb") as source:
                    raw_header = source.read(4)
                if len(raw_header) == 4:
                    header = struct.unpack(">I", raw_header)[0]
                    return (((header >> 27) & 0x1F) == 0x1F
                            and ((header >> 8) & 0x3) == 2)
            except OSError:
                pass
        # Generated contexts have no artifact locator. Their body constructor
        # below emits the normative typ=2 header from the configured Thread
        # design, so this is type provenance rather than a pet-name rule.
        return False

    for _step2_row in step2_lumps:
        if not isinstance(_step2_row, dict):
            continue
        _step2_slot = _step2_row.get("nsSlot")
        if not isinstance(_step2_slot, int):
            raise ValueError(
                "generate_boot_image: Step-2 Namespace rows require an integer nsSlot")
        _state_row = _state_by_slot.get(_step2_slot)
        if _state_row is None:
            raise ValueError(
                f"generate_boot_image: Step-2 row NS[{_step2_slot}] is not present "
                "in authoritative Namespace state")
        _state_token = str(
            _state_row.get("token") or _state_row.get("cache_token") or "").lower()
        _step2_token = _step2_row.get("lumpToken")
        if _step2_token is not None and str(_step2_token).lower() != _state_token:
            raise ValueError(
                f"generate_boot_image: Step-2 token for NS[{_step2_slot}] "
                "disagrees with Namespace state")
        _state_policy = "Resident" if image_artifact_selected(_state_row, cfg) else "Lazy"
        _state_is_thread = _state_binding_is_thread(_state_row)
        if _state_is_thread:
            _state_policy = "Resident"
        _step2_policy = _step2_row.get("loadPolicy", _step2_row.get("load_policy"))
        if _state_is_thread and _step2_policy is not None:
            # Historical Lazy is input compatibility only. It cannot change
            # the effective policy of a Thread object.
            _step2_policy = "Resident"
        if _step2_policy is not None and str(_step2_policy) != _state_policy:
            raise ValueError(
                f"generate_boot_image: Step-2 load policy for NS[{_step2_slot}] "
                "disagrees with Namespace state")
        _state_resident = _state_policy == "Resident"
        if _state_is_thread and "resident" in _step2_row:
            # Treat the stale compatibility boolean exactly like stale Lazy.
            _step2_row = dict(_step2_row)
            _step2_row["resident"] = True
        if "resident" in _step2_row and bool(_step2_row.get("resident")) != _state_resident:
            raise ValueError(
                f"generate_boot_image: Step-2 residency for NS[{_step2_slot}] "
                "disagrees with Namespace state")
        if _step2_row.get("physAddr") is not None:
            _state_location = _state_row.get("location")
            try:
                _state_location = int(str(_state_location), 0)
            except (TypeError, ValueError):
                _state_location = None
            if _state_location is None or int(_step2_row["physAddr"]) != _state_location:
                raise ValueError(
                    f"generate_boot_image: Step-2 physical placement for NS[{_step2_slot}] "
                    "disagrees with Namespace state")
    # Foundational slots (0=NS, 1=Thread, 6=SelfTest) and MMIO device-register
    # windows (2-5) must not be overridden by caller-supplied physAddr values.
    _FOUNDATIONAL_SLOTS = {0, 1}  # Namespace and Thread are the only protected slots.
    _DEVICE_REG_SLOTS   = set(_MMIO_SLOT_SPECS.keys())            # slots 2..5 (MMIO)
    # Keep the historical fixed catalog immutable.  Namespace-selected
    # residents appended below are not fixed catalog identities: their
    # physical location is the authoritative Namespace placement, and a
    # matching Step-2 row must be allowed to carry it into this projection.
    # The authoritative SelfTest slot owns its identity, even when it replaces
    # a historical catalog/MMIO slot.  Slot 6 itself is otherwise free.
    catalog = list(DEFAULT_ABSTRACTION_CATALOG)
    catalog[BOOT_ABSTR_NS_SLOT] = None
    if _selftest_slot < len(catalog):
        catalog[_selftest_slot] = None
    # Destination-local resident admissions are authoritative Namespace rows,
    # not members of the fixed historical catalog. Extend the projection so
    # their exact approved bodies receive deterministic RAM placement.
    for _resident_row in _bootstrap_rows:
        if not isinstance(_resident_row, dict):
            continue
        _resident_slot = _resident_row.get("slot")
        if (not image_artifact_selected(_resident_row, cfg)
                or isinstance(_resident_slot, bool)
                or not isinstance(_resident_slot, int)
                or _resident_slot < len(DEFAULT_ABSTRACTION_CATALOG)):
            continue
        while len(catalog) <= _resident_slot:
            catalog.append(None)
        catalog[_resident_slot] = (
            str(_resident_row.get("name") or f"NS[{_resident_slot}]"),
            {"R": 0, "W": 0, "X": 0, "L": 0, "S": 0, "E": 1},
            False,
        )
    if honor_namespace_layout:
        # Historical catalog defaults are hardware conveniences, not saved
        # Namespace allocations. Absent services/devices must neither claim
        # RAM nor acquire descriptors/capabilities in a private simulation.
        # NS[0] is the architectural header and NS[1] the configured root
        # Thread; secondary configured Threads are generated separately.
        catalog = [
            entry if slot in _state_by_slot or slot in (0, 1) else None
            for slot, entry in enumerate(catalog)
        ]
    _RESERVED_SLOTS = ({0, 1, _selftest_slot}
                       | {slot for slot, entry in enumerate(DEFAULT_ABSTRACTION_CATALOG)
                          if entry is not None}
                       | set(_generated_thread_slots))

    phys_override = {}
    for e in step2_lumps:
        if not isinstance(e, dict):
            continue
        ns_slot = e.get("nsSlot")
        if isinstance(ns_slot, int) and ns_slot in _RESERVED_SLOTS:
            raise ValueError(
                f"generate_boot_image: NS slot {ns_slot} is reserved "
                f"(foundational lump, fixed catalog, or generated Thread); "
                "physAddr override rejected"
            )
        if (e.get("resident")
                and isinstance(e.get("physAddr"), int) and e["physAddr"] > 0):
            phys_override[int(ns_slot)] = int(e["physAddr"])

    _manifest_path_for_cache = os.path.join(lumps_dir, "manifest.json")
    # Configured Step-2 tokens were validated above only for compatibility;
    # Namespace state remains the sole source used to resolve artifact bytes.
    _selected_slot_tokens = {}
    trusted_cache_tokens = {}
    if executable_validator is not _require_approved_executable_lump:
        # W3 is runtime capability evidence, not an IDE artifact lookup ID.
        for row in _bootstrap_rows:
            if image_artifact_selected(row, cfg) and row.get("filename"):
                body = executable_validator(
                    os.path.join(lumps_dir, row["filename"]), lumps_dir,
                    f"NS[{row['slot']}]")
                trusted_cache_tokens[row["slot"]] = body[len(body) - (body[0] & 255)]
    else:
        trusted_cache_tokens = _load_trusted_cache_token_map(_manifest_path_for_cache, cfg)
    # A frozen bootstrap resident uses its approved SELF capability as the
    # descriptor's non-authoritative cache word.  This is deliberately not
    # inferred through the ordinary artifact-token resolver: bootstrap T is a
    # capability encoding, while the resolver's cache-token convention is
    # artifact-oriented.  Its exact approval was verified above.
    for _bootstrap_slot, _bootstrap_owner in _bootstrap_by_slot.items():
        if executable_validator is not _require_approved_executable_lump:
            continue
        try:
            trusted_cache_tokens[_bootstrap_slot] = int(
                str(_bootstrap_owner["token"]), 16) & 0xFFFFFFFF
        except (KeyError, TypeError, ValueError):
            raise ValueError(
                f"generate_boot_image: frozen resident slot {_bootstrap_slot} "
                "has an invalid bootstrap T")
    retained_sequences = _load_ns_state_sequence_map(lumps_dir)
    # Resolve boot-resident catalog bodies before assigning any locations.
    # Their declared LUMP allocation, not the historical 64-word catalog
    # default and not merely the file's byte length, reserves physical RAM.
    # The same cached body is embedded later so placement and writing cannot
    # disagree and overwrite a generated Thread context.
    _boot_resident_bodies = {}
    _boot_resident_allocations = {}
    for _slot, _tok, _filename in _load_boot_resident_entries(
            _manifest_path_for_cache, _selected_slot_tokens, config=cfg):
        if (_slot == _selftest_slot
                or not (0 <= _slot < len(catalog))
                or _slot in _MMIO_SLOT_SPECS):
            continue
        _selected_rows = [
            row for row in _bootstrap_rows
            if isinstance(row, dict) and row.get("slot") == _slot
            and str(row.get("token") or row.get("cache_token") or "").lower()
            == str(_tok).lower()
            and row.get("filename") == _filename
        ]
        if len(_selected_rows) != 1:
            raise ValueError(
                f"generate_boot_image: resident slot {_slot} has no unique exact "
                "Namespace-selected binding")
        _selected_hash = _selected_rows[0].get(
            "binary_hash", _selected_rows[0].get("binaryHash"))
        if (not isinstance(_selected_hash, str)
                or not re.fullmatch(r"[0-9a-fA-F]{64}", _selected_hash)):
            raise ValueError(
                f"generate_boot_image: resident slot {_slot} has no exact "
                "Namespace-selected artifact hash")
        _selected_path = os.path.join(lumps_dir, _filename)
        try:
            with open(_selected_path, "rb") as _selected_file:
                _selected_raw = _selected_file.read()
        except OSError as exc:
            raise ValueError(
                f"generate_boot_image: Namespace-selected resident slot {_slot} "
                f"artifact {_filename!r} is unavailable: {exc}") from exc
        if hashlib.sha256(_selected_raw).hexdigest() != _selected_hash.lower():
            raise ValueError(
                f"generate_boot_image: Namespace-selected resident slot {_slot} "
                "artifact hash mismatch")
        _body = _read_lump_body(lumps_dir, _tok, _filename)
        if _body is None:
            raise ValueError(
                f"generate_boot_image: boot-resident catalog slot {_slot} "
                "approval-required executable LUMP is missing")
        if not _body or ((_body[0] >> 27) & 0x1F) != 0x1F:
            raise ValueError(
                f"generate_boot_image: boot-resident catalog slot {_slot} "
                "does not contain a valid LUMP header")
        _declared_words = 1 << (((_body[0] >> 23) & 0xF) + 6)
        if len(_body) < _declared_words:
            raise ValueError(
                f"generate_boot_image: boot-resident catalog slot {_slot} "
                f"declares {_declared_words} words but its file contains only "
                f"{len(_body)}")
        _cw = (_body[0] >> 10) & 0x1FFF
        _typ = (_body[0] >> 8) & 0x3
        if _typ == 0 and _cw > 0:
            _body = executable_validator(
                _selected_path, lumps_dir, f"boot-resident Namespace slot {_slot}",
                _bootstrap_by_slot.get(_slot))
            _declared_words = len(_body)
        _boot_resident_bodies[_slot] = _body[:_declared_words]
        _boot_resident_allocations[_slot] = _declared_words
    slot_sizes = {
        0: ns_size,
        1: thread_size,
        # Slots 2-5: MMIO — no RAM body, handled by _MMIO_SLOT_SPECS.
    }
    slot_sizes.update(_boot_resident_allocations)

    # ----- NS entries ----------------------------------------------------
    clist_gts = []
    running_offset = NAMESPACE_HEADER_V2_WORDS
    locations = {}                              # idx -> location word
    _simulation_ranges = [(0, NAMESPACE_HEADER_V2_WORDS, 0)]

    def _namespace_location(slot, fallback):
        if not honor_namespace_layout:
            return fallback
        row = _state_by_slot.get(slot, {})
        if "location" not in row:
            return fallback
        value = row["location"]
        try:
            location = int(value, 0) if isinstance(value, str) else value
        except ValueError:
            location = None
        if type(location) is not int or location < 0:
            raise ValueError(f"NS[{slot}] saved Namespace location must be a nonnegative word address")
        return location

    def _claim_simulation_range(slot, location, size):
        if not honor_namespace_layout:
            return
        end = location + size
        if location < NAMESPACE_HEADER_V2_WORDS or end > _metadata_start:
            raise ValueError(
                f"NS[{slot}] saved Namespace allocation [0x{location:X},0x{end:X}) "
                "overlaps the reserved header/table or exceeds image bounds; review Namespace placement")
        for start, stop, other in _simulation_ranges:
            if location < stop and end > start:
                raise ValueError(
                    f"NS[{slot}] saved Namespace allocation [0x{location:X},0x{end:X}) "
                    f"overlaps NS[{other}] [0x{start:X},0x{stop:X}); review Namespace placement")
        _simulation_ranges.append((location, end, slot))
    for i, entry in enumerate(catalog):
        my_size  = slot_sizes.get(i, SLOT_SIZE)
        assigned = _state_by_slot.get(i)
        if i not in {0, 1} and assigned is None:
            # Catalog positions describe available objects, not Namespace
            # membership. An omitted saved slot must remain empty.
            clist_gts.append(0)
            continue
        if (i not in {0, 1, _selftest_slot, *_MMIO_SLOT_SPECS}
                and i not in _generated_thread_slots
                and assigned is not None and not image_artifact_selected(assigned, cfg)):
            # Dormant assignments stay in saved design, not in image RAM or
            # its executable descriptor inventory.
            clist_gts.append(0)
            continue

        if entry is None:
            # Null/free catalog slot: leave NS entry all-zeros.
            # No lump body is placed, so running_offset is unchanged.
            if i == 0:
                running_offset = ns_size   # degenerate: slot 0 is never None
            clist_gts.append(0)              # null GT in c-list at this position
            continue

        label, perms, chainable, *_bsonly = entry
        retained_sequence = retained_sequences.get(i, 0)
        bitstream_only = bool(_bsonly and _bsonly[0])
        override = phys_override.get(i)
        if i == 0:
            # Namespace Header V2 has a real physical block before the table.
            # runningOffset is NOT advanced so Thread (slot 1) naturally gets loc=0.
            loc = ns_header_base
            if _namespace_location(i, loc) != loc:
                raise ValueError("NS[0] saved Namespace location disagrees with the architectural header")
        elif i in _MMIO_SLOT_SPECS and i != _selftest_slot:
            # MMIO NS slot: physical MMIO byte address, no RAM body allocated.
            loc = _MMIO_SLOT_SPECS[i][0]
            if _namespace_location(i, loc) != loc:
                raise ValueError(f"NS[{i}] saved Namespace location disagrees with its architectural MMIO address")
            # Don't advance running_offset (no RAM reservation for MMIO).
        else:
            if override is not None:
                loc = override
            elif not bitstream_only:
                loc = running_offset
                running_offset += my_size
            else:
                loc = 0   # placeholder; NS entry not written (bitstream fills it)
            if not bitstream_only:
                loc = _namespace_location(i, loc)
                _claim_simulation_range(i, loc, my_size)
                if honor_namespace_layout:
                    running_offset = max(running_offset, loc + my_size)
        locations[i] = loc

        # Slot 0: limit covers the NS TABLE region (NS_TABLE_RESERVE words).
        # MMIO slots: lim17 from _MMIO_SLOT_SPECS (device register count - 1).
        if i == 0:
            lim17 = (NS_TABLE_RESERVE - 1) & 0x1FFFF
            # NS[0] (Boot.NS) has no physical c-list in the NS TABLE region.
            # clistCount=0; the DEMO_CLIST is managed through clist_gts[] and
            # lazily installed into Boot.Abstr at runtime.
            clist_count = 0
        elif i in _MMIO_SLOT_SPECS and i != _selftest_slot:
            lim17 = _MMIO_SLOT_SPECS[i][1]
            clist_count = 0
        else:
            lim17 = (my_size - 1) & 0x1FFFF
            clist_count = 0

        if bitstream_only:
            # Bitstream-written slot: NS entry provided by FPGA hardware, not boot software.
            # Leave the NS table words as zeros (hardware fills them at power-on).
            # runningOffset already not advanced (loc assignment already skipped above).
            clist_gts.append(create_gt(retained_sequence, i, perms, 1))
            continue
        write_ns_entry(mem, total, NS_ENTRY_WORDS, i, loc, lim17,
                       0, 0, 1, retained_sequence, clist_count,
                       trusted_cache_tokens.get(i, 0))
        clist_gts.append(create_gt(retained_sequence, i, perms, 1))

    # SelfTest is not a catalog-position body.  Its authoritative Namespace
    # state selects both its slot and the exact approved allocation, so place
    # it in the same running resident pool as other executable bodies.
    _selftest_loc = _namespace_location(_selftest_slot, running_offset)
    _claim_simulation_range(_selftest_slot, _selftest_loc, actual_abstr_size)
    _selftest_end = _selftest_loc + actual_abstr_size
    if _selftest_end > _metadata_start:
        raise ValueError(
            f"generate_boot_image: SelfTest ({actual_abstr_size} words at "
            f"0x{_selftest_loc:X}) does not fit below the NS table "
            f"(base 0x{ns_table_base:X})")
    _selftest_sequence = retained_sequences.get(_selftest_slot, 0)
    write_ns_entry(
        mem, total, NS_ENTRY_WORDS, _selftest_slot, _selftest_loc,
        (actual_abstr_size - 1) & 0x1FFFF, 0, 0, 1, _selftest_sequence, 0,
        trusted_cache_tokens.get(_selftest_slot, 0))
    locations[_selftest_slot] = _selftest_loc
    running_offset = max(running_offset, _selftest_end) if honor_namespace_layout else _selftest_end

    # Count only non-null catalog entries: the highest non-null slot index + 1.
    # All 11 catalog entries are non-null (slots 0–10). This must match simulator.js nsCount.
    ns_count = max((i + 1 for i, e in enumerate(catalog) if e is not None), default=0)
    ns_count = max(ns_count, _selftest_slot + 1)

    # ----- Generated Thread Namespace entries ----------------------------
    # Each secondary Thread has the same complete Thread LUMP layout as the
    # fixed Thread.1 entry and is discoverable through a deterministic Inform
    # descriptor.  Place bodies after the fixed catalog's RAM bodies, matching
    # simulator.js fallback initialization exactly.
    extra_thread_locs = []
    for _ordinal, _thread_slot in enumerate(_generated_thread_slots, start=2):
        _thread_loc = _namespace_location(_thread_slot, running_offset)
        _claim_simulation_range(_thread_slot, _thread_loc, thread_size)
        _thread_end = _thread_loc + thread_size
        # Keep all resident bodies below the three metadata sentinel words.
        if _thread_end > _metadata_start:
            raise ValueError(
                f"generate_boot_image: Thread.{_ordinal} ({thread_size} words at "
                f"0x{_thread_loc:X}) does not fit below the NS table "
                f"(base 0x{ns_table_base:X}); reduce threadCount, "
                f"threadLumpWords, or nsSlotsMax, or increase "
                f"totalNamespaceWords."
            )
        write_ns_entry(mem, total, NS_ENTRY_WORDS, _thread_slot, _thread_loc,
                       (thread_size - 1) & 0x1FFFF, 0, 0, 1,
                       retained_sequences.get(_thread_slot, 0) if honor_namespace_layout else 0, 0, 0)
        locations[_thread_slot] = _thread_loc
        extra_thread_locs.append(_thread_loc)
        running_offset = max(running_offset, _thread_end) if honor_namespace_layout else _thread_end
        ns_count = max(ns_count, _thread_slot + 1)

    # The catalog loop has reserved RAM for all fixed catalog bodies and the
    # generated-thread loop has reserved every configured Thread body.  A
    # Step-2 body is written later, so reject an overlap before it can corrupt
    # a Thread header or its CR0 boot-entry capability.
    _protected_end = running_offset
    for _e2 in step2_lumps:
        if not (isinstance(_e2, dict) and bool(_e2.get("resident"))):
            continue
        _e2_phys = _e2.get("physAddr")
        _e2_size = _e2.get("lumpSize") or SLOT_SIZE
        if (isinstance(_e2_phys, int) and isinstance(_e2_size, int)
                and _e2_size > 0 and _e2_phys < _protected_end
                and _e2_phys + _e2_size > 0):
            raise ValueError(
                f"generate_boot_image: resident Step-2 lump at "
                f"physAddr {_e2_phys} overlaps the fixed boot and generated "
                f"Thread region (0..{_protected_end - 1})")

    # ----- Step 2 augmentation: NS entries for extended slots (≥8) ------
    # The 11-slot hardware catalog loop above creates NS entries for
    # slots 0–10.  Resident
    # Step-2 lumps targeting slots ≥ 11 need explicit
    # NS entries written here.  Lazy (resident=False) slots are left as
    # all-zeros — the runtime lazy loader writes their NS entry on first use.
    for _e2 in step2_lumps:
        if not isinstance(_e2, dict):
            continue
        _e2_slot = _e2.get("nsSlot")
        if not isinstance(_e2_slot, int) or _e2_slot < len(catalog):
            continue   # foundational / in-catalog slots already handled
        if _e2_slot in _RESERVED_SLOTS:
            continue
        if not (bool(_e2.get("resident"))
                and isinstance(_e2.get("physAddr"), int)
                and _e2["physAddr"] > 0):
            continue   # lazy-load: no NS entry in boot image
        _e2_phys  = int(_e2["physAddr"])
        _e2_size  = int(_e2.get("lumpSize") or SLOT_SIZE)
        _e2_lim17 = (_e2_size - 1) & 0x1FFFF
        _e2_perms = {"E": 1}   # callable abstraction
        write_ns_entry(mem, total, NS_ENTRY_WORDS, _e2_slot, _e2_phys, _e2_lim17,
                       0, 0, 1, retained_sequences.get(_e2_slot, 0), 0,
                       trusted_cache_tokens.get(_e2_slot, 0))
        locations[_e2_slot] = _e2_phys
        ns_count = max(ns_count, _e2_slot + 1)

    # ----- Step 3: empty NS slots ---------------------------------------
    empty_count = 0
    if isinstance(cfg.get("step3"), dict):
        try:
            empty_count = max(0, int(cfg["step3"].get("emptySlotCount") or 0))
        except (TypeError, ValueError):
            empty_count = 0
    if ns_count + empty_count > _ns_slots_max:
        raise ValueError(
            f"Step 3 emptySlotCount={empty_count} would push NS table to "
            f"{ns_count + empty_count} entries; configured capacity is "
            f"{_ns_slots_max} (step1.nsSlotsMax)."
        )
    if _ns_slots_max < ns_count:
        raise ValueError(
            f"generate_boot_image: nsSlotsMax={_ns_slots_max} is less than the "
            f"abstraction catalog count ({ns_count}); the NS table would not fit all "
            f"catalog entries. Increase nsSlotsMax to at least {ns_count}."
        )
    # ----- Foundational lump headers -------------------------------------
    # Thread lump (NS slot 1): cw/sw=stack words, cc=12 persisted CR homes, typ=2.
    # Capability homes occupy the final 12 words of the selected Thread size.
    # Pre-set here so the board boots into SelfTest standalone without needing
    # setBootEntrySlot() from the IDE.  The IDE overwrites this when the user
    # chooses a different entry point; the simulator's "if empty" guard is a no-op
    # when loading a boot image that already carries this word.
    thread_loc = locations[1]
    if thread_size not in THREAD_SUPPORTED_BODY_WORDS:
        raise ValueError(
            f"generate_boot_image: threadLumpWords ({thread_size}) is not a "
            f"supported Thread body size; choose one of "
            f"{', '.join(map(str, THREAD_SUPPORTED_BODY_WORDS))}")
    mem[thread_loc] = pack_lump_header(
        _ns_n_minus_6(thread_size), thread_stack_words, THREAD_CAP_WORDS, 2)
    # Selection is prepared from the destination Namespace descriptor.  The
    # descriptor's live sequence is authoritative; neither a UI default nor a
    # historical artifact revision may replace it.  Do this before touching
    # Boot.Thread so a bad target leaves no partially prepared output.
    _boot_entry_ns_base = total - (boot_entry_slot + 1) * NS_ENTRY_WORDS
    if boot_entry_slot in _MMIO_SLOT_SPECS:
        raise ValueError(
            f"generate_boot_image: boot entry slot {boot_entry_slot} is an "
            "MMIO device, not an executable E-GT target")
    if boot_entry_slot not in locations:
        raise ValueError(
            f"generate_boot_image: boot entry slot {boot_entry_slot} has no "
            "allocated resident Namespace location; explicitly prepare a resident "
            "target before selecting it")
    if not (0 <= _boot_entry_ns_base + 1 < total):
        raise ValueError(
            f"generate_boot_image: boot entry slot {boot_entry_slot} is outside "
            "the generated Namespace table")
    _boot_entry_authority = mem[_boot_entry_ns_base + 1]
    if mem[_boot_entry_ns_base] == 0 and _boot_entry_authority == 0:
        raise ValueError(
            f"generate_boot_image: boot entry slot {boot_entry_slot} does not "
            "have a valid live Namespace descriptor")
    _boot_entry_seq = _ns_word1_get(mem[_boot_entry_ns_base + 1], "gt_seq")
    if _boot_entry_seq != _target_sequence:
        raise ValueError(
            f"generate_boot_image: selected boot target NS[{boot_entry_slot}] "
            "descriptor generation disagrees with its current Namespace state")
    _entry_gt = create_gt(_boot_entry_seq, boot_entry_slot, {"E": 1}, 1)
    _resume_sto = layout["stack_end"] - 2
    mem[thread_loc + THREAD_STO_OFFSET] = (1 << 12) | _resume_sto
    mem[thread_loc + layout["caps_start"]] = _entry_gt
    mem[thread_loc + _resume_sto + 1] = _entry_gt
    mem[thread_loc + _resume_sto + 2] = (
        (0x7FFF << 13) | (1 << 12) | layout["stack_end"]
    )

    # ----- Generated Thread bodies (Thread.2 .. Thread.N) ----------------
    # A Lightning Bolt selection prepares *Boot.Thread* only.  Do not use a
    # new next-boot target as authority to rewrite another Thread's saved
    # context. Thread.2/3 explicitly start CapabilityTest through an initial
    # continuation frame, not an implicit CALL. This formats new images only.
    for _ordinal, _thread_loc in enumerate(extra_thread_locs, start=2):
        _secondary_thread_gt = create_gt(
            retained_sequences.get(CAPABILITY_TEST_NS_SLOT, 0) if _ordinal <= 3 else _selftest_sequence,
            CAPABILITY_TEST_NS_SLOT if _ordinal <= 3 else _selftest_slot, {"E": 1}, 1)
        mem[_thread_loc] = pack_lump_header(
            _ns_n_minus_6(thread_size), thread_stack_words, THREAD_CAP_WORDS, 2)
        mem[_thread_loc + THREAD_STO_OFFSET] = (1 << 12) | _resume_sto
        mem[_thread_loc + layout["caps_start"]] = _secondary_thread_gt
        mem[_thread_loc + _resume_sto + 1] = _secondary_thread_gt
        mem[_thread_loc + _resume_sto + 2] = (
            (0x7FFF << 13) | (1 << 12) | layout["stack_end"]
        )
        # CHANGE restores this real PC-0 continuation, leaving the poison
        # root beneath it. Unlike boot, ordinary CHANGE has no following CALL.
        if thread_stack_words < 4:
            raise ValueError("secondary Thread startup requires two two-word frames")
        mem[_thread_loc + THREAD_STO_OFFSET] = (1 << 12) | (_resume_sto - 2)
        mem[_thread_loc + _resume_sto - 1] = _secondary_thread_gt
        mem[_thread_loc + _resume_sto] = (1 << 12) | _resume_sto

    # Memory-manager GT at c-list[0]: R|W capability over NS slot 0 (full namespace).
    mem_mgr_gt = create_gt(0, 0, {"R":1, "W":1}, 1)
    clist_gts[0] = mem_mgr_gt

    # Next.GT at c-list[1]: SelfTest calls through it at done:
    # (CALL AL, CR1, CR1). It always targets the same Namespace slot selected
    # by the ⚡ LightningBolt boot-entry control. This keeps the post-SelfTest
    # continuation and Thread.CR0 in lockstep; it is never independently
    # configurable or a stale self-loop.
    clist_gts[1] = create_gt(_boot_entry_seq, boot_entry_slot, {"E": 1}, 1)

    # ── DEMO_CLIST finalisation ─────────────────────────────────────────────────
    # The c-list GT words are managed virtually in clist_gts[].  They are NOT
    # written into the NS TABLE region — the NS TABLE is a flat table of NS
    # entries only; it carries no c-list.  NS slots 0 and 1 were written
    # correctly above by the catalog loop (using write_ns_entry via mem writes
    # with clist_count=0 for NS[0]) and are never stomped by any c-list loop.

    # Truncate to DEMO_CLIST_SIZE (11 entries for minimal 8-slot namespace).
    clist_gts = clist_gts[:DEMO_CLIST_SIZE]

    # ----- Authoritative SelfTest lump ------------------------------------
    # The Boot Abstraction: directly loaded by B:06 (INIT_ABSTR), no director hop.
    #
    # Resident mode is selected only by Namespace state / boot configuration:
    #   The saved SelfTest lump body (00000600.lump) is copied into the image at
    #   boot_entry_loc.  The simulator executes it immediately on first Run.
    #
    # Lazy mode is never inferred from artifact manifest metadata.
    #   A minimal CODE_NOT_RESIDENT stub header (magic=0x1F, cw=0, cc=0) is written
    #   at boot_entry_loc.  The simulator detects cw=0 on the first execution attempt
    #   and triggers a lazy fetch of the canonical SelfTest lump (4c7380cb.lump).
    #   This mirrors the FPGA BRAM model where the 512-word body does not fit in BRAM
    #   and only the 64-word stub is stored on-chip.
    boot_entry_loc  = locations[_selftest_slot]
    entry_ns_base   = total - (_selftest_slot + 1) * NS_ENTRY_WORDS

    # SelfTest residency is not inferred from the artifact manifest.
    _selftest_lazy = False

    # Preserve the cache_token32 word3 that the catalog loop wrote for Boot.Abstr.
    # The lazy/resident paths below only need to update word1 (limit/authority) and
    # word2 (seal); word0 (location) and word3 (cache token) stay from the loop.
    _abstr_ns_base = total - (_selftest_slot + 1) * NS_ENTRY_WORDS
    _abstr_cache_token = mem[_abstr_ns_base + 3]

    if _selftest_lazy:
        # Lazy mode: write CODE_NOT_RESIDENT stub (cw=0).  Simulator lazy-loads the
        # real lump body on first call; NS entry points here with alloc=64 words.
        mem[boot_entry_loc] = pack_lump_header(_ns_n_minus_6(actual_abstr_size), 0, 0, 0)
        entry_cr_limit = actual_abstr_size - 1  # cc=0 stub has no c-list
        write_ns_entry(mem, total, NS_ENTRY_WORDS, _selftest_slot,
                       boot_entry_loc, entry_cr_limit, 0, 0, 1, 0, 0,
                       _abstr_cache_token)
    elif abstr_words is not None:
        # Resident mode: saved lump present and validated — copy body into image.
        # abstr_words was parsed from big-endian disk format into Python ints;
        # writing them into mem[] produces correct little-endian output at pack time.
        for _i, _w in enumerate(abstr_words):
            mem[boot_entry_loc + _i] = _w & 0xFFFFFFFF
        # Derive cc from the saved lump header (already validated above).
        _saved_cc      = abstr_words[0] & 0xFF
        entry_cr_limit = actual_abstr_size - _saved_cc - 1

        # Row 0 is immutable authenticated input.  Approval validation above
        # already proved it equals the owning descriptor-derived GT; never
        # repair or normalize a mismatching artifact while building an image.
        if _saved_cc > 0:
            _clist_base_m = boot_entry_loc + actual_abstr_size - _saved_cc
            if 0 < _clist_base_m < total:
                if _saved_cc > 1 and len(clist_gts) > 1:
                    mem[_clist_base_m + 1] = clist_gts[1] & 0xFFFFFFFF
        write_ns_entry(mem, total, NS_ENTRY_WORDS, _selftest_slot,
                        boot_entry_loc, entry_cr_limit, 0, 0, 1, _selftest_sequence, _saved_cc,
                       _abstr_cache_token)
    else:
        # No saved lump and resident mode required — the trampoline is eliminated
        # (direct dispatch via CR0).  Raise a clear error so the operator knows to
        # generate a boot image with the SelfTest lump rather than silently producing
        # a broken image.
        raise ValueError(
            f"Boot.Abstr (SelfTest) lump not found in lumps directory.\n"
            f"The direct-dispatch boot model requires the real SelfTest lump.\n"
            f"Save the SelfTest lump selected by Namespace state (slot {_selftest_slot}) via the IDE "
            f"and retry.\n"
            f"(Manifest: {os.path.join(lumps_dir, 'manifest.json')})\n"
            f"(Lumps dir: {lumps_dir})"
        )

    # Thread.CR[0] entry E-GT is pre-set to boot_entry_slot above; IDE overwrites on connect.

    # ----- Service abstraction c-lists ------------------------------------
    # Populate c-lists for service abstractions that have declared capability
    # requirements. All are handler-based (cw=0 — no CLOOMC code).
    # Pure Church-calculus slots keep cc=0 and are absent from SERVICE_CLIST_DEFS.
    for _cslot, _entries in SERVICE_CLIST_DEFS.items():
        _cc = len(_entries)
        _loc = locations.get(_cslot)
        if _loc is None or _cc == 0:
            continue
        _sz = slot_sizes.get(_cslot, SLOT_SIZE)
        _lim17 = (_sz - _cc - 1) & 0x1FFFF
        # lump header: cw=0 (handler-only, no code), cc=_cc, typ=0
        mem[_loc] = pack_lump_header(_ns_n_minus_6(_sz), 0, _cc, 0)
        # c-list GT words at lump tail
        for _ci, _entry in enumerate(_entries):
            if _entry[0] == "abstract_sperm":
                _gt = create_abstract_sperm_gt()
            elif _entry[0] == "abstract":
                _, _ab_type, _rw_perms, _ab_data = _entry
                _gt = create_abstract_gt(_ab_type, _rw_perms, 0, _ab_data)
            else:  # "inform"
                _, _ref_slot, _perms = _entry
                _gt = create_gt(
                    retained_sequences.get(_ref_slot, 0),
                    _ref_slot,
                    _perms,
                    1,
                )
            mem[_loc + _sz - _cc + _ci] = _gt & 0xFFFFFFFF
        # Update NS entry: rewrite with corrected lim17 and cc via the gated helper.
        _svc_ns_base = total - (_cslot + 1) * NS_ENTRY_WORDS
        write_ns_entry(mem, total, NS_ENTRY_WORDS, _cslot, _loc, _lim17,
                       0, 0, 1, 0, _cc, mem[_svc_ns_base + 3])

    # Namespace Header V2 occupies physical words 0..15.  Its boot entry is a
    # byte address; the Namespace descriptors continue to use word offsets.
    _header_entry = locations.get(boot_entry_slot)
    if _header_entry is None:
        raise ValueError(
            f"generate_boot_image: boot entry slot {boot_entry_slot} has no "
            "allocated resident Namespace location")
    mem[:NAMESPACE_HEADER_V2_WORDS] = encode_namespace_header(
        0, total, _ns_slots_max, _header_entry * 4)

    # ----- Boot-resident manifest lumps (auto-placement) ---------------
    # Any manifest entry with boot_resident=true and a corresponding
    # .lump file is automatically embedded at its catalog physAddr so that
    # the lump body is present on cold boot without a lazy fetch.
    # Step-2 explicit config can override a slot's physAddr and will
    # overwrite this placement in the loop below.
    _manifest_path = os.path.join(lumps_dir, "manifest.json")
    _token_map     = _load_catalog_token_map(_manifest_path, _selected_slot_tokens, cfg)
    for _slot, _body in _boot_resident_bodies.items():
        _phys = locations.get(_slot)
        if _phys is None:
            continue
        _allocation = _boot_resident_allocations[_slot]
        if _phys + _allocation > _metadata_start:
            raise ValueError(
                f"generate_boot_image: boot-resident catalog slot {_slot} "
                f"({_allocation} words at 0x{_phys:X}) does not fit below "
                f"the NS table (base 0x{ns_table_base:X})")
        _n = min(len(_body), _allocation)
        for _wi in range(_n):
            mem[_phys + _wi] = _body[_wi] & 0xFFFFFFFF
        # Update NS entry word1 (lim17 + cc) and word2 (seal) to match the
        # actual lump.  The catalog loop wrote cc=0 for non-MMIO non-SelfTest
        # slots; boot-resident lumps may have cc > 0 (e.g. CapabilityTest has cc=5).
        # Preserve word3 (cache_token32) from the catalog loop.
        _hdr      = _body[0] if _body else 0
        _body_cc  = _hdr & 0xFF
        _body_sz  = _allocation
        _br_lim17 = (_body_sz - _body_cc - 1) & 0x1FFFF
        _br_ns_base = total - (_slot + 1) * NS_ENTRY_WORDS
        _br_cache_token = mem[_br_ns_base + 3]
        _br_sequence = _ns_word1_get(mem[_br_ns_base + 1], "gt_seq")
        write_ns_entry(mem, total, NS_ENTRY_WORDS, _slot, _phys, _br_lim17,
                       0, 0, 1, _br_sequence, _body_cc, _br_cache_token)

    # ----- Resident lump bodies (Step 2) --------------------------------
    token_map = _token_map
    # Portable artifacts deliberately retain unresolved c-list rows on disk.
    # Once this image's NS descriptors exist, build a destination view from
    # their *live* slots/sequences and localize each resident portable body.
    # Manifest fields identify candidates, but each candidate includes bytes
    # read from its .lump so localize_portable_lump_body rehashes real content.
    _portable_candidates = {}
    _portable_approvals = {}
    try:
        _approvals = read_approvals(os.path.join(lumps_dir, "approvals.json"))
        with open(_manifest_path) as _pmf:
            _portable_manifest = json.load(_pmf)
    except (OSError, ValueError) as exc:
        raise ValueError(f"portable catalog is unreadable: {exc}") from exc
    if not isinstance(_portable_manifest, list):
        raise ValueError("portable catalog manifest must be an array")
    for _pe in _portable_manifest:
        if not isinstance(_pe, dict):
            raise ValueError("portable catalog contains a non-object locator")
        # Archived locators preserve immutable history but are never candidates
        # for the live Namespace binding.  Processing them can emit diagnostics
        # to stdout and corrupt callers which stream the generated binary there.
        if _pe.get("archived") is True:
            continue
        _ptok = str(_pe.get("token", "")).lower()
        _p_slots = [slot for slot, selected_token in token_map.items()
                    if str(selected_token).lower() == _ptok]
        if len(_p_slots) != 1:
            continue
        _pslot = _p_slots[0]
        if _pe.get("filename") != _state_by_slot[_pslot].get("filename"):
            continue
        _pbase = total - (_pslot + 1) * NS_ENTRY_WORDS
        if not (0 <= _pbase + 1 < total):
            raise ValueError(f"portable token {_ptok} has an invalid Namespace slot")
        _pbody = _read_lump_body(lumps_dir, _ptok, _pe.get("filename"))
        if _pbody is None:
            print(f"[boot-image] portable token {_ptok}: located binary unavailable",
                  flush=True)
            continue
        _praw = struct.pack(f">{len(_pbody)}I", *[x & 0xffffffff for x in _pbody])
        _digest = hashlib.sha256(_praw).hexdigest()
        _approval = _approvals.get(_digest)
        if not isinstance(_approval, dict):
            print(f"[boot-image] portable token {_ptok}: exact approval missing",
                  flush=True)
            continue
        # Frozen bootstrap residents are already materialized and validated
        # above.  They intentionally carry bootstrap_t rather than a portable
        # relocation binding, so they must not enter the portable-LUMP path.
        if _approval.get("bootstrap_t") is not None:
            continue
        _dot = _approval.get("dot_name")
        _issue = _approval.get("issue_n")
        _identity = _approval.get("identity_hash")
        _binding = _approval.get("portable_binding")
        if _binding is None:
            # Ordinary compiler output can carry only the intrinsic SELF
            # marker, with concrete external capabilities. It is not portable.
            continue
        if (not isinstance(_dot, str) or not _dot
                or not isinstance(_issue, int) or _issue < 1
                or _identity != hashlib.sha256(
                    f"{_dot}#{_issue}".encode("utf-8")).hexdigest()
                or not isinstance(_binding, dict)):
            print(f"[boot-image] portable token {_ptok}: approval binding invalid",
                  flush=True)
            continue
        try:
            try:
                from portable_binding import validate_portable_binding
            except ImportError:
                from server.portable_binding import validate_portable_binding
            validate_portable_binding(_binding, cc=_pbody[0] & 0xff)
        except ValueError as exc:
            print(f"[boot-image] portable token {_ptok}: invalid portable binding: {exc}",
                  flush=True)
            continue
        _pn = f"{_dot}#{_issue}"
        _portable_candidates[_pn] = {
            "dot_name": _dot, "issue_n": _issue,
            "identity_hash": _identity,
            "binary_hash": _digest,
            "lump_bytes": _praw, "ns_slot": _pslot,
            "sequence": _ns_word1_get(mem[_pbase + 1], "gt_seq"),
            "grants": _approval.get("grants", []),
            "capability_type": _approval.get("capability_type"),
        }
        _portable_approvals[_ptok] = _approval
    # Revisit bodies already placed through the boot-entry and catalog paths.
    # They are now eligible for the same localization as Step-2 bodies because
    # every NS descriptor (and therefore every live sequence) exists.
    for _placed_slot, _placed_token in token_map.items():
        _placed_binding = (_portable_approvals.get(
            str(_placed_token).lower(), {}).get("portable_binding"))
        _placed_loc = locations.get(_placed_slot)
        if _placed_binding is None or _placed_loc is None or not (0 <= _placed_loc < total):
            continue
        _placed_header = mem[_placed_loc]
        if ((_placed_header >> 27) & 0x1f) != 0x1f:
            continue
        _placed_size = 1 << (((_placed_header >> 23) & 0xf) + 6)
        if _placed_loc + _placed_size > total:
            raise ValueError(f"portable boot body at slot {_placed_slot} is truncated")
        _localized = localize_portable_lump_body(
            mem[_placed_loc:_placed_loc + _placed_size], _placed_binding,
            _portable_candidates)
        mem[_placed_loc:_placed_loc + _placed_size] = _localized
    for e in step2_lumps:
        if not (isinstance(e, dict) and e.get("resident")):
            continue
        slot = int(e["nsSlot"])
        phys = int(e["physAddr"])
        token = token_map.get(slot)
        body_path = _resolve_selected_lump_locator(
            lumps_dir, slot, token)
        body = executable_validator(
            body_path, lumps_dir, f"Step-2 resident slot {slot}",
            _bootstrap_by_slot.get(slot))
        _binding = (_portable_approvals.get(str(token).lower(), {})
                    .get("portable_binding"))
        if _binding is not None:
            # A binding failure is a build failure, never a partially localized
            # boot image with stale source-local GT words.
            body = localize_portable_lump_body(body, _binding, _portable_candidates)
        # Honour the lump's declared size bound (don't write past it).
        size_cap = int(e.get("lumpSize") or len(body))
        n = min(len(body), size_cap, total - phys)
        for i in range(n):
            mem[phys + i] = body[i] & 0xFFFFFFFF

    # ----- Boot-entry residency validation --------------------------------
    # Hardware-targeted images (require_entry_resident=True) must carry the
    # selected entry lump's code body: the FPGA has no lazy-fetch path, so a
    # cw=0 stub (or a missing/MMIO location) would fault on the first fetch
    # after the boot ROM's CALL CR0.  Fail loudly here instead.
    if require_entry_resident:
        _e_slot = boot_entry_slot
        _e_loc  = locations.get(_e_slot)
        _e_err  = None
        if _e_loc is None:
            _e_err = f"NS slot {_e_slot} has no allocated location in this image"
        elif _e_slot in _MMIO_SLOT_SPECS:
            _e_err = f"NS slot {_e_slot} is an MMIO device slot (not executable)"
        elif not (0 <= _e_loc < total):
            _e_err = (f"NS slot {_e_slot} location 0x{_e_loc:08X} is outside "
                      f"the image ({total} words)")
        else:
            _e_hdr   = mem[_e_loc]
            _e_magic = (_e_hdr >> 27) & 0x1F
            _e_cw    = (_e_hdr >> 10) & 0x1FFF
            if _e_magic != 0x1F:
                _e_err = (f"NS slot {_e_slot} location 0x{_e_loc * 4:08X} does not "
                          f"hold a lump header (word=0x{_e_hdr:08X})")
            elif _e_cw == 0:
                _e_err = (f"NS slot {_e_slot} lump at 0x{_e_loc * 4:08X} is a "
                          f"CODE_NOT_RESIDENT stub (cw=0)")
        if _e_err:
            raise ValueError(
                f"Boot-entry lump body not resident for hardware image: {_e_err}.\n"
                f"The board cannot lazy-fetch code — save the entry lump as "
                f"boot-resident (manifest boot_resident=true) or pick a resident "
                f"entry slot before uploading."
            )

    # Bind the compiler's intrinsic SELF marker in the destination copy only.
    # Unlike external relocations this has no lookup: authority is precisely
    # this approved assignment's live slot/sequence. Revalidate exact compiler
    # provenance before interpreting the marker, never mutate saved bytes.
    for _slot, _binding in _state_by_slot.items():
        if not image_artifact_selected(_binding, cfg):
            continue
        _loc = locations.get(_slot)
        if _loc is None or not _binding.get("filename"):
            continue
        _header = mem[_loc]
        _size = 1 << (((_header >> 23) & 15) + 6)
        _cc = _header & 255
        if not _cc or mem[_loc + _size - _cc] != 0xFEED5E1F:
            continue
        _exact = executable_validator(
            os.path.join(lumps_dir, _binding["filename"]), lumps_dir,
            f"compiler SELF NS[{_slot}]", _binding)
        _base = total - (_slot + 1) * NS_ENTRY_WORDS
        if mem[_loc:_loc + _size] != _exact:
            raise ValueError(f"NS[{_slot}] destination body differs from approved bytes")
        _destination = dict(_binding, slot=_slot,
                            seq=_ns_word1_get(mem[_base + 1], "gt_seq"))
        _, _self = materialize_compiler_self(
            struct.pack(f">{len(_exact)}I", *_exact), _destination,
            lumps_dir, f"compiler SELF NS[{_slot}]")
        mem[_loc + _size - _cc] = _self
        mem[_base + 3] = _self

    # Final invariant: copied SELF, owning descriptor-derived GT, ns-state T,
    # approval T (proved while loading), and NS W3 remain one exact word.
    for _owner_slot, _owner in _bootstrap_by_slot.items():
        _owner_loc = locations.get(_owner_slot)
        if _owner_loc is None:
            raise ValueError(
                f"generate_boot_image: frozen resident slot {_owner_slot} is not resident")
        _owner_header = mem[_owner_loc]
        _owner_size = 1 << (((_owner_header >> 23) & 0xF) + 6)
        _owner_cc = _owner_header & 0xFF
        if _owner_cc < 1:
            raise ValueError(
                f"generate_boot_image: frozen resident slot {_owner_slot} has no SELF row")
        _owner_row0 = mem[_owner_loc + _owner_size - _owner_cc]
        verify_bootstrap_self_gt(_owner, _owner_row0, _owner.get("token"))
        _owner_ns_base = total - (_owner_slot + 1) * NS_ENTRY_WORDS
        if mem[_owner_ns_base + 3] != _owner_row0:
            raise ValueError(
                f"generate_boot_image: frozen resident slot {_owner_slot} "
                "NS W3 differs from SELF GT")

    # ----- Pack ----------------------------------------------------------
    image = struct.pack(f"<{total}I", *mem)

    # Pre-flight sanity check: catch a zeroed mandatory NS slot now rather
    # than waiting for the simulator to fault at runtime.
    validate_boot_image(image, total, simulation_only=honor_namespace_layout)

    return image


# ---------------------------------------------------------------------------
# Namespace placement is solely ns-state/boot configuration.
# ---------------------------------------------------------------------------

def check_ns_slot_drift(lumps_dir):
    """Retained compatibility hook; there is no second placement authority."""
    return []
